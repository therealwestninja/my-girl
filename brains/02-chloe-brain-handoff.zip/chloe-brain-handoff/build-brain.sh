#!/usr/bin/env bash
# Compile the pure Brain: brain.js (editable source) -> brain.min.js (the lean, mangled, comment-free artifact
# the app ships). Property names are preserved (the mouth's API contract); only internals are mangled.
# Verify equivalence afterwards:  BRAIN=./brain.min.js node harness-solo-council.js
set -e
cd "$(dirname "$0")"
npx terser brain.js \
  --compress passes=3,unsafe=true,toplevel=true,drop_console=true \
  --mangle toplevel=true \
  --format 'comments=false' \
  --output brain.min.js
node --check brain.min.js
printf 'brain.js %s -> brain.min.js %s bytes\n' "$(wc -c <brain.js)" "$(wc -c <brain.min.js)"
