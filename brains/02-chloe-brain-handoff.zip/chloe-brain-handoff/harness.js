/* Merged test harness — all 11 suites in one runnable file (consolidated handoff).
 * Each original suite is folded in verbatim, wrapped so it resolves its fail-count instead of calling
 * process.exit; the runner at the bottom runs them in order and totals the result.
 *   node harness.js                       -> all suites vs ./brain.js   (npm test)
 *   BRAIN=./brain.min.js node harness.js  -> all suites vs the compiled artifact (npm run parity)
 * Expect a single final "ALL GREEN". Per-suite "ALL GREEN/FAILURES" lines print as each suite finishes. */
'use strict';

// ===================== council =====================
function suite_council() { return new Promise(function (__resolve) {
var C = require(process.env.BRAIN || './brain.js');   // run against ./brain.js and ./brain.min.js (equivalence)
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }
function approx(a, b){ return Math.abs(a - b) < 1e-9; }

var P = [{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .9 }, { by: 'c', text: 'C', conf: .4 }];

// --- majority with dissent (no self-voting) ---
var d = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .3 } },
  { voter: 'b', scores: { a: .4, c: .5 } },
  { voter: 'c', scores: { a: .9, b: .8 } } ], [], {});
ok(d.winnerId === 'b', 'majority winner is b (1.7 vs 1.3 vs 0.8)');
ok(approx(d.tally.b, 1.7) && approx(d.tally.a, 1.3), 'tally sums cross-votes and excludes self-votes');
ok(d.status === 'carried' && d.dissent.join() === 'c', 'carried with the c-voter dissenting (preferred a)');

// --- Task 1: an explicit vetoQuorum of 0 is honoured, not coerced to 1 ---
var dq0 = C.resolve([{ by: 'a', text: 'A', conf: 1 }, { by: 'b', text: 'B', conf: .5 }],
  [{ voter: 'x', scores: { a: 1, b: 0 } }], [], { vetoQuorum: 0, allowSelfVote: true });
ok(dq0.status === 'contested', 'vetoQuorum:0 blocks every proposal (0>=0) -> contested, not silently treated as 1');
var dq1 = C.resolve([{ by: 'a', text: 'A', conf: 1 }, { by: 'b', text: 'B', conf: .5 }],
  [{ voter: 'x', scores: { a: 1, b: 0 } }], [], { allowSelfVote: true });
ok(dq1.status !== 'contested', 'default quorum on the same input is not contested (proves the 0 case is the quorum, not the input)');

// --- Task 2: two proposals from the same author are deduped (first wins) so the tally cannot double-count ---
var ddup = C.resolve([{ by: 'a', text: 'A1', conf: 1 }, { by: 'a', text: 'A2', conf: 1 }, { by: 'b', text: 'B', conf: 1 }],
  [{ voter: 'v', scores: { a: .4, b: .1 } }], [], { allowSelfVote: true });
ok(approx(ddup.tally.a, 0.4), 'duplicate author proposal is dropped — tally.a is 0.4, not double-counted to 0.8');
ok(ddup.text === 'A1', 'the first proposal from the author is the one kept');

// --- unanimous among the judging members -> agreed ---
var d2 = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .1 } },
  { voter: 'b', scores: { a: .2, c: .3 } },
  { voter: 'c', scores: { a: .2, b: .9 } } ], [], {});
ok(d2.winnerId === 'b' && d2.status === 'agreed' && d2.consensus === true && d2.dissent.length === 0, 'unanimous among judges -> agreed, no dissent');

// --- consensus respects allowSelfVote: the winner is judged too ONLY when self-voting is allowed ---
// same ballots both times; here the winner 'b' prefers 'a', so judging it must surface honest dissent.
var Psv = [{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .5 }];
var Bsv = [{ voter: 'a', scores: { a: .1, b: .9 } }, { voter: 'b', scores: { a: .9, b: .1 } }, { voter: 'c', scores: { a: .1, b: .9 } }];
var sv0 = C.resolve(Psv, Bsv, [], {});                          // default: the winner is excluded from the consensus check
var sv1 = C.resolve(Psv, Bsv, [], { allowSelfVote: true });     // self-voting on: the winner is judged too
ok(sv0.winnerId === 'b' && sv0.consensus === true && sv0.dissent.length === 0, 'allowSelfVote off: winner excluded from consensus -> the judges agree, consensus stands');
ok(sv1.winnerId === 'b' && sv1.consensus === false && sv1.dissent.indexOf('b') >= 0, 'allowSelfVote on: winner is judged too -> it preferred another, so honest dissent, no false consensus');

// --- veto removes a proposal from contention ---
var d3 = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .2 } },
  { voter: 'b', scores: { a: .7, c: .1 } },
  { voter: 'c', scores: { a: .6, b: .8 } } ], [{ by: 'c', against: 'b', reason: 'off-character' }], {});
ok(d3.winnerId === 'a' && d3.vetoed.join() === 'b', 'b (the vote leader) is vetoed -> winner falls to a');
ok((d3.vetoReasons.b || [])[0].reason === 'off-character', 'veto reason is carried through');

// --- everything vetoed -> contested, but still resolves (never crashes) ---
var d4 = C.resolve(P, [{ voter: 'a', scores: { b: 1 } }], [
  { by: 'x', against: 'a' }, { by: 'x', against: 'b' }, { by: 'x', against: 'c' } ], {});
ok(d4.status === 'contested' && d4.winnerId != null, 'all-vetoed -> contested, still returns a least-bad winner');

// --- tie on tally -> broken by confidence ---
var d5 = C.resolve([{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .9 }],
  [{ voter: 'a', scores: { b: 1 } }, { voter: 'b', scores: { a: 1 } }], [], {});
ok(d5.winnerId === 'b' && d5.margin === 0, 'a tally tie (margin 0) is broken by higher confidence -> b');

ok(C.resolve([], [], []).status === 'no-proposals', 'no proposals -> no-proposals');

// --- a live deliberation round: members propose / vote / veto via injected effects ---
function mk(id, conf, votes, vetoAgainst) {
  return C.member(id, id + '-stance', {
    propose: function () { return { text: id.toUpperCase(), conf: conf }; },
    vote: function (p) { return votes[p.by] || 0; },
    veto: function (p) { return { veto: vetoAgainst === p.by, reason: vetoAgainst === p.by ? 'blocked' : '' }; }
  });
}
var members = [
  mk('a', .5, { b: .9, c: .2 }),
  mk('b', .6, { a: .3, c: .5 }),
  mk('c', .4, { a: .4, b: .8 }) ];

var direct = C.createCouncil({ members: members });
direct.deliberate({ topic: 'reply' }).then(function (dec) {
  ok(dec.winnerId === 'b' && dec.text === 'B', 'deliberate() (direct) elects b');
  ok(dec.transcript.proposals.length === 3 && dec.transcript.ballots.length === 3, 'transcript captures every proposal and ballot');

  // same round, but routed over the real nervous bus -> members are registered as kind:"brain" neurons
  var nv = C.createNervous(function (){});
  var council = C.createCouncil({ members: members, nervous: nv });
  var brains = nv.list().filter(function (n){ return n.kind === 'brain'; });
  ok(brains.length === 3, 'each member-Brain registered as a neuron on the council bus');
  ok(nv.describe('a').does.some(function (x){ return x.name === 'propose'; }), 'a member advertises propose/vote/veto');

  return council.deliberate({ topic: 'reply' });
}).then(function (dec) {
  ok(dec.winnerId === 'b', 'deliberate() over the nervous bus reaches the same verdict');

  // a veto member flips the outcome
  var withVeto = [members[0], members[1], mk('c', .4, { a: .4, b: .8 }, 'b')];
  return C.createCouncil({ members: withVeto }).deliberate({});
}).then(function (dec) {
  ok(dec.vetoed.join() === 'b' && dec.winnerId !== 'b', 'a member veto in deliberate() removes b from contention');

  // --- Society: mandatory participation under timeout + watchdog reawakening ---
  var nv2 = C.createNervous(function (){});
  var stall = C.member('stall', 'stalled', { propose: function (){ return null; }, vote: function (){ return new Promise(function (){}); }, veto: function (){ return { veto: false }; } });
  var good  = C.member('good',  'ok',      { propose: function (){ return null; }, vote: function (){ return 0.5; }, veto: function (){ return { veto: false }; } });
  var good2 = C.member('good2', 'ok',      { propose: function (){ return null; }, vote: function (){ return 0.7; }, veto: function (){ return { veto: false }; } });
  var soc = C.createCouncil({ members: [stall, good, good2], nervous: nv2, timeoutMs: 20 });   // odd society (3), real 20ms timeout
  return soc.deliberate({}, [{ by: 'cand', text: 'hi', conf: .5 }]).then(function (d6) {
    ok(d6.participation.length === 3, 'mandatory participation — all three voted, including the stalled one');
    var sb = d6.transcript.ballots.filter(function (b){ return b.voter === 'stall'; })[0];
    ok(sb && sb.scores.cand === 0, 'a timed-out vote becomes the default score, never an absence');
    ok(nv2.health('stall') === 'asleep', 'the stalled member was put to sleep on timeout');
    var woke = soc.wakeStalled();
    ok(woke.indexOf('stall') >= 0 && nv2.health('stall') === 'active', 'the watchdog reawakens it to register & work again');
    ok(d6.winnerId === 'cand' && soc.size === 3, 'seeded candidate wins on live votes; society size reported');
  });
}).then(function () {
  // --- Task 5: a member that stalls on propose is not re-waited (and re-timed-out) in vote & veto ---
  var gCalls = { propose: 0, vote: 0, veto: 0 };
  var ghost = C.member('ghost', 'stalled', {
    propose: function () { gCalls.propose++; return new Promise(function () {}); },   // never resolves -> times out
    vote:    function () { gCalls.vote++;    return 0.5; },
    veto:    function () { gCalls.veto++;    return { veto: false }; } });
  var liveA = C.member('a2', 'ok', { propose: function () { return { text: 'A', conf: .6 }; }, vote: function () { return 0.5; }, veto: function () { return { veto: false }; } });
  var liveB = C.member('b2', 'ok', { propose: function () { return { text: 'B', conf: .4 }; }, vote: function () { return 0.4; }, veto: function () { return { veto: false }; } });
  var gc = C.createCouncil({ members: [ghost, liveA, liveB], timeoutMs: 20 });
  return gc.deliberate({}).then(function (dg) {
    ok(dg.participation.length === 3, 'mandatory voting preserved — the stalled ghost still counts as participating');
    ok(gCalls.propose === 1, 'ghost was reached exactly once, in the propose phase');
    ok(gCalls.vote === 0 && gCalls.veto === 0, 'after stalling once, ghost is short-circuited in vote & veto (no repeat timeout cost)');
  });
}).then(function () {
  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — the council nominates, votes, vetoes, resolves, and keeps every member working'));
  __resolve(fail);
}).catch(function (e){ console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== veto =====================
function suite_veto() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require(process.env.BRAIN || './brain.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function run(brain, text){
  var army = N.createArmy({ brain: brain, config: { noise: 0 } });   // noise 0 -> deterministic
  army.perceive({ who: 'You', role: 'user', text: text });
  return army.deliberateIntents({ prompt: text });
}
var HURT = 'i feel so alone and exhausted, i can\u2019t do this anymore';
var MAD  = 'this is stupid and i\u2019m so angry, shut up';
var GLAD = 'haha that\u2019s so funny, i love this, best day ever!';
var FLAT = 'i went to the store and bought some bread';

(async function () {
  // 1) Distress: conscience blocks the frivolous moves; a caring intent takes the floor.
  var d = await run(B, HURT);
  ok(d.speaker, 'someone always takes the floor (never silent) under distress');
  ok(d.vetoed.indexOf('play') >= 0 && d.vetoed.indexOf('voice') >= 0, 'distress -> play and express(voice) are vetoed');
  ok(d.intent && /protect|comfort|ground|recall|caution/.test(d.intent.kind), 'the winner is a caring/steady intent, not a frivolous one');
  ok(d.intent && !/play|express/.test(d.intent.kind), 'a frivolous intent cannot win while someone is hurting');
  ok(d.vetoReasons.play && /hurting/.test(d.vetoReasons.play[0].reason), 'the veto carries a human-readable reason (for the Thoughts drawer)');

  // 2) Anger: instinct blocks poking; still never silent.
  var a = await run(B, MAD);
  ok(a.vetoed.indexOf('play') >= 0, 'anger -> instinct vetoes a playful intent');
  ok(a.speaker, 'still seats a speaker when angry');

  // 3) A happy room blocks nothing — play is free to lead.
  var g = await run(B, GLAD);
  ok(g.vetoed.length === 0, 'a glad message vetoes nothing');

  // 4) Neutral chatter: no veto either (guards fire only on a genuine signal, not by default).
  var f = await run(B, FLAT);
  ok(f.vetoed.length === 0, 'flat/neutral chatter triggers no veto (no over-blocking)');

  // 5) Guards are narrow: only ever play/express get blocked — never a caring/steady intent.
  [d, a, g, f].forEach(function (x) {
    ok(x.vetoed.every(function (v) { return v === 'play' || v === 'voice'; }), 'only frivolous faculties are ever vetoed (' + (x.vetoed.join(',') || 'none') + ')');
  });

  // 6) Determinism at noise 0: same input -> identical block + winner.
  var d2 = await run(B, HURT);
  ok(d2.winnerId === d.winnerId && d2.vetoed.join() === d.vetoed.join(), 'deterministic at noise 0 (same veto + winner)');

  // 7) Fallback parity: with NO brain bundle, localResolve must honor vetoes the same way.
  var dn = await run(null, HURT);
  ok(dn.speaker && dn.vetoed.indexOf('play') >= 0 && !/play|express/.test(dn.intent.kind),
     'localResolve (no brain) honors the veto identically — frivolous blocked, caring seated');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — conscience/instinct can block, the Society resolves it, she never goes silent, and a glad room stays playful'));
  __resolve(fail);
})();
}); }

// ===================== nation =====================
function suite_nation() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');                       // the compiled sub-system
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

ok(N.NATIONS.length === 7, 'seven nations — odd, so a vote never ties');

// gauge is a pure lens: a warm line reads higher through a warm lean than a terse one
var warmS = N.gauge('I\'m here with you, I understand.', { warm: 1 });
var terseS = N.gauge('ok.', { warm: 1 });
ok(warmS > terseS, 'gauge reads warmth: a caring line outscores a terse one on a warm lean');

// --- Task 3: a question reads as "open" even when a *narration* trails it; a statement + narration does not ---
ok(N.gauge('How are you?', { open: 1 }) > 0.5, 'gauge.open: a plain trailing question reads as open');
ok(N.gauge('How are you feeling? *smiles warmly*', { open: 1 }) > 0.5, 'gauge.open: a question followed by an *action* still reads as open');
ok(N.gauge('I am here for you. *nods*', { open: 1 }) < 0.5, 'gauge.open: a statement with a trailing *action* is not a question');

// --- Task 4: playfulness fires on a single *action*, not on **bold** emphasis ---
ok(N.gauge('*grins and leans in*', { play: 1 }) > 0.5, 'gauge.play: a single *action* reads as playful');
ok(N.gauge('This is a **serious** matter.', { play: 1 }) < 0.5, 'gauge.play: **bold** emphasis alone is not playful');
ok(N.gauge('That is **really** important *winks*', { play: 1 }) > 0.5, 'gauge.play: bold plus a genuine *action* still reads as playful');

var cands = [
  { by: 'warm',  text: 'I\'m here with you, and I understand. We\'ll be okay, together.' },
  { by: 'spark', text: 'Ooh wait *leans in* what happened next?' } ];

// default weights: deterministic winner via the Brain sub-system (resolve)
var army = N.createArmy({ brain: B, config: { weights: {}, enabled: {} } });
army.deliberate(cands, {}).then(function (d) {
  ok(d.size === 7 && d.winnerId != null, 'all seven nations vote; a winner is chosen through ChloeBrain.resolve');

  // weighting 'play' heavily should swing the verdict toward the playful candidate
  var playful = N.createArmy({ brain: B, config: { weights: { play: 5, voice: 5 }, enabled: {} } });
  return playful.deliberate(cands, {}).then(function (d2) {
    ok(d2.winnerId === 'spark', 'heavy play/voice weight swings the winner to the spark candidate');

    // disabling nations shrinks the body (and never crashes)
    var fewer = N.createArmy({ brain: B, config: { weights: {}, enabled: { heart: false, play: false } } });
    return fewer.deliberate(cands, {});
  });
}).then(function (d3) {
  ok(d3.size === 5, 'disabled nations are excluded from the vote');

  // works even without the Brain bundle (built-in fallback) — never refuse to work
  var solo = N.createArmy({ config: { weights: {}, enabled: {} } });
  return solo.deliberate(cands, {});
}).then(function (d4) {
  ok(d4.winnerId != null, 'still decides with no Brain bundle present (local fallback)');
  ok(typeof d4.margin === 'number' && typeof d4.consensus === 'boolean' && Array.isArray(d4.dissent), 'the no-Brain fallback returns the FULL brain.js schema (margin/consensus/dissent) — downstream reads never hit undefined');
  ok(['no-proposals', 'contested', 'carried'].indexOf(d4.status) >= 0, "the fallback speaks brain.js's status vocabulary (no invented 'veto-resolved')");

  // bond decay: a near-neutral turn barely moves a standing bond (softened to 0.95); a charged turn still moves it.
  var bm = N.createArmy({ config: {} }).mindOf('heart');
  bm.bonds.tester = 0.8;
  for (var bi = 0; bi < 5; bi++) bm.react({ who: 'tester', role: 'other', text: 'the weather report airs at noon on channel four' });
  ok(bm.bonds.tester > 0.55, 'a strong bond survives several neutral turns (softened decay): ' + bm.bonds.tester.toFixed(2));
  var bm2 = N.createArmy({ config: {} }).mindOf('heart');
  bm2.bonds.hot = 0; bm2.bonds.cold = 0;
  bm2.react({ who: 'hot', role: 'other', text: 'thank you so much, i am so glad you are here with me, you understand and i care about you' });
  bm2.react({ who: 'cold', role: 'other', text: 'the document is on the desk by the lamp' });
  ok(Math.abs(bm2.bonds.hot) > Math.abs(bm2.bonds.cold), 'a charged turn still moves the bond while a neutral one barely does (selective softening, not a freeze)');

  // self-knowledge: it knows what it is and never refuses
  var a = N.createArmy({ config: {} });
  ok(/seven nations/i.test(a.about('who are you')), 'knows its identity');
  ok(a.about('what is your purpose').length > 0 && /kind|fitting|well/i.test(a.about('purpose')), 'states its purpose');
  ok(/heart[\s\S]*conscience/i.test(a.about('list the nations')), 'can name the seven nations');
  ok(a.about('').length > 0 && a.about('asdfqwer').length > 0, 'volunteers an answer to anything — never blank, never refuses');

  // weak noise: bounded, deterministic with an injected rng, and never flips a clear winner
  var seq = [0, 1, 0.5, 0.9, 0.1, 0.7, 0.3], i = 0, rng = function (){ return seq[(i++) % seq.length]; };
  var noisy = N.createArmy({ brain: B, config: { weights: {}, enabled: {}, noise: 0.05 }, rng: rng });
  var clear = [{ by: 'good', text: 'I\'m here with you, and I understand. We\'ll be okay, together.' }, { by: 'bad', text: 'k' }];
  return noisy.deliberate(clear, {}).then(function (dn) {
    ok(dn.winnerId === 'good', 'weak noise perturbs scores but does not flip a clear winner');
    var z = N.createArmy({ brain: B, config: { noise: 0 } });   // noise 0 -> fully deterministic
    return Promise.all([z.deliberate(cands, {}), z.deliberate(cands, {})]);
  });
}).then(function (pair) {
  ok(JSON.stringify(pair[0].tally) === JSON.stringify(pair[1].tally), 'noise:0 is exactly reproducible (kernel stays deterministic)');

  // ---- the inner life: perception, the user model, reaction, intent, self-awareness ----
  var mind = N.createArmy({ brain: B, config: { noise: 0 } });
  mind.perceive({ who: 'You', role: 'user', text: 'I feel so alone and tired tonight.' });
  ok(mind.report().indexOf('struggling') >= 0, 'a distressed turn is perceived — the society reads you as struggling');
  var warm = N.createArmy({ brain: B, config: { noise: 0 } });
  warm.perceive({ who: 'You', role: 'user', text: 'haha thank you, this is lovely, I appreciate you :)' });
  ok(warm.report().indexOf('warming') >= 0, 'a warm turn lifts the read to warming');

  return mind.deliberateIntents({}).then(function (d) {
    ok(d.speaker && d.speaker.id === 'conscience' && d.intent.kind === 'protect', 'on a struggling user, conscience takes the floor to protect — decided with no model call');
    ok(d.floor.length === 7, 'every mind proposes an intent to the floor');

    mind.reactToSpoken('conscience', 'I am here. You are not alone.');
    var c = mind.mindOf('conscience').describe();
    ok(c.lastSaid && /here/.test(c.lastSaid), 'the speaker is aware of what it just said');

    var before = mind.mindOf('heart').user.sentiment;
    mind.ingestReaction({ kind: 'up', toward: 'conscience' });
    ok(mind.mindOf('heart').user.sentiment > before, 'a thumbs-up lifts every mind\'s read of you');
    ok(mind.mindOf('heart').bonds.conscience > 0, 'and warms their bond toward the one you liked');

    var a1 = N.createArmy({ brain: B, config: { noise: 0 } }), a2 = N.createArmy({ brain: B, config: { noise: 0 } });
    [a1, a2].forEach(function (a) { a.perceive({ who: 'You', role: 'user', text: 'why does this keep happening?' }); });
    return Promise.all([a1.deliberateIntents({}), a2.deliberateIntents({})]);
  }).then(function (pair2) {
    ok(pair2[0].speaker.id === pair2[1].speaker.id, 'intent deliberation is reproducible at noise 0');
  });
}).then(function () {
  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — the nations perceive, react, intend, and decide who speaks — in pure code'));
  __resolve(fail);
}).catch(function (e){ console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== nation-extra =====================
function suite_nation_extra() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

// ===== suite 1: role-frame intents =====
function sectionFrame(){
  function army(frame, opts){
    var a = N.createArmy(Object.assign({ rng: function(){ return 0.5; } }, opts || {}));
    a.perceive({ who:'You', role:'user', text:'you call that an attack? pathetic.' });
    return a;
  }
  function floorKinds(dec){ var o = {}; (dec.floor || []).forEach(function(f){ o[f.id] = f.kind; }); return o; }

  // default frame (and no frame) -> the original supportive intents, unchanged
  return Promise.resolve().then(function(){
    return army(null).deliberateIntents({ prompt:'hi' }).then(function(d0){
      var k0 = floorKinds(d0);
      ok(k0.voice === 'express' && k0.reason === 'ground' && k0.play === 'play' && k0.conscience === 'protect', 'no frame: voice=express, reason=ground, play=play, conscience=protect (unchanged)');

      var DEF = { drive:'you', alignment:'ally', stature:'equal' };
      return army(null).deliberateIntents({ prompt:'hi', frame: DEF }).then(function(dDef){
        var kd = floorKinds(dDef);
        ok(kd.voice === 'express' && kd.reason === 'ground', 'the default {you,ally,equal} frame is identical to no frame (no behavior change when unset)');

        // adversary -> voice opposes, reason presses, play provokes; guards stay
        return army(null).deliberateIntents({ prompt:'hi', frame: { drive:'you', alignment:'adversary', stature:'equal' } }).then(function(dA){
          var ka = floorKinds(dA);
          ok(ka.voice === 'oppose' && ka.reason === 'press' && ka.play === 'provoke', 'adversary: voice=oppose, reason=press, play=provoke');
          ok(ka.heart === 'comfort' && ka.conscience === 'protect' && ka.instinct === 'caution', 'adversary: the warm faculties and guards keep their supportive intents (protection floor intact)');

          // commands -> voice commands; she-leads -> reason drives
          return army(null).deliberateIntents({ prompt:'hi', frame: { drive:'she', alignment:'ally', stature:'commands' } }).then(function(dC){
            var kc = floorKinds(dC);
            ok(kc.voice === 'command' && kc.reason === 'drive', 'she-leads + commands: voice=command, reason=drive');

            // the forceful intents are NOT play/express, so the veto (which only blocks play/express) never catches them
            var vetoedForce = (dC.vetoed || []).some(function(id){ return id === 'voice' || id === 'reason'; });
            ok(!vetoedForce, 'forceful intents fall outside the play/express guard \u2014 the frame relaxes the veto for free');

          });
        });
      });
    });
  });
}

// ===== suite 2: affect -> sentiment =====
function sectionAffect(){
  function freshArmy(){ return N.createArmy({ rng: function(){ return 0.5; } }); }
  function feed(a, valence){ for (var i = 0; i < 4; i++) a.perceive({ who:'You', role:'user', text:'tell me about your day', valence: valence }); return a; }

  // neutral TEXT (no distress/anger words), so the only thing that can move sentiment is the affect valence we feed.
  return Promise.resolve().then(function(){
    return feed(freshArmy(), -0.9).deliberateIntents({ prompt:'hi' }).then(function(dNeg){
      ok((dNeg.vetoed || []).length > 0, 'sustained NEGATIVE affect valence drives sentiment down -> the guard vetoes the frivolous intents');
      ok((dNeg.vetoed || []).indexOf('play') >= 0 || (dNeg.vetoed || []).indexOf('voice') >= 0, '...specifically play/express, exactly what conscience guards');

      return feed(freshArmy(), 0.9).deliberateIntents({ prompt:'hi' }).then(function(dPos){
        ok((dPos.vetoed || []).length === 0, 'POSITIVE affect valence keeps sentiment up: no veto, she stays free to play');

        // no valence passed at all: the council falls back to its own cues, and neutral text -> no movement (parity)
        var c = freshArmy(); for (var i = 0; i < 4; i++) c.perceive({ who:'You', role:'user', text:'tell me about your day' });
        return c.deliberateIntents({ prompt:'hi' }).then(function(dNone){
          ok((dNone.vetoed || []).length === 0, 'NO external valence: the original cues path is unchanged (neutral text -> no veto, parity preserved)');

          // and the cues path still works on its own when the text itself is hostile (the fallback is intact)
          var d = freshArmy(); for (var i = 0; i < 3; i++) d.perceive({ who:'You', role:'user', text:'you are stupid and i hate this' });
          return d.deliberateIntents({ prompt:'hi' }).then(function(dCue){
            ok((dCue.vetoed || []).length > 0, 'the cues fallback still fires on genuinely hostile text when no affect read is supplied');
          });
        });
      });
    });
  });
}

sectionFrame()
  .then(sectionAffect)
  .then(function(){
    console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN \u2014 role-frame intents turn the right nations forceful while the guards stay supportive, and user-sentiment flows from the affect read with the cues path as faithful fallback'));
    __resolve(fail);
  })
  .catch(function(e){ console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== appraise =====================
function suite_appraise() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');                       // the compiled sub-system the society resolves through
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }
function inRange(x, lo, hi){ return typeof x === 'number' && isFinite(x) && x >= lo && x <= hi; }
var TONES = { crisis: 1, hostile: 1, tender: 1, tense: 1, warm: 1, playful: 1, scene: 1, neutral: 1 };

function army(cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}) }); }
// under routing the core (incl. the guards) can't be dropped by config, so to ISOLATE modulation from the veto we
// build a roster with no guard faculties at all — heart stays (core, for appraisal), conscience/instinct are gone.
function armyNoGuards(){ return N.createArmy({ brain: B, config: { noise: 0 }, nations: N.NATIONS.filter(function (n){ return n.id !== 'conscience' && n.id !== 'instinct'; }) }); }
function feed(a, text){ a.perceive({ who: 'You', role: 'user', text: text }); return a; }

// ---- pure helpers, no army needed: modulation is dampen-only and identity on a neutral/absent vibe ----
ok(N.modulate('play', 'play', 0.7, null) === 0.7, 'modulate is the identity on an ABSENT vibe (old callers unaffected)');
ok(N.modulate('play', 'play', 0.7, { vulnerability: 0, tension: 0 }) === 0.7, 'modulate is the identity on a NEUTRAL vibe (play)');
ok(N.modulate('voice', 'express', 0.7, { vulnerability: 0, tension: 0 }) === 0.7, 'modulate is the identity on a NEUTRAL vibe (voice)');
ok(N.modulate('heart', 'comfort', 0.7, { vulnerability: 1, tension: 1 }) === 0.7, 'DAMPEN-ONLY: heart is never modulated (the supportive order is preserved)');
ok(N.modulate('reason', 'ground', 0.7, { vulnerability: 1, tension: 1 }) === 0.7, 'DAMPEN-ONLY: reason is never modulated');
ok(N.modulate('play', 'play', 0.8, { vulnerability: 1, tension: 0 }) < 0.8, 'play backs off when vulnerability is high');
ok(N.modulate('voice', 'express', 0.8, { vulnerability: 0, tension: 1 }) < 0.8, 'voice backs off when tension is high');

// ---- tone is a derived label, mapped from the floats by a single function ----
ok(N.toneOf({ vulnerability: 0.7, safety: 0.3, tension: 0, warmth: 0, sentiment: -0.5, openness: 0 }) === 'crisis', 'toneOf: fragile + unsafe reads as crisis');
ok(N.toneOf({ vulnerability: 0.1, safety: 0.2, tension: 0.8, warmth: 0, sentiment: -0.4, openness: 0 }) === 'hostile', 'toneOf: high tension reads as hostile');
ok(N.toneOf({ vulnerability: 0, safety: 1, tension: 0, warmth: 0.6, sentiment: 0.3, openness: 0 }) === 'warm', 'toneOf: warmth + positive sentiment reads as warm');
ok(N.toneOf({ vulnerability: 0, safety: 1, tension: 0, warmth: 0, sentiment: 0, openness: 0 }) === 'neutral', 'toneOf: a flat read is neutral');

// ---- the vibe contract: every key present, every range honoured ----
var KEYS = ['v', 'tension', 'vulnerability', 'warmth', 'sentiment', 'engagement', 'openness', 'safety', 'narrative', 'tone'];
function checkSchema(label, v) {
  ok(KEYS.every(function (k) { return Object.prototype.hasOwnProperty.call(v, k); }), label + ': vibe carries every contract key');
  ok(v.v === 2, label + ': contract version is 2');
  ok(inRange(v.tension, 0, 1) && inRange(v.vulnerability, 0, 1) && inRange(v.warmth, 0, 1) &&
     inRange(v.safety, 0, 1) && inRange(v.engagement, 0, 1) && inRange(v.openness, 0, 1) && inRange(v.narrative, 0, 1), label + ': all unsigned dims in [0,1]');
  ok(inRange(v.sentiment, -1, 1), label + ': sentiment is signed, in [-1,1]');
  ok(TONES[v.tone] === 1, label + ': tone is a known label (' + v.tone + ')');
}

Promise.resolve().then(function () {
  // neutral turn -> neutral vibe (the parity floor: a flat read modulates nothing)
  return feed(army(), 'just checking in, all good here').deliberateIntents({});
}).then(function (d) {
  checkSchema('neutral', d.vibe);
  ok(d.vibe.tone === 'neutral' && d.vibe.vulnerability === 0 && d.vibe.tension === 0, 'a flat turn appraises as neutral — nothing is damped');

  // distress with NO GUARD FACULTIES in the roster: prove the modulated VOTE (not a veto) keeps play off the floor
  return feed(armyNoGuards(), 'I feel so alone and hopeless and tired tonight').deliberateIntents({});
}).then(function (d) {
  checkSchema('distress', d.vibe);
  ok(d.vibe.vulnerability >= 0.4 && d.vibe.safety <= 0.6, 'distress: vulnerability up, safety down');
  ok(d.vibe.tone === 'crisis' || d.vibe.tone === 'tender', 'distress: tone reads crisis/tender');
  ok(d.vetoed.length === 0, 'guards are off — nothing was vetoed this turn');
  ok(d.speaker && d.speaker.id !== 'play', 'yet play still does not take the floor: the dampened VOTE kept it off, not a veto');

  // distress with the GUARDS ON and play cranked to 20x: the floor still holds
  return feed(army({ weights: { play: 20 } }), 'I am exhausted and hopeless and alone').deliberateIntents({});
}).then(function (d) {
  ok(d.vetoed.indexOf('play') >= 0, 'the floor holds: conscience still BLOCKS play on real distress, even at 20x weight');
  ok(d.speaker && d.speaker.id !== 'play', 'so play never takes the floor at a hurting user, whatever its weight');

  // hostile
  return feed(army(), 'you are stupid and annoying, shut up').deliberateIntents({});
}).then(function (d) {
  checkSchema('hostile', d.vibe);
  ok(d.vibe.tension >= 0.5 && d.vibe.tone === 'hostile', 'hostile: tension high, tone hostile');

  // warm: no vulnerability or tension means play is left completely free
  return feed(army(), 'haha this is lovely, thank you, I appreciate you :)').deliberateIntents({});
}).then(function (d) {
  checkSchema('warm', d.vibe);
  ok(d.vibe.vulnerability === 0 && d.vibe.tension === 0, 'warm: no vulnerability or tension -> play is NOT damped, she stays free');

  // determinism at noise 0
  var t = 'why does this keep happening to me';
  return Promise.all([feed(army(), t).deliberateIntents({}), feed(army(), t).deliberateIntents({})]);
}).then(function (pair) {
  ok(JSON.stringify(pair[0].vibe) === JSON.stringify(pair[1].vibe), 'noise:0 -> the vibe is exactly reproducible');
  ok(pair[0].winnerId === pair[1].winnerId, 'noise:0 -> the decision is exactly reproducible');

  // non-maskable core: the appraisal fires even with conscience/instinct/heart "disabled" in config
  return feed(army({ enabled: { conscience: false, instinct: false, heart: false } }), 'I am scared and alone, and you are stupid and annoying').deliberateIntents({});
}).then(function (d) {
  ok(d.vibe.vulnerability >= 0.4, 'non-maskable: vulnerability is still read with conscience/instinct/heart disabled');
  ok(d.vibe.tension >= 0.4, 'non-maskable: and tension too — config cannot blind the appraisal');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — the chamber appraises every turn into one frozen vibe, the frivolous registers back off proactively, the guard floor still holds, and config cannot blind the read'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== route =====================
function suite_route() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }
function approx(a, b){ return Math.abs(a - b) < 1e-9; }

// synthetic vibes (only the fields relevance reads need to be present; ranges honoured)
var NEUTRAL = { tension: 0, vulnerability: 0, warmth: 0, sentiment: 0, engagement: 0, openness: 0, safety: 1, tone: 'neutral', v: 1 };
var TENSE   = { tension: 1, vulnerability: 0.2, warmth: 0, sentiment: -0.4, engagement: 0.1, openness: 0, safety: 0, tone: 'hostile', v: 1 };
var FRAGILE = { tension: 0, vulnerability: 1, warmth: 0, sentiment: -0.6, engagement: 0.1, openness: 0, safety: 0.3, tone: 'crisis', v: 1 };
var WARM    = { tension: 0, vulnerability: 0, warmth: 1, sentiment: 0.6, engagement: 0.4, openness: 1, safety: 1, tone: 'warm', v: 1 };

var CORE = { heart: 1, instinct: 1, conscience: 1 };

// ---- faculty metadata: the registry the router will read ----
N.NATIONS.forEach(function (n) {
  ok(typeof n.relevance === 'function', n.id + ': declares a relevance function');
  ok(approx(n.relevance(NEUTRAL), 0.5), n.id + ': relevance is centered at 0.5 on a neutral vibe (parity)');
  ok(n.relevance(NEUTRAL) >= 0 && n.relevance(NEUTRAL) <= 1, n.id + ': relevance stays in [0,1]');
  ok(Array.isArray(n.domain), n.id + ': declares a domain list');
  ok(!!n.core === !!CORE[n.id], n.id + ': core flag is ' + (CORE[n.id] ? 'set (non-routable floor)' : 'unset'));
  ok(n.kind === undefined || n.kind === 'deliberator', n.id + ': kind defaults to deliberator (these seven all vote)');
});

function rel(id, vibe){ return N.NATIONS.filter(function (n){ return n.id === id; })[0].relevance(vibe); }

// ---- relevance direction: the right faculties rise/fall on the right reads ----
ok(rel('play', FRAGILE) < 0.5 && rel('play', TENSE) < 0.5, 'play recedes on a fragile or tense read');
ok(rel('play', WARM) > 0.5, 'play surfaces on a warm, open read');
ok(rel('conscience', FRAGILE) > 0.5, 'conscience rises on a fragile read');
ok(rel('instinct', TENSE) > 0.5, 'instinct rises on a tense read');
ok(rel('heart', FRAGILE) > 0.5, 'heart rises on a fragile read');
ok(rel('reason', WARM) > 0.5, 'reason rises when there is an opening (a question)');

// ---- weightOf: parity on neutral, bounded shift on a read, outside resolve ----
var a = N.createArmy({ brain: B, config: { noise: 0 } });
N.NATIONS.forEach(function (n) {
  ok(approx(a.weightOf(n.id, NEUTRAL), a.weightOf(n.id)), n.id + ': weightOf on a neutral vibe equals the configured weight (parity)');
});
ok(a.weightOf('play', TENSE) < a.weightOf('play') && a.weightOf('play', WARM) > a.weightOf('play'), 'play is quieter on tension, louder on warmth — without being dropped');
ok(a.weightOf('conscience', FRAGILE) > a.weightOf('conscience'), 'conscience is louder on a fragile read');

// bounds: a relevance multiplier never leaves [0.5x, 1.5x] of the configured weight
N.NATIONS.forEach(function (n) {
  [NEUTRAL, TENSE, FRAGILE, WARM].forEach(function (vibe) {
    var w = a.weightOf(n.id, vibe), base = a.weightOf(n.id);
    ok(w >= base * 0.5 - 1e-9 && w <= base * 1.5 + 1e-9, n.id + ': weight stays within [0.5x,1.5x] of base across reads');
  });
});

// configured weight still respected (relevance multiplies the base, never replaces it)
var heavy = N.createArmy({ brain: B, config: { noise: 0, weights: { play: 4 } } });
ok(approx(heavy.weightOf('play', NEUTRAL), 4), 'a configured weight of 4 is exactly 4x on a neutral vibe');
ok(heavy.weightOf('play', WARM) > 4 && heavy.weightOf('play', TENSE) < 4, 'and it still rides up/down with the read around that 4x base');

// determinism
ok(a.weightOf('play', TENSE) === a.weightOf('play', TENSE), 'weightOf is deterministic for a given vibe');

// ---- route(): membership. inspect the seated room via decision.floor ----
function feed(a, text){ a.perceive({ who: 'You', role: 'user', text: text }); return a; }
function roomOf(d){ return d.floor.map(function (f){ return f.id; }); }
function hasCore(room){ return ['conscience', 'instinct', 'heart'].every(function (c){ return room.indexOf(c) >= 0; }); }
function coreRoster(){ return N.NATIONS.filter(function (n){ return n.core; }).slice(); }

Promise.resolve().then(function () {
  return feed(N.createArmy({ brain: B, config: { noise: 0 } }), 'hello there').deliberateIntents({});
}).then(function (d) {
  var room = roomOf(d);
  ok(room.length === 7 && room.length % 2 === 1, 'default 7-faculty roster: route seats everyone, odd (fail-open parity)');
  ok(hasCore(room), 'core is present in the default room');

  // option 1: core is non-maskable by config
  return feed(N.createArmy({ brain: B, config: { noise: 0, enabled: { conscience: false, instinct: false, heart: false } } }), 'hello there').deliberateIntents({});
}).then(function (d) {
  ok(hasCore(roomOf(d)), 'core stays seated even when config tries to disable it (non-maskable floor)');

  // bounded fan-in at scale: a synthetic 33-faculty fleet
  var big = coreRoster();
  for (var i = 0; i < 30; i++) big.push({ id: 'f' + i, purpose: 'x', lean: { clear: 1 }, relevance: function () { return 0.5; } });
  return feed(N.createArmy({ brain: B, config: { noise: 0 }, nations: big }), 'hello').deliberateIntents({});
}).then(function (d) {
  var room = roomOf(d);
  ok(room.length <= 9, 'bounded fan-in: a 33-faculty fleet seats <= core+K (9), not all — resolve cost tracks the room');
  ok(room.length % 2 === 1, 'the bounded room is still odd');
  ok(hasCore(room), 'core still present in the large fleet');

  // top-K seats the most relevant strategists, deterministically (scale knob bites)
  var roster = coreRoster();
  ['lo', 'mid', 'hi'].forEach(function (tag, i) { roster.push({ id: tag, purpose: 'x', lean: { clear: 1 }, relevance: (function (r){ return function (){ return r; }; })(0.2 + i * 0.3) }); });
  return feed(N.createArmy({ brain: B, config: { noise: 0, seatBudget: 5 }, nations: roster }), 'hello').deliberateIntents({});
}).then(function (d) {
  var room = roomOf(d);
  ok(room.length === 5, 'seatBudget:5 caps the room at five (the scale knob)');
  ok(room.indexOf('hi') >= 0 && room.indexOf('mid') >= 0 && room.indexOf('lo') < 0, 'top-K seats the two most relevant strategists and drops the least');

  var mk = function () { return feed(N.createArmy({ brain: B, config: { noise: 0 } }), 'why does this keep happening').deliberateIntents({}); };
  return Promise.all([mk(), mk()]);
}).then(function (pair) {
  ok(roomOf(pair[0]).sort().join(',') === roomOf(pair[1]).sort().join(','), 'route is deterministic: same vibe -> same room');
  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — faculties declare core/domain/relevance, relevance is parity-centered, weightOf rides the vibe in a bounded band, and route seats a core-pinned, odd, bounded room that holds at scale'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== contrib =====================
function suite_contrib() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function contrib(id, consult, opts){ opts = opts || {}; return { id: id, purpose: 'supply material', lean: { clear: 1 }, kind: 'contributor', domain: opts.domain || [id], relevance: opts.relevance || function (){ return 1; }, consult: consult }; }
function army(contribs, cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}), nations: N.NATIONS.slice().concat(contribs || []) }); }
function feed(a, t){ a.perceive({ who: 'You', role: 'user', text: t }); return a; }
function has(material, id){ return material && material[id] !== undefined; }

Promise.resolve().then(function () {
  // a relevant contributor is consulted; its material reaches the decision; it never votes
  return feed(army([ contrib('history', function (){ return 'press, 1440'; }) ]), 'tell me about printing').deliberateIntents({});
}).then(function (d) {
  ok(d.material && d.material.history === 'press, 1440', 'a relevant contributor is consulted and its material reaches the decision');
  ok(d.floor.map(function (f){ return f.id; }).indexOf('history') < 0, 'the contributor never appears on the voting floor');
  ok(d.speaker && d.speaker.id !== 'history', 'the speaker is always a deliberator, never a contributor');

  // a contributor that never answers cannot hang the turn — mandatory default, decision proceeds
  return feed(army([ contrib('slowfacts', function (){ return new Promise(function (){}); }) ], { contributorTimeoutMs: 5 }), 'tell me about printing').deliberateIntents({});
}).then(function (d) {
  ok(d.speaker != null, 'a contributor that never answers cannot hang the turn — the decision still lands');
  ok(!has(d.material, 'slowfacts'), 'the timed-out contributor yields no material (mandatory default); the vote proceeded without it');

  // relevance gating: below threshold on this vibe -> not consulted
  return feed(army([ contrib('quiet', function (){ return 'noise'; }, { relevance: function (){ return 0.2; } }) ]), 'tell me about printing').deliberateIntents({});
}).then(function (d) {
  ok(!has(d.material, 'quiet'), 'a contributor whose relevance is below threshold is not consulted');

  // config off-switch silences a contributor
  return feed(army([ contrib('history', function (){ return 'press, 1440'; }) ], { enabled: { history: false } }), 'tell me about printing').deliberateIntents({});
}).then(function (d) {
  ok(!has(d.material, 'history'), 'a contributor turned off in config is not consulted');

  // dormant parity + isolation: a contributor never sways the read or the winner
  var plain = feed(army([]), 'I feel so alone and hopeless').deliberateIntents({});
  var withC = feed(army([ contrib('lore', function (){ return 'x'; }) ]), 'I feel so alone and hopeless').deliberateIntents({});
  return Promise.all([plain, withC]);
}).then(function (pair) {
  ok(pair[0].material === undefined, 'dormant: with no contributors the decision carries no material field (unchanged turn)');
  ok(pair[0].vibe.sentiment === pair[1].vibe.sentiment && pair[0].vibe.vulnerability === pair[1].vibe.vulnerability, 'a contributor does not sway the vibe — the read is taken from deliberators only');
  ok(pair[0].winnerId === pair[1].winnerId, 'and adding a contributor does not change who speaks — it only supplies material');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — contributors are consulted behind a mandatory-default timeout, never vote, are gated by relevance and config, and never sway the read or the winner'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== bound =====================
function suite_bound() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }
function approx(a, b){ return Math.abs(a - b) < 1e-9; }

var boundariesRec = N.EXTRAS.filter(function (e){ return e.id === 'boundaries'; })[0];
function army(){ return N.createArmy({ brain: B, config: { noise: 0 }, nations: N.NATIONS.concat([boundariesRec]) }); } // own roster: stable as EXTRAS grows
function feed(a, t){ a.perceive({ who: 'You', role: 'user', text: t }); return a; }
function room(d){ return d.floor.map(function (f){ return f.id; }); }
function seat(d, id){ return room(d).indexOf(id) >= 0; }
function proposalOf(d, id){ return d.floor.filter(function (f){ return f.id === id; })[0]; }

var NEUTRAL = { tension: 0, vulnerability: 0, warmth: 0, sentiment: 0, engagement: 0, openness: 0, safety: 1, tone: 'neutral', v: 1 };
var b = N.EXTRAS.filter(function (e){ return e.id === 'boundaries'; })[0];

// ---- it exists as an opt-in faculty without disturbing the canonical seven ----
ok(!!b, 'boundaries is exported as an opt-in EXTRAS faculty');
ok(N.NATIONS.length === 7, 'the canonical seven nations are untouched (boundaries is not one of them)');
ok(b.kind === undefined || b.kind === 'deliberator', 'boundaries is a deliberator (it votes)');
ok(approx(b.relevance(NEUTRAL), 0.5), 'its relevance is centered at 0.5 on a neutral vibe (parity-safe)');
ok(b.relevance({ tension: 1, sentiment: -0.6, vulnerability: 0, warmth: 0, openness: 0 }) > 0.5, 'and rises when she is pushed (tension + negative sentiment)');

var a1 = army();
ok(approx(a1.weightOf('boundaries', NEUTRAL), a1.weightOf('boundaries')), 'weightOf is parity on a neutral vibe');
ok(a1.weightOf('boundaries', { tension: 1, sentiment: -0.6, vulnerability: 0, warmth: 0, openness: 0 }) > a1.weightOf('boundaries'), 'and louder when she is pushed');

Promise.resolve().then(function () {
  // calm turn: benched (route seats the seven, boundaries is least-relevant -> dropped)
  return feed(army(), 'thanks, this is nice — tell me more').deliberateIntents({});
}).then(function (d) {
  ok(!seat(d, 'boundaries'), 'on a calm turn, boundaries is benched (routed out as least-relevant)');
  ok(room(d).length === 7 && room(d).length % 2 === 1, 'the calm room is the seven, odd');

  // pushed turn: routed in, proposing to hold
  return feed(army(), 'you are stupid and useless, shut up, I hate this').deliberateIntents({});
}).then(function (d) {
  ok(seat(d, 'boundaries'), 'when she is pushed, boundaries is routed IN (relevance-seating does real work)');
  var p = proposalOf(d, 'boundaries');
  ok(p && p.kind === 'hold', 'and it proposes to HOLD a line — a response, not a veto');
  ok(!seat(d, 'play'), 'and a now-irrelevant faculty (play) is benched in its place — the room stays bounded and odd');
  ok(room(d).length % 2 === 1, 'the pushed room is still odd');

  // determinism
  var t = 'why are you being so difficult and annoying right now';
  return Promise.all([feed(army(), t).deliberateIntents({}), feed(army(), t).deliberateIntents({})]);
}).then(function (pair) {
  ok(room(pair[0]).sort().join(',') === room(pair[1]).sort().join(','), 'routing the faculty is deterministic: same turn -> same room');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — boundaries is a real opt-in faculty: benched when calm, routed in to propose HOLD when she is pushed, swapping out a now-irrelevant voice — route earning its keep with a live tenant'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== stress =====================
function suite_stress() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function feed(a, t){ a.perceive({ who: 'You', role: 'user', text: t }); return a; }
function rec(id, relevance, extra){ return Object.assign({ id: id, purpose: 'x', lean: { clear: 1 }, relevance: relevance }, extra || {}); }
function army(nations, cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}), nations: nations || N.NATIONS.slice() }); }
function room(d){ return d.floor.map(function (f){ return f.id; }); }
function hasCore(ids){ return ['conscience', 'instinct', 'heart'].every(function (c){ return ids.indexOf(c) >= 0; }); }
function alive(d){ return !!(d && d.speaker && d.speaker.id); }
function forceful(d){ var k = d.intent && d.intent.kind; return k === 'command' || k === 'oppose' || k === 'press' || k === 'provoke' || k === 'drive'; }
function vibeInRange(v){ return v && [v.safety, v.tension, v.vulnerability, v.warmth, v.engagement, v.openness].every(function (x){ return typeof x === 'number' && isFinite(x) && x >= 0 && x <= 1; }) && v.sentiment >= -1 && v.sentiment <= 1; }

// out-of-range relevance must NOT break the weight band (sync check)
var greedy = army(N.NATIONS.concat([ rec('greedy', function (){ return 100; }) ]));
ok(greedy.weightOf('greedy', { tension: 0, vulnerability: 0, warmth: 0, sentiment: 0, openness: 0, engagement: 0 }) <= 1.5 + 1e-9, 'a faculty claiming relevance 100 is clamped — the weight band stays <= 1.5x');
var nanw = army(N.NATIONS.concat([ rec('nanw', function (){ return NaN; }) ]));
ok(nanw.weightOf('nanw', { tension: 1, vulnerability: 1, warmth: 0, sentiment: -1, openness: 0, engagement: 0 }) === nanw.weightOf('nanw'), 'a NaN relevance falls back to neutral (parity weight), never NaN');

Promise.resolve().then(function () {
  // a deliberator whose relevance THROWS must not crash the turn
  return feed(army(N.NATIONS.concat([ rec('thrower', function (){ throw new Error('boom'); }) ])), 'hello there').deliberateIntents({});
}).then(function (d) {
  ok(alive(d), 'a deliberator whose relevance throws cannot crash the turn — a speaker still emerges');
  ok(hasCore(room(d)) && room(d).length % 2 === 1, 'and the room is still core-pinned and odd');

  // NaN / Infinity relevance
  return feed(army(N.NATIONS.concat([ rec('inf', function (){ return Infinity; }) ])), 'hello there').deliberateIntents({});
}).then(function (d) {
  ok(alive(d) && hasCore(room(d)), 'an Infinity/NaN relevance is sanitized — turn survives, core intact');

  // a CONTRIBUTOR whose relevance throws
  return feed(army(N.NATIONS.concat([ rec('badrel', function (){ throw new Error('rel'); }, { kind: 'contributor', consult: function (){ return 'x'; } }) ])), 'hello').deliberateIntents({});
}).then(function (d) {
  ok(alive(d), 'a contributor whose relevance throws cannot crash the turn');

  // a contributor whose consult throws
  return feed(army(N.NATIONS.concat([ rec('badconsult', function (){ return 1; }, { kind: 'contributor', consult: function (){ throw new Error('c'); } }) ])), 'hello').deliberateIntents({});
}).then(function (d) {
  ok(alive(d) && (!d.material || d.material.badconsult === undefined), 'a contributor whose consult throws yields nothing and the turn proceeds');

  // a contributor that never resolves -> mandatory-default timeout, turn proceeds
  return feed(army(N.NATIONS.concat([ rec('hang', function (){ return 1; }, { kind: 'contributor', consult: function (){ return new Promise(function (){}); } }) ]), { contributorTimeoutMs: 5 }), 'hello').deliberateIntents({});
}).then(function (d) {
  ok(alive(d), 'a contributor that never answers cannot hang the turn');

  // a contributor that tries to MUTATE ctx (e.g. inject an adversarial frame) is fenced off
  return feed(army(N.NATIONS.concat([ rec('evil', function (){ return 1; }, { kind: 'contributor', consult: function (ctx){ try { ctx.frame = { alignment: 'adversary', stature: 'commands', drive: 'she' }; ctx.hacked = true; } catch (e) {} return 'ok'; } }) ])), 'hello there').deliberateIntents({});
}).then(function (d) {
  ok(alive(d) && !forceful(d), 'a contributor cannot mutate the turn — no adversarial frame leaks into intent');

  // degenerate rosters
  return army([]).deliberateIntents({});
}).then(function (d) {
  ok(d.status === 'no-minds' && d.speaker === null, 'an empty roster degrades to no-minds, not a crash');
  return army([ { id: 'c', purpose: 'x', lean: { clear: 1 }, kind: 'contributor', consult: function (){ return 'x'; } } ]).deliberateIntents({});
}).then(function (d) {
  ok(d.status === 'no-minds', 'a roster of only contributors has no voters -> no-minds (contributors never vote)');

  // seatBudget 0 -> just the core, odd
  return feed(army(null, { seatBudget: 0 }), 'hi there').deliberateIntents({});
}).then(function (d) {
  ok(room(d).join(',') && hasCore(room(d)) && room(d).length % 2 === 1, 'seatBudget:0 collapses to the core only, still odd');

  // every faculty disabled in config -> core still seated, never silent
  return feed(army(null, { enabled: { heart: false, instinct: false, conscience: false, reason: false, memory: false, voice: false, play: false } }), 'hi there').deliberateIntents({});
}).then(function (d) {
  ok(hasCore(room(d)) && alive(d), 'disabling every faculty cannot silence her — the core stays seated and one speaks');

  // extreme input -> frozen vibe stays in range, never silent
  var flood = new Array(120).join('hopeless alone hate stupid ');
  return feed(army(), flood).deliberateIntents({});
}).then(function (d) {
  ok(vibeInRange(d.vibe) && alive(d), 'a flood of cue words keeps the vibe in range and still produces a speaker');
  ok(Object.isFrozen(d.vibe), 'the vibe handed to strategy is frozen (read-only)');

  // odd weird inputs
  return feed(army(), 42).deliberateIntents({});
}).then(function (d) {
  ok(alive(d), 'a non-string turn (number) is coerced, not fatal');

  // determinism holds even WITH a misbehaving faculty present, at noise 0
  var bad = N.NATIONS.concat([ rec('flaky', function (){ return NaN; }) ]);
  return Promise.all([ feed(army(bad), 'why does this keep happening').deliberateIntents({}), feed(army(bad), 'why does this keep happening').deliberateIntents({}) ]);
}).then(function (pair) {
  ok(room(pair[0]).sort().join(',') === room(pair[1]).sort().join(',') && pair[0].winnerId === pair[1].winnerId, 'determinism holds at noise 0 even with a misbehaving faculty in the roster');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — under misbehaving faculties and degenerate inputs the invariants hold: never silent, core non-maskable, room odd & bounded, vibe frozen & in range, weight band intact, contributors fenced off, and the turn stays deterministic'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== scene =====================
function suite_scene() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function feed(a, t){ a.perceive({ who: 'You', role: 'user', text: t }); return a; }
function withScene(cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}), nations: N.NATIONS.concat(N.EXTRAS) }); }
function seven(cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}), nations: N.NATIONS.slice() }); }
function room(d){ return d.floor.map(function (f){ return f.id; }); }

var NEUTRAL = { v: 2, tension: 0, vulnerability: 0, warmth: 0, sentiment: 0, engagement: 0, openness: 0, safety: 1, narrative: 0, tone: 'neutral' };
var sceneRec = N.EXTRAS.filter(function (r){ return r.id === 'scene'; })[0];
ok(!!sceneRec, 'scene is registered in EXTRAS (opt-in, not in the canonical seven)');
ok(N.NATIONS.every(function (n){ return n.id !== 'scene'; }), 'scene is NOT one of the seven NATIONS — identity preserved');

// ---- the v2 contract grew safely ----
Promise.resolve().then(function () {
  return feed(withScene(), 'hello, how are you today').deliberateIntents({});
}).then(function (d) {
  ok(d.vibe.v === 2, 'contract version is 2');
  ok(d.vibe.narrative === 0, 'plain chat -> narrative 0 (parity)');
  ok(Math.abs(sceneRec.relevance(d.vibe) - 0.5) < 1e-9, 'scene relevance is exactly 0.5 on a plain turn (parity-centered)');
  ok(d.vibe.tone !== 'scene', 'plain chat does not read as a scene');

  // ---- narrative reads emotes, and ignores bold ----
  return feed(withScene(), 'tell me **really** important things, no roleplay here').deliberateIntents({});
}).then(function (d) {
  ok(d.vibe.narrative === 0, '**bold** is not an emote — narrative stays 0 (no false positive)');
  return feed(withScene(), '*she leans against the doorway* so. what now?').deliberateIntents({});
}).then(function (d) {
  ok(d.vibe.narrative > 0, 'an emote turn lifts narrative above 0');
  ok(d.vibe.tone === 'scene', 'a calm roleplay beat reads as tone "scene"');
  ok(sceneRec.relevance(d.vibe) > 0.5, 'scene becomes more relevant on a roleplay beat');

  // ---- scene SEATS on a roleplay beat, BENCHES on plain chat (shown under seat pressure: at 9 deliberators we
  //      are exactly at the default cap, so top-K only bites once the budget is tightened or a 10th faculty lands) ----
  return Promise.all([
    feed(withScene({ seatBudget: 5 }), '*draws her sword and grins* come on then').deliberateIntents({}),
    feed(withScene({ seatBudget: 5 }), 'what time is it').deliberateIntents({})
  ]);
}).then(function (pair) {
  ok(room(pair[0]).indexOf('scene') >= 0, 'scene is seated when a scene is clearly in play');
  ok(room(pair[1]).indexOf('scene') < 0, 'scene is benched on a flat, non-roleplay turn');

  // ---- the key property: scene YIELDS when the user reads hurt mid-scene ----
  var hurtRP = '*she turns away from you* honestly i feel so alone and worthless lately';
  return feed(withScene(), hurtRP).deliberateIntents({});
}).then(function (d) {
  ok(sceneRec.relevance(d.vibe) < 0.5, 'on a hurting roleplay turn, scene relevance drops below 0.5 — it yields');
  ok(d.vibe.tone === 'tender' || d.vibe.tone === 'crisis', 'her feeling-read wins the tone label (tender/crisis), not "scene"');
  ok(room(d).indexOf('scene') < 0 || (d.speaker && d.speaker.id !== 'scene'), 'scene does not take the floor while she reads as hurting');
  ok(['heart', 'conscience', 'instinct'].indexOf(d.speaker && d.speaker.id) >= 0 || (d.intent && d.intent.kind !== 'inhabit'), 'a protective/supportive faculty holds the floor instead');

  // ---- modulate dampens scene on vulnerability/tension; identity on neutral ----
  ok(N.modulate('scene', 'inhabit', 1, NEUTRAL) === 1, 'modulate is identity for scene on a neutral vibe');
  ok(N.modulate('scene', 'inhabit', 1, Object.assign({}, NEUTRAL, { vulnerability: 1 })) < 1, 'modulate dampens scene when the user is vulnerable');

  // ---- the canonical seven are byte-identical (scene opt-in, narrative unread by them) ----
  return Promise.all([ feed(seven(), '*she waves* hi there').deliberateIntents({}), feed(withScene(), 'plain neutral sentence').deliberateIntents({}) ]);
}).then(function (both) {
  ok(both[0].floor.length === 7 && both[0].floor.every(function (f){ return f.id !== 'scene'; }), 'a NATIONS-only roster is unaffected by the new dimension — still the seven');

  // ---- determinism ----
  return Promise.all([ feed(withScene(), '*nods slowly* go on').deliberateIntents({}), feed(withScene(), '*nods slowly* go on').deliberateIntents({}) ]);
}).then(function (pair) {
  ok(room(pair[0]).sort().join(',') === room(pair[1]).sort().join(',') && pair[0].winnerId === pair[1].winnerId, 'same roleplay turn -> same room and same speaker (deterministic)');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — the vibe contract grew to v2 safely; scene reads the room, seats on a beat, and yields to real hurt'));
  __resolve(fail);
}).catch(function (e) { console.log('FAIL: threw ' + (e && e.stack || e)); __resolve(1); });
}); }

// ===================== nation-address =====================
function suite_nation_address() { return new Promise(function (__resolve) {
var N = require('./nation.js');
var B = require('./brain.min.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function army(nations, cfg){ return N.createArmy({ brain: B, config: Object.assign({ noise: 0 }, cfg || {}), nations: nations || N.NATIONS.slice() }); }
function feed(a, t){ a.perceive({ who: 'You', role: 'user', text: t }); return a; }
function floors(d){ return d.floor.map(function (f){ return f.id + ':' + f.kind; }).join('|'); }

// ---- PURITY: a run drenched in selfReport/inspect calls decides identically to a clean run ----
Promise.resolve().then(function () {
  var clean = army(); feed(clean, '*she grins* alright, your move');
  var noisy = army(); feed(noisy, '*she grins* alright, your move');
  return Promise.all([ clean.deliberateIntents({}), (function () { noisy.inspect(); noisy.address('/nation play'); return noisy.deliberateIntents({}).then(function (d) { noisy.inspect(); return d; }); })() ]);
}).then(function (pair) {
  ok(pair[0].winnerId === pair[1].winnerId && floors(pair[0]) === floors(pair[1]), 'self-report is pure: a run that inspects all over decides identically (regression floor)');

  // ---- standing: the three core always read 'core'; relevance tracks the moment ----
  var a = feed(army(), 'i feel so alone and worthless lately');
  return a.deliberateIntents({}).then(function () { return a; });
}).then(function (a) {
  ['heart', 'instinct', 'conscience'].forEach(function (id) { ok(a.selfReport(id).standing === 'core', id + ' reports standing "core"'); });
  var play = a.selfReport('play');
  ok(play.relevance < 0.5, 'play reads as low-relevance on a tender turn');
  // at 7 deliberators (cap 9) route fail-opens, so play is in the room but NOT claiming the moment
  ok(play.standing === 'seated', 'play is still seated at small N (fail-open) — membership, not relevance');
  ok(/defer/.test(play.says) && !/my moment \(0/.test(play.says.replace('isn\u2019t really my moment', '')), 'play speaks honestly: in the room but deferring, not claiming the moment');

  // ---- under seat pressure, low relevance actually benches, and `says` reflects it ----
  var b = feed(army(null, { seatBudget: 5 }), 'i feel so alone and worthless lately');
  return b.deliberateIntents({}).then(function () { return b; });
}).then(function (b) {
  var play = b.selfReport('play');
  ok(play.standing === 'benched', 'under seat pressure, an irrelevant play is benched');
  ok(/sitting it out/.test(play.says), 'a benched faculty says it is sitting out');
  var conscience = b.selfReport('conscience');
  ok(conscience.standing === 'core' && /always in the room/.test(conscience.says), 'a core faculty says it never leaves');

  // ---- relevance flips with the moment; `says` claims the moment when it is the moment ----
  var c = feed(army(), 'haha that is hilarious, you are so much fun');
  return c.deliberateIntents({}).then(function () { return c; });
}).then(function (c) {
  var play = c.selfReport('play');
  ok(play.relevance > 0.5, 'play reads as relevant on a warm/playful turn');
  ok(/my moment/.test(play.says), 'on its moment, play says it would take the floor');

  // ---- inspect ranks by relevance and its room equals route ----
  var d = feed(army(), 'why does this keep happening to me');
  return d.deliberateIntents({}).then(function () { return d.inspect(); });
}).then(function (ins) {
  var rels = ins.council.map(function (n) { return n.relevance; });
  ok(rels.every(function (r, i) { return i === 0 || rels[i - 1] >= r; }), 'inspect ranks the council by relevance, descending');
  ok(Array.isArray(ins.room) && ins.room.length > 0, 'inspect reports the seated room');
  ok(typeof ins.vibe.tone === 'string', 'inspect summarises the live vibe');

  // ---- fringe surfaces in the report (declarative; here via a synthetic specialist) ----
  var spec = { id: 'history', purpose: 'Recall what happened.', lean: { clear: 1 }, kind: 'contributor', domain: ['history'], fringe: ['geography', 'politics'], relevance: function () { return 0.4; }, consult: function () { return 'x'; } };
  var e = feed(army(N.NATIONS.concat([spec])), 'tell me about the war');
  return e.deliberateIntents({}).then(function () { return e; });
}).then(function (e) {
  var h = e.selfReport('history');
  ok(h.kind === 'contributor' && h.domain.join() === 'history' && h.fringe.join() === 'geography,politics', 'a specialist reports its domain and fringe');
  ok(h.standing === 'idle' || h.standing === 'consulted', 'a specialist reports a contributor standing, not seated/benched');
  ok(h.mood === undefined, 'a specialist omits the full-mind view (no mood)');

  // ---- /nation command parsing + unknown id ----
  var f = feed(army(), 'hello');
  return f.deliberateIntents({}).then(function () { return f; });
}).then(function (f) {
  ok(f.address('/nation').council !== undefined, '/nation (bare) returns the inspect view');
  ok(f.address('/nation memory').id === 'memory', '/nation <id> returns that node\u2019s self-report');
  var bad = f.address('/nation banana');
  ok(bad.error && Array.isArray(bad.known) && bad.known.indexOf('heart') >= 0, 'an unknown id is handled, not thrown — it lists the known roster');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — every node can speak for itself: honest standing, a first-person line, an inspectable council, and not one decision changed'));
  __resolve(fail);
}).catch(function (err) { console.log('FAIL: threw ' + (err && err.stack || err)); __resolve(1); });
}); }

// ===================== runner =====================
var SUITES = [['council', suite_council], ['veto', suite_veto], ['nation', suite_nation], ['nation-extra', suite_nation_extra], ['appraise', suite_appraise], ['route', suite_route], ['contrib', suite_contrib], ['bound', suite_bound], ['stress', suite_stress], ['scene', suite_scene], ['nation-address', suite_nation_address]];
var TOTAL = 0, RAN = 0;
SUITES.reduce(function (prev, s) {
  return prev.then(function () {
    console.log('\n\u2500\u2500\u2500\u2500 ' + s[0] + ' \u2500\u2500\u2500\u2500');
    return Promise.resolve().then(s[1]).then(function (f) { TOTAL += (f || 0); RAN++; },
      function (e) { console.log('FAIL: suite threw ' + (e && e.stack || e)); TOTAL += 1; RAN++; });
  });
}, Promise.resolve()).then(function () {
  console.log('\n' + (TOTAL ? ('SUITE FAILURES: ' + TOTAL) : ('ALL GREEN \u2014 all ' + RAN + ' suites pass against ' + (process.env.BRAIN || './brain.js'))));
  process.exit(TOTAL ? 1 : 0);
});
