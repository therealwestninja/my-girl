/* chloe-brain — the pure Brain (nervous system + Society deliberation), the editable source for
 * brain.min.js. DOM-free, network-free, deterministic. The mouth (engine.js) keeps memory and
 * personality; this is only the reasoning. API: createNervous, resolve, member, createCouncil, withTimeout. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api; // Node / harness
  root.ChloeBrain = api; root.ChloeCouncil = api;                            // window / app
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // ---- nervous system: a registry + synapse bus + lifecycle (shared by the Society's member-Brains) ----
    function makeNervous(log) {
      log = log || function () {};
      var neurons = {};   // id -> { id, kind, role, does[], state, ready, __ready, _inbox, _ask }
      var topics = {};    // topic -> [fn]
      function register(m) {
        if (!m || !m.id) return null;
        var rec = neurons[m.id] || {};
        rec.id = String(m.id);
        rec.kind = m.kind || rec.kind || 'process';            // provider | store | process | organ | brain
        rec.role = m.role != null ? m.role : (rec.role || '');
        rec.does = Array.isArray(m.does) ? m.does : (rec.does || []);
        rec.state = m.state || rec.state || 'active';          // active | standby | asleep
        if (typeof m.onSend === 'function') rec._inbox = m.onSend;
        if (typeof m.onAsk === 'function') rec._ask = m.onAsk;
        if (m.ready && typeof m.ready.then === 'function') {   // async organ readiness (the honest handshake)
          rec.ready = m.ready; rec.__ready = null;
          m.ready.then(function (v) { rec.__ready = (v !== false); }, function () { rec.__ready = false; });
        }
        neurons[rec.id] = rec;
        return rec;
      }
      function list() { return Object.keys(neurons).map(function (id) { var n = neurons[id]; return { id: n.id, kind: n.kind, role: n.role, state: n.state }; }); }
      function describe(id) { var n = neurons[id]; return n ? { id: n.id, kind: n.kind, role: n.role, state: n.state, does: (n.does || []).slice() } : null; }
      function find(cap) { cap = String(cap || '').toLowerCase(); return Object.keys(neurons).filter(function (id) { return (neurons[id].does || []).some(function (d) { return String(d.name || '').toLowerCase() === cap; }); }); }
      function setState(id, s) { var n = neurons[id]; if (n) n.state = s; return !!n; }
      function send(to, msg) { var n = neurons[to]; if (n && n._inbox) { try { n._inbox(msg); return true; } catch (e) { log('[nervous] send->' + to + ': ' + (e && e.message)); } } return false; }
      function ask(to, msg) { var n = neurons[to]; if (n && n._ask) { try { return Promise.resolve(n._ask(msg)); } catch (e) { return Promise.reject(e); } } return Promise.resolve(null); }
      function publish(topic, payload) { var hit = 0; (topics[topic] || []).slice().forEach(function (fn) { try { fn(payload); hit++; } catch (e) { log('[nervous] ' + topic + ' subscriber threw: ' + (e && e.message)); } }); return hit; }
      function subscribe(topic, fn) { (topics[topic] = topics[topic] || []).push(fn); return function () { topics[topic] = (topics[topic] || []).filter(function (f) { return f !== fn; }); }; }
      function health(id) {
        var n = neurons[id]; if (!n) return 'absent';
        if (n.ready) return n.__ready === true ? 'ready' : (n.__ready === false ? 'degraded' : 'pending');
        return n.state;   // pure neurons: their lifecycle state IS their health
      }
      return { register: register, list: list, describe: describe, find: find, setState: setState,
        wake: function (id) { return setState(id, 'active'); }, sleep: function (id) { return setState(id, 'asleep'); },
        standby: function (id) { return setState(id, 'standby'); },
        send: send, ask: ask, publish: publish, subscribe: subscribe, health: health };
    }

  // ---- the pure heart: proposals + a vote matrix + vetoes -> a decision. Fully deterministic. ----
  // proposals: [{ by, text, conf }]                      one nomination per member (abstain = omitted)
  // ballots:   [{ voter, scores: { <proposalBy>: num } }] each member scores the others' proposals (~[0,1])
  // vetoes:    [{ by, against, reason }]                  a member blocks a proposal
  // opts:      { allowSelfVote=false, vetoQuorum=1, consensusMargin=0 }
  function resolve(proposals, ballots, vetoes, opts) {
    opts = opts || {};
    proposals = (proposals || []).filter(function (p) { return p && p.by != null; });
    var seenBy = {}; proposals = proposals.filter(function (p) { if (seenBy[p.by]) return false; seenBy[p.by] = true; return true; });
    ballots = ballots || []; vetoes = vetoes || [];
    var allowSelf = !!opts.allowSelfVote, vetoQuorum = (opts.vetoQuorum != null) ? opts.vetoQuorum : 1;

    var vetoCount = {}, vetoReasons = {};
    vetoes.forEach(function (v) {
      if (!v || v.against == null) return;
      vetoCount[v.against] = (vetoCount[v.against] || 0) + 1;
      (vetoReasons[v.against] = vetoReasons[v.against] || []).push({ by: v.by, reason: v.reason || '' });
    });
    function isVetoed(by) { return (vetoCount[by] || 0) >= vetoQuorum; }

    var eligible = proposals.filter(function (p) { return !isVetoed(p.by); });
    var contested = false;
    if (!eligible.length && proposals.length) { eligible = proposals.slice(); contested = true; }  // all blocked -> contest, never crash

    var tally = {}, voterTop = {};
    eligible.forEach(function (p) { tally[p.by] = 0; });
    ballots.forEach(function (b) {
      if (!b || !b.scores) return;
      var best = null, bestS = -Infinity;
      eligible.forEach(function (p) {
        if (!allowSelf && b.voter === p.by) return;        // no self-voting by default
        var s = Number(b.scores[p.by]); if (!isFinite(s)) return;
        tally[p.by] += s;
        if (s > bestS) { bestS = s; best = p.by; }
      });
      if (best != null) voterTop[b.voter] = best;
    });

    var order = {}, conf = {};
    eligible.forEach(function (p, i) { order[p.by] = i; conf[p.by] = Number(p.conf) || 0; });
    var ranked = eligible.slice().sort(function (a, b) {
      if (tally[b.by] !== tally[a.by]) return tally[b.by] - tally[a.by];   // most votes
      if (conf[b.by] !== conf[a.by]) return conf[b.by] - conf[a.by];       // then confidence
      return order[a.by] - order[b.by];                                    // then nomination order (stable)
    });
    var winner = ranked[0] || null, runnerUp = ranked[1] || null;
    var margin = winner ? (tally[winner.by] - (runnerUp ? tally[runnerUp.by] : 0)) : 0;

    var voters = Object.keys(voterTop);
    var judging = voters.filter(function (v) { return allowSelf || !winner || v !== winner.by; });   // the proposer is excluded from the consensus check — unless self-voting was explicitly allowed, then its vote counts here too
    var agreed = !!winner && judging.length > 0 && judging.every(function (v) { return voterTop[v] === winner.by; });
    var dissent = winner ? judging.filter(function (v) { return voterTop[v] !== winner.by; }) : [];

    var status = !winner ? 'no-proposals'
               : contested ? 'contested'
               : agreed ? 'agreed'
               : (margin <= (opts.consensusMargin || 0) ? 'tie-resolved' : 'carried');

    return {
      winnerId: winner ? winner.by : null,
      text: winner ? winner.text : null,
      status: status,
      tally: tally,
      margin: margin,
      consensus: !!agreed,
      dissent: dissent,
      vetoed: Object.keys(vetoCount).filter(isVetoed),
      vetoReasons: vetoReasons
    };
  }

  // ---- a member-Brain: id + role + injected effects. Pure-by-default behaviour. -------------------
  function member(id, role, fx) {
    fx = fx || {};
    return {
      id: String(id), role: role || '',
      propose: function (ctx) { return Promise.resolve(fx.propose ? fx.propose(ctx) : null); },
      vote:    function (p, ctx) { return Promise.resolve(fx.vote ? fx.vote(p, ctx) : ((p && Number(p.conf)) || 0)); },
      veto:    function (p, ctx) { return Promise.resolve(fx.veto ? fx.veto(p, ctx) : { veto: false }); }
    };
  }

  // ---- timeout helper: race a member's reply against a clock so a stalled mind can't freeze the round. ----
  // Injected scheduler (sched.set/clear) + `now` keep this pure-testable. Returns { __timeout, value }.
  function withTimeout(p, ms, fallback, sched) {
    if (!ms || ms <= 0) return Promise.resolve(p).then(function (v) { return { __timeout: false, value: v }; }, function () { return { __timeout: false, value: fallback }; });
    return new Promise(function (resolve) {
      var done = false;
      var t = sched.set(function () { if (!done) { done = true; resolve({ __timeout: true, value: fallback }); } }, ms);
      Promise.resolve(p).then(function (v) { if (!done) { done = true; sched.clear(t); resolve({ __timeout: false, value: v }); } },
                              function () { if (!done) { done = true; sched.clear(t); resolve({ __timeout: false, value: fallback }); } });
    });
  }

  // ---- the Society: an (odd) body of member-Brains. They register, propose, and ALWAYS vote — a stalled or
  //      sleeping member is timed out to a default vote (never an abstention) and reawakened by the watchdog
  //      before the next round. Perchance is just the mouth at the edge. ----
  // deps: { members, nervous?, opts?, timeoutMs?, idleMs?, sched?, now?, log? }
  function createCouncil(deps) {
    deps = deps || {};
    var members = deps.members || [];
    var nervous = deps.nervous || null;
    var opts = deps.opts || {};
    var timeoutMs = deps.timeoutMs || 0;
    var idleMs = deps.idleMs || 0;
    var log = deps.log || function () {};
    var now = deps.now || function () { return Date.now(); };
    var sched = deps.sched || { set: function (fn, ms) { return setTimeout(fn, ms); }, clear: function (t) { clearTimeout(t); } };
    var DEFAULT_SCORE = (opts.defaultScore != null) ? opts.defaultScore : 0;
    var lastSeen = {};

    if (members.length % 2 === 0) log('[society] even membership (' + members.length + ') — keep it odd so votes never split');

    function registerMember(m) {           // every member identifies + registers; never optional
      if (nervous) nervous.register({ id: m.id, kind: 'brain', role: m.role,
        does: [ { name: 'propose', how: "ask(id,{type:'propose',ctx})" },
                { name: 'vote',    how: "ask(id,{type:'vote',proposal,ctx})" },
                { name: 'veto',    how: "ask(id,{type:'veto',proposal,ctx})" } ],
        onAsk: function (msg) {
          if (!msg) return null;
          if (msg.type === 'propose') return m.propose(msg.ctx);
          if (msg.type === 'vote') return m.vote(msg.proposal, msg.ctx);
          if (msg.type === 'veto') return m.veto(msg.proposal, msg.ctx);
          return null;
        } });
      lastSeen[m.id] = now();
    }
    members.forEach(registerMember);

    // watchdog: any member idle/asleep too long (or somehow unregistered) is reawakened to register & work again.
    function wakeStalled() {
      var woke = [];
      members.forEach(function (m) {
        var h = nervous ? nervous.health(m.id) : 'active';
        var stale = idleMs && (now() - (lastSeen[m.id] || 0) > idleMs);
        if (h === 'absent') registerMember(m);                 // re-identify / re-register
        if (h === 'absent' || h === 'asleep' || stale) { if (nervous) nervous.wake(m.id); lastSeen[m.id] = now(); woke.push(m.id); }
      });
      return woke;
    }

    function reach(m, type, proposal, ctx, fallback, deadSet) {         // bus (proves the protocol) or direct; always times out cleanly
      if (deadSet && deadSet[m.id]) return Promise.resolve(fallback);    // already stalled this turn — don't pay its timeout again
      var call = nervous ? Promise.resolve(nervous.ask(m.id, { type: type, proposal: proposal, ctx: ctx }))
                         : Promise.resolve(type === 'propose' ? m.propose(ctx) : type === 'vote' ? m.vote(proposal, ctx) : m.veto(proposal, ctx));
      return withTimeout(call, timeoutMs, fallback, sched).then(function (res) {
        if (res.__timeout) { if (nervous) nervous.sleep(m.id); if (deadSet) deadSet[m.id] = true; }   // it stalled — mark asleep; watchdog wakes it next round
        else lastSeen[m.id] = now();
        return res.value;
      });
    }

    // one round. `seed` (optional) supplies candidate proposals the whole Society votes on (a few voices
    // propose; the many decide) — the faithful emotion-council shape. Members may also propose.
    function deliberate(ctx, seed) {
      wakeStalled();                                          // start every round by reawakening anyone who drifted off
      var dead = {};                                          // members that stalled this turn — skip them in later phases
      return Promise.all(members.map(function (m) {           // 1. NOMINATE (best-effort; text can't be forced)
        return reach(m, 'propose', null, ctx, null, dead).then(function (r) { return { by: m.id, r: r }; });
      })).then(function (props) {
        var proposals = (seed || []).slice().concat(props.map(function (x) { var r = x.r; return (r && r.text != null) ? { by: x.by, text: String(r.text), conf: Number(r.conf) || 0 } : null; }).filter(Boolean));
        if (!proposals.length) return { status: 'no-proposals', text: null, winnerId: null, transcript: { proposals: [], ballots: [], vetoes: [] }, participation: members.map(function (m) { return m.id; }) };

        var ballots = [], vetoes = [];
        var votePs = members.map(function (m) {               // 2. CROSS-VOTE — MANDATORY: a timeout yields a default score, never an absence
          var scores = {};
          return Promise.all(proposals.map(function (p) {
            return reach(m, 'vote', p, ctx, DEFAULT_SCORE, dead).then(function (s) { scores[p.by] = (typeof s === 'number' && isFinite(s)) ? s : DEFAULT_SCORE; });
          })).then(function () { ballots.push({ voter: m.id, scores: scores }); });
        });
        var vetoPs = members.map(function (m) {               // 3. VETO
          return Promise.all(proposals.map(function (p) {
            return reach(m, 'veto', p, ctx, { veto: false }, dead).then(function (vr) { if (vr && vr.veto) vetoes.push({ by: m.id, against: p.by, reason: vr.reason || '' }); });
          }));
        });

        return Promise.all(votePs.concat(vetoPs)).then(function () {
          var decision = resolve(proposals, ballots, vetoes, opts);   // 4. RESOLVE (pure)
          decision.transcript = { proposals: proposals, ballots: ballots, vetoes: vetoes };
          decision.participation = ballots.map(function (b) { return b.voter; });   // proof every member voted
          return decision;
        });
      });
    }

    return { deliberate: deliberate, resolve: resolve, members: members, nervous: nervous, wakeStalled: wakeStalled, size: members.length };
  }

  return { createNervous: makeNervous, resolve: resolve, member: member, createCouncil: createCouncil, withTimeout: withTimeout };
});
