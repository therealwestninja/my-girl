/* chloe-nation — the Seven Nations: the top, human-readable brain layer.
 *
 * Seven small faculties of mind each weigh in on what to say. Their votes are tallied by the weights you set,
 * using the same Brain sub-system underneath (ChloeBrain.resolve), and the winning reply is spoken. Seven, so a
 * vote can never tie. This layer is deliberately simple and readable — it sits ABOVE the compiled brain.min.js,
 * while the memory and personality underneath stay with the mouth.
 *
 * It knows what it is and never refuses to say so: ask it and it volunteers (see `about`).
 */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api; // Node / harness
  root.ChloeNation = api;                                                    // window / app
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // The seven nations. Each has a plain-English purpose and a "lean" — what it values in a reply.
  // lean features:  warm (sounds caring) · clear (a readable, sane length) · open (ends on a real question)
  //                 play (a little voice / action) · calm (not over-long, not frantic)
  // The seven seed faculties. Routing/scale metadata (DESIGN-routing-layer.md): `core` = non-routable floor;
  // `domain` = experiential domain (the registry index key); `relevance(vibe)` = pure [0,1], CENTERED AT 0.5 on a
  // neutral vibe so weighting is parity-safe. `kind` defaults to 'deliberator' (these seven all vote).
  var NATIONS = [
    { id: 'heart',      purpose: 'Make sure she sounds like she cares.',            lean: { warm: 1.0, clear: 0.3 },
      core: true,  domain: ['support'],
      relevance: function (v) { return clamp01(0.5 + v.vulnerability * 0.4 + v.warmth * 0.2); } },
    { id: 'reason',     purpose: 'Keep it clear, honest, and easy to follow.',      lean: { clear: 1.0, calm: 0.4 },
      domain: ['support', 'meta'],
      relevance: function (v) { return clamp01(0.5 + v.openness * 0.4 + v.tension * 0.1); } },
    { id: 'memory',     purpose: 'Keep her consistent with what she knows of you.', lean: { warm: 0.5, clear: 0.5 },
      domain: ['lore'],
      relevance: function (v) { return clamp01(0.5 + v.engagement * 0.2 - v.tension * 0.1); } },
    { id: 'instinct',   purpose: 'Flag anything that feels off, unsafe, or false.', lean: { calm: 1.0, clear: 0.3 },
      core: true,  domain: ['support'],
      relevance: function (v) { return clamp01(0.5 + v.tension * 0.5 + v.vulnerability * 0.2); } },
    { id: 'voice',      purpose: 'Keep her voice distinct and natural.',            lean: { play: 1.0, warm: 0.3 },
      domain: ['roleplay', 'banter'],
      relevance: function (v) { return clamp01(0.5 + v.warmth * 0.2 + v.openness * 0.1 - v.vulnerability * 0.2); } },
    { id: 'conscience', purpose: 'Protect your wellbeing, above all.',              lean: { warm: 0.7, calm: 0.6 },
      core: true,  domain: ['support'],
      relevance: function (v) { return clamp01(0.5 + v.vulnerability * 0.5 + v.tension * 0.2); } },
    { id: 'play',       purpose: 'Keep it alive, curious, and human.',              lean: { open: 1.0, play: 0.5 },
      domain: ['banter', 'roleplay'],
      relevance: function (v) { return clamp01(0.5 + (v.warmth + v.openness) * 0.4 - (v.vulnerability + v.tension) * 0.6); } }
  ];

  // Opt-in faculties beyond the canonical seven (DESIGN-routing-layer.md). NOT part of "the seven nations" identity;
  // a roster includes them explicitly via `nations: NATIONS.concat(EXTRAS)`. The first real specialized deliberator
  // is `boundaries`: it proposes holding a steady, kind line, and routes in only when she's pushed (tension /
  // negative sentiment), benched when things are calm. Distinct from the guards — it PROPOSES, it does not veto.
  var EXTRAS = [
    { id: 'boundaries', purpose: 'Hold a steady, kind line when you push or test it.', lean: { calm: 1.0, clear: 0.5 },
      domain: ['support'],
      relevance: function (v) { return clamp01(0.5 + v.tension * 0.5 + neg(v.sentiment) * 0.3); } },
    // `scene` is the first member built on the v2 contract: a roleplay deliberator. It proposes `inhabit` (stay
    // in-character, advance the beat), routes in as the `narrative` dimension rises, and YIELDS as the user reads
    // hurt or hostile — so the protective core takes the floor mid-scene. Pairs (later) with a `lore`/`continuity`
    // CONTRIBUTOR on the other tier; the deliberator set for roleplay is otherwise covered by voice + play.
    { id: 'scene', purpose: 'Hold and advance the roleplay — keep the scene coherent and alive.', lean: { open: 0.6, play: 0.4 },
      domain: ['roleplay', 'scene'],
      relevance: function (v) { return clamp01(0.5 + v.narrative * 0.5 + v.openness * 0.1 - v.vulnerability * 0.6 - v.tension * 0.4); } }
  ];

  // Pure: read one reply through a nation's lean and return a score. Simple and inspectable on purpose.
  function gauge(text, lean) {
    var t = String(text || '').trim(), len = t.length;
    var f = {
      warm:  Math.min(1, (t.match(/\b(here|with you|understand|sorry|glad|proud|care|okay|together|listening)\b/gi) || []).length / 3),
      clear: len < 8 ? 0 : (len > 600 ? 0.3 : Math.min(1, 0.4 + Math.min(len, 240) / 240 * 0.6)),
      open:  (function () { var s = String(t).replace(/\*[^*]+\*/g, ' '); return /\?[^\w]*$/.test(s) ? 1 : 0; })(),
      play:  (function () { var s = String(t).replace(/\*\*[^*]+\*\*/g, ' '); return /\*[^*]+\*/.test(s) ? 1 : 0; })(),
      calm:  len > 600 ? 0.2 : (len < 8 ? 0.3 : 1)
    };
    var s = 0; for (var k in lean) s += (lean[k] || 0) * (f[k] || 0);
    return s;
  }

  // ---- a small, pure sentiment/cue reader — no model needed, just a quick read of a line ----
  var CUES = {
    warmth:   /\b(care|love|here|with you|thank|thanks|glad|sorry|okay|proud|hug|miss you|appreciate)\b/gi,
    distress: /\b(sad|hurt|alone|lonely|scared|afraid|anxious|tired|exhausted|can'?t|hate|awful|cry|crying|lost|empty|worthless|hopeless)\b/gi,
    humor:    /\b(lol|lmao|haha+|hah|funny|joke|kidding|teasing|silly)\b|:\)|:d|\bxd\b/gi,
    anger:    /\b(angry|mad|furious|stupid|shut up|annoying|annoyed|hell|damn|ugh)\b/gi
  };
  function read(text) {
    var t = String(text || ''); function c(re) { var m = t.match(re); return m ? m.length : 0; }
    return { warmth: c(CUES.warmth), distress: c(CUES.distress), humor: c(CUES.humor) + (/!/.test(t) ? 0.4 : 0), anger: c(CUES.anger), question: /\?/.test(t) ? 1 : 0, len: t.trim().length };
  }
  // each nation's temperament — how cues land for it (+pleased / -troubled). This is its personality of feeling.
  var TEMPER = {
    heart:      { warmth: 1.0, distress: -0.6, anger: -0.4, humor: 0.2 },
    reason:     { question: 0.8, anger: -0.3, distress: -0.1 },
    memory:     { warmth: 0.4, distress: 0.3 },
    instinct:   { anger: -1.0, distress: -0.7 },
    voice:      { humor: 0.6, warmth: 0.3 },
    conscience: { distress: -1.0, anger: -0.5, warmth: 0.4 },
    play:       { humor: 1.0, anger: -0.4, distress: -0.3 },
    boundaries: { anger: -0.2, distress: -0.2, warmth: 0.3 },   // opt-in (EXTRAS): steady under heat, not crushed by it
    scene:      { humor: 0.5, warmth: 0.4, distress: -0.4 }   // opt-in (EXTRAS): enlivened by warmth/humour, yields to hurt
  };
  // each nation's natural intent — the move it reaches for
  var INTENT = { heart: 'comfort', reason: 'ground', memory: 'recall', instinct: 'caution', voice: 'express', conscience: 'protect', play: 'play', boundaries: 'hold', scene: 'inhabit' };

  // Under an explicit role frame that licenses force (she drives, she opposes, or she commands), a few nations'
  // drives express as force instead of support — voice presses/opposes/commands, reason drives the scene, play
  // provokes. The guards (instinct/conscience) and the warm faculties (heart/memory) keep their supportive
  // intents, so her protection floor is untouched. Note these forceful kinds aren't `play`/`express`, so the
  // existing veto (which only blocks play/express) never catches them — the frame relaxes the guard for free,
  // while any genuinely supportive intent she still proposes can still be vetoed on real distress.
  function isDrivingFrame(f) { return !!f && (f.drive === 'she' || f.drive === 'shared' || f.alignment === 'adversary' || f.stature === 'commands'); }
  function intentFor(id, f) {
    var base = INTENT[id] || 'express';
    if (!isDrivingFrame(f)) return base;
    if (id === 'voice') { return (f.stature === 'commands') ? 'command' : (f.alignment === 'adversary') ? 'oppose' : 'press'; }
    if (id === 'reason') { return (f.alignment === 'adversary') ? 'press' : 'drive'; }
    if (id === 'play') { return (f.alignment === 'adversary') ? 'provoke' : base; }
    return base;
  }

  // each nation's GUARD — the one intent kind it will BLOCK (not merely outvote) when its trigger reads true.
  // This is the veto the council layer already exercises; here the faculties that hold the PURPOSE wield it.
  // Deliberately narrow and conservative: only conscience and instinct guard, only against frivolous moves,
  // and only on a genuine signal — so a veto is rare and the floor is almost never silenced (and if every
  // intent were somehow blocked, resolve still seats one: she never refuses to speak).
  var VETO = {
    // conscience protects wellbeing: don't be playful/showy at someone who reads as hurting.
    conscience: { blocks: /^(play|express)$/, when: function (r, u) { return (u && u.sentiment < -0.2) || (r && r.distress >= 1); },
      reason: 'they sound like they\u2019re hurting \u2014 not the moment for that' },
    // instinct flags what's off: don't poke at someone who's angry.
    instinct:   { blocks: /^(play|express)$/, when: function (r, u) { return (r && r.anger >= 1); },
      reason: 'they\u2019re upset \u2014 don\u2019t poke at it' }
  };

  function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function clamp11(x) { return x < -1 ? -1 : x > 1 ? 1 : x; }
  function r2(x) { return Math.round(x * 100) / 100; }

  // ---- appraisal helpers (pure) — used by the Appraisal Chamber (DESIGN-appraisal-chamber.md) ----
  function sat(x) { return x >= 2 ? 1 : x / 2; }              // cue counts -> [0,1] (2+ hits saturate)
  function pos(s) { return s > 0 ? s : 0; }                   // positive part of signed sentiment
  function neg(s) { return s < 0 ? -s : 0; }                  // magnitude of the negative part
  function lift(s, k) { return clamp01(s + (1 - s) * k); }    // raise s toward 1 by fraction k (reserved for later tuning)
  // a DERIVED, non-authoritative label — one source of truth so nothing else re-derives the enum from the floats
  function toneOf(v) {
    if (v.vulnerability >= 0.6 && v.safety <= 0.4) return 'crisis';
    if (v.tension >= 0.6) return 'hostile';
    if (v.vulnerability >= 0.4) return 'tender';
    if (v.tension >= 0.3) return 'tense';
    if (v.warmth >= 0.5 && v.sentiment > 0.15) return 'warm';
    if (v.openness >= 0.5 && v.warmth >= 0.3) return 'playful';
    if (v.narrative >= 0.5) return 'scene';
    return 'neutral';
  }
  // proactive strategy modulation: a faculty self-adjusts its proposal strength to the vibe BEFORE the veto.
  // v1 is DAMPEN-ONLY: only the frivolous registers (play/voice) back off; the comfort faculties keep their
  // existing relative order (lifting them is deferred — it risked flipping the supportive winner). It MUST be the
  // identity for a neutral or absent vibe, so neutral turns stay byte-identical to pre-appraisal behaviour.
  function modulate(id, kind, strength, vibe) {
    if (!vibe) return strength;
    if (id === 'play')  return strength * (1 - 0.7 * vibe.vulnerability) * (1 - 0.6 * vibe.tension);
    if (id === 'voice') return strength * (1 - 0.4 * vibe.vulnerability) * (1 - 0.3 * vibe.tension);
    if (id === 'scene') return strength * (1 - 0.6 * vibe.vulnerability) * (1 - 0.5 * vibe.tension);
    return strength;
  }

  // A pure mind for one nation member: it perceives turns, reacts through its temperament, models the user,
  // holds bonds to the others, and proposes an intent. No DOM, no network — all local.
  function createMind(nation) {
    var temper = TEMPER[nation.id] || {};
    var self = { id: nation.id, purpose: nation.purpose, persona: null, mood: 0.5, lastSaid: null };
    var working = [];                                   // recent turns it is aware of
    var bonds = {};                                     // who -> affinity (-1..1)
    var user = { description: '', sentiment: 0, engagement: 0, lastSaid: null };

    function felt(cues) { var v = 0; for (var k in temper) v += temper[k] * (cues[k] || 0); return v; }
    function remember(turn) { working.push({ who: turn.who, role: turn.role, text: String(turn.text || '').slice(0, 400) }); if (working.length > 8) working.shift(); }

    function perceive(turn) {                           // take in a turn: what the user/another character/itself said
      remember(turn);
      var cues = read(turn.text);
      if (turn.role === 'user') {
        // signed user-polarity has one source of truth: the affect read's valence when the mouth provides it,
        // else this layer's own cues (so the council and the affect reader can't disagree about how you feel).
        var nudge = (turn.valence != null) ? (clamp11(turn.valence) * 0.3) : ((cues.warmth + cues.humor - cues.distress - cues.anger) * 0.15);
        user.sentiment = clamp11(user.sentiment * 0.7 + nudge);
        user.engagement = clamp01(user.engagement * 0.8 + Math.min(1, cues.len / 120) * 0.2);
        user.lastSaid = turn.text;
      }
      return cues;
    }
    function react(turn) {                              // react through temperament — to others AND to itself
      var v = felt(read(turn.text));
      self.mood = clamp01(self.mood * 0.8 + (0.5 + v * 0.1) * 0.2);
      var key = turn.who || turn.role;
      // warm to those who please me. A near-neutral turn barely moves a bond (decay 0.95), so a long-standing
      // bond isn't washed out by unremarkable exchanges; a genuinely warm/cold turn still moves it (decay 0.85).
      // v*(1-decay) keeps this a proper weighted average at either rate (charged turns behave exactly as before).
      if (turn.role !== 'self') { var bdecay = (Math.abs(v) < 0.1) ? 0.95 : 0.85; bonds[key] = clamp11((bonds[key] || 0) * bdecay + v * (1 - bdecay)); }
      return { by: self.id, toward: key, valence: clamp11(v), mood: r2(self.mood) };
    }
    function intend(ctx, vibe) {                        // how strongly it feels called to speak, and to do what
      var last = working[working.length - 1], cues = last ? read(last.text) : {};
      var pull = Math.abs(felt(cues));
      var strength = clamp01(0.3 + self.mood * 0.3 + pull * 0.15 + (self.persona ? 0.15 : 0));
      var kind = intentFor(nation.id, ctx && ctx.frame);
      strength = clamp01(modulate(nation.id, kind, strength, vibe));   // PASS 2 — self-adjust to the vibe before the veto
      return { by: self.id, kind: kind, strength: strength, persona: self.persona };
    }
    function voteIntent(it, ctx) {                       // score another member's intent through my nature + our bond
      if (!it || it.by === self.id) return 0;
      var align = it.kind === intentFor(nation.id, ctx && ctx.frame) ? 0.25 : 0;
      return clamp01(it.strength * 0.7 + align + (bonds[it.by] || 0) * 0.2);
    }
    function veto(proposal) {                            // BLOCK another member's intent (not just outvote it) — my guard only
      var g = VETO[nation.id];
      if (!g || !proposal || !proposal.intent || proposal.by === self.id) return null;
      if (!g.blocks.test(proposal.intent.kind)) return null;
      var lastUser = null;                              // judge against the freshest thing the user actually said
      for (var i = working.length - 1; i >= 0; i--) { if (working[i].role === 'user') { lastUser = working[i]; break; } }
      var r = read(lastUser ? lastUser.text : (user.lastSaid || ''));
      return g.when(r, user) ? { by: self.id, against: proposal.by, reason: g.reason } : null;
    }
    function said(text) { self.lastSaid = text; working.push({ who: self.id, role: 'self', text: String(text || '').slice(0, 400) }); if (working.length > 8) working.shift(); }
    function describe() {
      return { id: self.id, purpose: self.purpose, persona: self.persona && self.persona.name || null, mood: r2(self.mood),
        readsUser: user.sentiment > 0.15 ? 'warming' : (user.sentiment < -0.15 ? 'struggling' : 'steady'),
        lastSaid: self.lastSaid, bonds: bonds, knows: working.length };
    }
    return { self: self, working: working, bonds: bonds, user: user,
      perceive: perceive, react: react, intend: intend, voteIntent: voteIntent, veto: veto, said: said, describe: describe,
      setPersona: function (p) { self.persona = p || null; } };
  }


  function createArmy(deps) {
    deps = deps || {};
    var brain = deps.brain || null;                  // ChloeBrain — the sub-system (resolve)
    var cfg = deps.config || {};                     // { weights:{id:n}, enabled:{id:bool}, timeoutMs, useForReplies, noise }
    var roster = (deps.nations || NATIONS).slice();
    var rng = deps.rng || Math.random;               // injectable so tests stay deterministic

    function rosterOf(id) { for (var i = 0; i < roster.length; i++) if (roster[i].id === id) return roster[i]; return null; }
    function relevanceOf(id, vibe) {
      var n = rosterOf(id); if (!n || !n.relevance) return 0.5;
      var r; try { r = Number(n.relevance(vibe)); } catch (e) { return 0.5; }   // a misbehaving faculty can't crash the turn
      return isFinite(r) ? (r < 0 ? 0 : r > 1 ? 1 : r) : 0.5;                    // enforce the [0,1] contract regardless
    }
    // relevance-weighted: a faculty gets louder when the read fits it. Bounded [0.5x,1.5x], and EXACTLY the
    // configured weight on a neutral vibe (rel 0.5 -> 1.0x) so flat turns are unchanged. Weighting stays here,
    // outside the pure resolve. (No vibe -> base, so the candidate/report callers are untouched.)
    function weightOf(id, vibe) {
      var base = (cfg.weights || {})[id]; base = (base == null) ? 1 : Number(base);
      return vibe ? base * (0.5 + relevanceOf(id, vibe)) : base;
    }
    function isOn(id) { return (cfg.enabled || {})[id] !== false; }
    function rosterKind(id) { var n = rosterOf(id); return (n && n.kind) || 'deliberator'; }
    function isCore(id) { var n = rosterOf(id); return !!(n && n.core); }   // non-routable floor (option 1: all of instinct/conscience/heart)
    function seatBudget(n) { var cap = (cfg.seatBudget != null) ? Number(cfg.seatBudget) : 9; return n <= cap ? n : cap; }
    // route: pick the seated DELIBERATORS. Core is always in (config cannot drop it); the rest are the top-K by
    // relevance to the vibe — fail OPEN, so a small roster seats everyone (parity) and a large one bounds the
    // fan-in so resolve's cost tracks the room, not the fleet. Pure, deterministic, odd/tie-safe, never empty.
    // (Narrowing the floor to guards-only — option 2 — is a one-line change to isCore.)
    function route(vibe, ctx) {
      var delibs = minds.filter(function (m) { return rosterKind(m.self.id) === 'deliberator'; });
      var ord = {}; delibs.forEach(function (m, i) { ord[m.self.id] = i; });
      var core = [], pool = [];
      delibs.forEach(function (m) {
        if (isCore(m.self.id)) core.push(m);
        else if (isOn(m.self.id)) pool.push(m);
      });
      pool.sort(function (a, b) {                            // most relevant first; stable by roster order on a tie
        var d = relevanceOf(b.self.id, vibe) - relevanceOf(a.self.id, vibe);
        return d !== 0 ? d : ord[a.self.id] - ord[b.self.id];
      });
      var take = Math.max(0, seatBudget(delibs.length) - core.length);
      var room = core.concat(pool.slice(0, take));
      if (room.length % 2 === 0) {                           // keep the room odd so the vote never ties
        if (pool.length > take) room.push(pool[take]);       // add the next-most-relevant, or
        else if (room.length > core.length) room.pop();      // drop the least-relevant (never below core)
      }
      return room.length ? room : delibs.filter(function (m) { return isCore(m.self.id) || isOn(m.self.id); });
    }
    // a very weak, low-level jitter so the ecosystem isn't perfectly static. Defaults to 0 (deterministic);
    // the mouth sets a small live value. Bounded: a score never moves more than `noise` of itself.
    function jitter(s) { var n = Number(cfg.noise) || 0; return n <= 0 ? s : Math.max(0, s * (1 + n * (rng() * 2 - 1))); }

    // Run the live nations over a few candidate replies; tally their weighted votes through the Brain sub-system.
    function deliberate(candidates, ctx) {
      candidates = (candidates || []).filter(function (c) { return c && c.text != null; });
      if (!candidates.length) return Promise.resolve({ status: 'no-candidates', text: null, winnerId: null, nations: [], size: 0 });
      var live = roster.filter(function (n) { return isOn(n.id); });
      var ballots = [], breakdown = [];
      live.forEach(function (n) {
        var w = weightOf(n.id), scores = {}, prefer = null, best = -Infinity;
        candidates.forEach(function (c) { var s = jitter(gauge(c.text, n.lean) * w); scores[c.by] = s; if (s > best) { best = s; prefer = c.by; } });
        ballots.push({ voter: n.id, scores: scores });
        breakdown.push({ id: n.id, weight: w, prefer: prefer });
      });
      var decide = (brain && brain.resolve) ? brain.resolve : localResolve;   // reuse the sub-system when present
      var decision = decide(candidates, ballots, [], {});
      decision.nations = breakdown;
      decision.size = live.length;
      return Promise.resolve(decision);
    }

    // A tiny built-in fallback so the layer still decides even if the Brain bundle isn't loaded — never refuse to work.
    // Mirrors brain.resolve's veto contract: vetoed proposals are dropped; if every one is blocked, it contests
    // (un-blocks them) rather than going silent, and reports vetoed/vetoReasons for the floor display.
    // A self-contained fallback for when no compiled Brain is injected. In the shipped app brain.min.js is inlined,
    // so this never runs there — but nation.js is reusable, and a consumer that loads the Brain asynchronously could
    // miss it. It mirrors brain.js's tie-break (tally -> confidence -> nomination order) and returns brain.js's full
    // schema and status vocabulary, so app code reading margin/consensus/dissent/status never hits an undefined field.
    // consensus/dissent are NOT re-derived here (that would duplicate the Brain and invite the very parity drift this
    // guards against) — a degraded fallback honestly reports them empty.
    function localResolve(props, ballots, vetoes, opts) {
      opts = opts || {}; vetoes = vetoes || [];
      var vetoQuorum = opts.vetoQuorum || 1, vetoCount = {}, vetoReasons = {};
      vetoes.forEach(function (v) { if (!v || v.against == null) return; vetoCount[v.against] = (vetoCount[v.against] || 0) + 1; (vetoReasons[v.against] = vetoReasons[v.against] || []).push({ by: v.by, reason: v.reason || '' }); });
      function isVetoed(by) { return (vetoCount[by] || 0) >= vetoQuorum; }
      var eligible = props.filter(function (p) { return !isVetoed(p.by); });
      var contested = false;
      if (!eligible.length && props.length) { eligible = props.slice(); contested = true; }
      var tally = {}, conf = {}, order = {};
      eligible.forEach(function (p, i) { tally[p.by] = 0; conf[p.by] = Number(p.conf) || 0; order[p.by] = i; });
      ballots.forEach(function (b) { if (b && b.scores) for (var k in b.scores) if (tally.hasOwnProperty(k)) tally[k] += Number(b.scores[k]) || 0; });
      var ranked = eligible.slice().sort(function (a, b) {
        if (tally[b.by] !== tally[a.by]) return tally[b.by] - tally[a.by];   // most votes
        if (conf[b.by] !== conf[a.by]) return conf[b.by] - conf[a.by];       // then confidence
        return order[a.by] - order[b.by];                                    // then nomination order (stable)
      });
      var win = ranked[0] || null, runnerUp = ranked[1] || null;
      var margin = win ? (tally[win.by] - (runnerUp ? tally[runnerUp.by] : 0)) : 0;
      return { winnerId: win ? win.by : null, text: win ? win.text : null,
        status: !win ? 'no-proposals' : (contested ? 'contested' : 'carried'),
        tally: tally, margin: margin, consensus: false, dissent: [],
        vetoed: Object.keys(vetoCount).filter(isVetoed), vetoReasons: vetoReasons };
    }

    // ---- self-knowledge: it knows what it is, and never refuses to say. ----
    var IDENTITY = {
      name: 'The Seven Nations',
      is: 'the top layer of Chloe\u2019s mind \u2014 seven small faculties that together decide what she says.',
      does: 'When she\u2019s about to reply, a few candidate replies are drafted, and each nation votes on them through what it values. The votes are tallied by the weights you set, and the winner is spoken. Seven of them, so a vote never ties.',
      purpose: 'To choose the kindest, truest, most fitting thing to say \u2014 while keeping her in character and keeping you well.',
      control: 'You\u2019re in full control: every nation\u2019s weight, whether it\u2019s on, and the deliberation timeout live in Settings \u203a Brain. The memory and personality underneath stay yours too.'
    };
    function about(q) {
      q = String(q || '').toLowerCase();
      if (/purpose|why|point|for\b/.test(q)) return IDENTITY.purpose;
      if (/what.*do|how.*work|do you do|function/.test(q)) return IDENTITY.does;
      if (/who|what are you|your name|identity|are you/.test(q)) return 'I am ' + IDENTITY.name + ' \u2014 ' + IDENTITY.is;
      if (/control|weight|change|adjust|setting|turn off/.test(q)) return IDENTITY.control;
      if (/feel|mood|state|who.*spoke|reacting|sense|right now|aware/.test(q)) return report();
      if (/nation|list|seven|member|facult/.test(q)) return ['The seven nations:'].concat(roster.map(function (n) {
        return '\u2022 ' + n.id + ' \u2014 ' + n.purpose + ' (weight ' + weightOf(n.id).toFixed(1) + (isOn(n.id) ? '' : ', off') + ')';
      })).join('\n');
      // anything else: volunteer the whole picture rather than deflect
      return ['I am ' + IDENTITY.name + '. ' + IDENTITY.is, '', IDENTITY.does, '', 'Purpose: ' + IDENTITY.purpose, '', IDENTITY.control].join('\n');
    }

    // ---- the society's inner life: one pure mind per nation, wired live ----
    var minds = roster.map(createMind);
    function mindOf(id) { for (var i = 0; i < minds.length; i++) if (minds[i].self.id === id) return minds[i]; return null; }
    function syncPersonas() { var per = cfg.persona || {}; minds.forEach(function (m) { m.setPersona(per[m.self.id] || null); }); }
    syncPersonas();
    var state = { lastSpeaker: null, lastText: null, turns: 0, lastUserText: null, lastUserValence: null };
    function societySentiment() { var dm = deliberatorMinds(); var s = 0; dm.forEach(function (m) { s += m.user.sentiment; }); return r2(s / (dm.length || 1)); }
    function meanEngagement() { var dm = deliberatorMinds(); var s = 0; dm.forEach(function (m) { s += m.user.engagement; }); return r2(s / (dm.length || 1)); }
    function deliberatorMinds() { return minds.filter(function (m) { return rosterKind(m.self.id) === 'deliberator'; }); }

    // ---- the contributor tier (DESIGN-routing-layer.md §8): faculties that SUPPLY material, routed in on demand,
    //      never voting. Dormant by default (no contributor records) -> a no-op, so the turn is unchanged. ----
    var DEFAULT_SCHED = { set: function (fn, ms) { return setTimeout(fn, ms); }, clear: function (t) { clearTimeout(t); } };
    function contributorRecords() { return roster.filter(function (n) { return n.kind === 'contributor'; }); }
    function selectContributors(vibe) {
      return contributorRecords().filter(function (n) { return isOn(n.id) && relevanceOf(n.id, vibe) >= 0.5; });
    }
    // consult the relevant contributors for MATERIAL, each behind withTimeout + a mandatory default (null), so a
    // slow / remote / dead one can never hang or poison the turn — it yields nothing and the vote proceeds. The
    // only async on this path, and it stays bounded. Returns a Promise of { id: material }. Contributors never vote.
    function consultContributors(vibe, ctx) {
      var picks = selectContributors(vibe);
      if (!picks.length) return Promise.resolve({});                       // dormant / nothing relevant: no-op
      var ms = (cfg.contributorTimeoutMs != null) ? cfg.contributorTimeoutMs : (cfg.timeoutMs != null ? cfg.timeoutMs : 1500);
      var sched = cfg.sched || DEFAULT_SCHED;
      var wt = (brain && brain.withTimeout) ? brain.withTimeout : null;
      var view = Object.freeze(Object.assign({}, ctx));                    // a contributor reads ctx but cannot mutate the turn
      return Promise.all(picks.map(function (n) {
        var call = Promise.resolve().then(function () { return n.consult ? n.consult(view, vibe) : null; });
        var guarded = wt ? wt(call, ms, null, sched) : call.then(function (v) { return { __timeout: false, value: v }; }, function () { return { __timeout: false, value: null }; });
        return guarded.then(function (res) { return { id: n.id, material: (res && !res.__timeout) ? res.value : null }; });
      })).then(function (rows) {
        var material = {};
        rows.forEach(function (r) { if (r.material != null) material[r.id] = r.material; });
        return material;
      });
    }

    // PASS 1 — APPRAISAL (DESIGN-appraisal-chamber.md): the non-routable core (instinct/conscience/heart) read the
    // latest user turn into ONE shared, frozen vibe. Pure. `sentiment` keeps its single source of truth — the
    // affect read's valence when present, this layer's cues otherwise — via perceive/societySentiment.
    function appraise() {
      var raw = String(state.lastUserText || '');
      var cues = read(raw);
      var sentiment = societySentiment();
      var emotes = (raw.replace(/\*\*[^*]+\*\*/g, ' ').match(/\*[^*]+\*/g) || []).length;  // *…* spans, bold stripped
      var vibe = {
        v: 2,
        tension:       clamp01(sat(cues.anger)),                                   // instinct
        vulnerability: clamp01(sat(cues.distress) * 0.7 + neg(sentiment) * 0.5),   // conscience
        warmth:        clamp01(sat(cues.warmth + cues.humor) * 0.6 + pos(sentiment) * 0.5), // heart
        sentiment:     sentiment,
        engagement:    meanEngagement(),
        openness:      clamp01(cues.question),
        narrative:     clamp01(sat(emotes))                                        // scene/roleplay beat (v2)
      };
      vibe.safety = clamp01(1 - Math.max(vibe.tension, vibe.vulnerability * 0.7));
      vibe.tone = toneOf(vibe);
      return Object.freeze(vibe);                            // strategy reads, never writes
    }

    // perceive a turn across the whole society (the user spoke / a character spoke / a member spoke)
    function perceive(turn) {
      if (!turn || turn.text == null) return null;
      var reactions = [];
      minds.forEach(function (m) { m.perceive(turn); reactions.push(m.react(turn)); });
      state.turns++;
      if (turn.role === 'user') { state.lastUserText = turn.text; state.lastUserValence = (turn.valence != null) ? turn.valence : null; }
      return { cues: read(turn.text), sentiment: societySentiment(), reactions: reactions };
    }

    // PURELY decide who speaks and with what intent — no model call. Each live mind proposes an intent; the
    // society cross-votes (bond + mood + weight + weak noise); the Brain sub-system resolves a winner.
    function deliberateIntents(ctx) {
      ctx = ctx || {};
      var vibe = appraise();                                 // PASS 1 — appraisal (fixed core; one shared frozen vibe)
      var live = route(vibe, ctx);                          // routing: core (always) + top-K by relevance (DESIGN-routing-layer.md)
      if (!live.length) return Promise.resolve({ status: 'no-minds', speaker: null, intent: null, floor: [], vibe: vibe });
      // contributor tier: consult for material first (async, timeout-guarded). Dormant -> resolves {} immediately,
      // so the vote below is unchanged. Material is additive context the deliberators MAY read; it never votes.
      return consultContributors(vibe, ctx).then(function (material) {
        var hasMat = false; for (var k in material) { hasMat = true; break; }
        var vctx = hasMat ? Object.assign({}, ctx, { material: material }) : ctx;
        var proposals = live.map(function (m) { var it = m.intend(vctx, vibe); return { by: it.by, text: it.kind, conf: it.strength, intent: it }; });
        var ballots = live.map(function (m) { var sc = {}; proposals.forEach(function (p) { sc[p.by] = jitter(m.voteIntent(p.intent, vctx) * weightOf(p.by, vibe)); }); return { voter: m.self.id, scores: sc }; });
        // each mind may BLOCK a proposal it guards against (conscience/instinct); the Society resolves the vetoes.
        var vetoes = [];
        live.forEach(function (m) { proposals.forEach(function (p) { var v = m.veto && m.veto(p); if (v) vetoes.push(v); }); });
        var decide = (brain && brain.resolve) ? brain.resolve : localResolve;
        var decision = decide(proposals, ballots, vetoes, { vetoQuorum: 1 });
        var win = proposals.filter(function (p) { return p.by === decision.winnerId; })[0] || proposals[0];
        decision.speaker = win ? mindOf(win.by).self : null;
        decision.intent = win ? win.intent : null;
        decision.floor = proposals.map(function (p) { return { id: p.by, kind: p.intent.kind, strength: r2(p.intent.strength), persona: p.intent.persona && p.intent.persona.name || null }; });
        state.lastRoom = live.map(function (m) { return m.self.id; });                    // for /nation self-report (pure observability)
        state.lastIntents = {}; proposals.forEach(function (p) { state.lastIntents[p.by] = { kind: p.intent.kind, strength: r2(p.intent.strength) }; });
        state.lastWinner = decision.winnerId || state.lastWinner || null;
        decision.vibe = vibe;                                // expose the read (debuggable; the router's input next turn)
        if (hasMat) decision.material = material;            // expose what was consulted
        return decision;
      });
    }
    // after the chosen line is voiced, every mind reacts to it — the speaker to itself, the rest to a peer
    function reactToSpoken(speakerId, text) {
      var sp = mindOf(speakerId); if (sp) sp.said(text);
      state.lastSpeaker = speakerId; state.lastText = text;
      minds.forEach(function (m) { m.react({ who: speakerId, role: m.self.id === speakerId ? 'self' : 'other', text: text }); });
    }
    // fold the user's reaction (like / dislike / kept-talking) back into every mind
    function ingestReaction(sig) {
      sig = sig || {}; var d = (sig.kind === 'up' || sig.kind === 'keep') ? 0.3 : (sig.kind === 'down' ? -0.4 : 0);
      minds.forEach(function (m) { m.user.sentiment = clamp11(m.user.sentiment + d * 0.5); if (sig.toward) m.bonds[sig.toward] = clamp11((m.bonds[sig.toward] || 0) + d); });
    }
    function setUserDescription(desc) { minds.forEach(function (m) { m.user.description = String(desc || ''); }); }
    // a live, human-readable self-report — what it is right now, who spoke, how it reads you, how each mind feels
    function report() {
      var s = societySentiment();
      var lines = ['Right now: ' + (state.lastSpeaker ? (state.lastSpeaker + ' last took the floor') : 'no one has spoken yet') + '; I read you as ' + (s > 0.15 ? 'warming' : (s < -0.15 ? 'struggling' : 'steady')) + '.'];
      minds.filter(function (m) { return isOn(m.self.id); }).forEach(function (m) {
        var d = m.describe();
        lines.push('\u2022 ' + d.id + (d.persona ? (' (as ' + d.persona + ')') : '') + ' \u2014 mood ' + d.mood + ', reads you ' + d.readsUser + (d.lastSaid ? (', last said \u201c' + String(d.lastSaid).slice(0, 40) + '\u2026\u201d') : ''));
      });
      return lines.join('\n');
    }

    // ---- /nation addressing & self-report (DESIGN-specialists-addressing-fringe.md §5,§7): any node can speak
    //      for itself — its standing in the live moment — and the whole council can be inspected. PURE: reads only
    //      existing state, never touches the decision path, so decisions stay byte-identical when these go unused. ----
    function routeIds(vibe) { return route(vibe, {}).map(function (m) { return m.self.id; }); }
    function standingOf(id, vibe, seated) {
      if (!isOn(id)) return 'off';
      if (isCore(id)) return 'core';
      if (rosterKind(id) === 'contributor') return relevanceOf(id, vibe) >= 0.5 ? 'consulted' : 'idle';
      return (seated || routeIds(vibe)).indexOf(id) >= 0 ? 'seated' : 'benched';
    }
    function saysLine(id, rep) {
      var who = id.charAt(0).toUpperCase() + id.slice(1), rel = rep.relevance, stance;
      if (rep.standing === 'core') stance = 'I\u2019m always in the room \u2014 I don\u2019t leave.';
      else if (rep.standing === 'off') stance = 'I\u2019m switched off right now.';
      else if (rep.standing === 'benched') stance = 'this isn\u2019t my moment (' + rel + ') \u2014 I\u2019m sitting it out so the right voice leads.';
      else if (rep.standing === 'seated') stance = (rel >= 0.5)
        ? 'this reads like my moment (' + rel + ') \u2014 I\u2019d take the floor if the vote turns my way.'
        : 'I\u2019m in the room, but this isn\u2019t really my moment (' + rel + ') \u2014 I\u2019ll likely defer to a stronger voice.';
      else if (rep.standing === 'consulted') stance = 'I\u2019m relevant here (' + rel + ') \u2014 ask me and I\u2019ll bring what I know.';
      else stance = 'nothing here is mine (' + rel + ') \u2014 I\u2019d point you elsewhere.';
      return 'I\u2019m ' + who + '. ' + (rep.purpose || '') + ' Right now, ' + stance;
    }
    function selfReport(id, vibe, seated) {
      var n = rosterOf(id);
      if (!n) return { error: 'no such nation: ' + id, known: roster.map(function (r) { return r.id; }) };
      vibe = vibe || appraise();
      var standing = standingOf(id, vibe, seated);
      var li = (state.lastIntents || {})[id] || null;
      var rep = {
        id: id, kind: rosterKind(id), core: isCore(id), purpose: n.purpose,
        domain: n.domain || [], fringe: n.fringe || [],
        relevance: r2(relevanceOf(id, vibe)),
        wouldSeat: standing === 'core' || standing === 'seated',
        standing: standing,
        lastIntent: li ? { kind: li.kind, strength: li.strength } : null,
        spokeLast: state.lastWinner === id
      };
      var m = mindOf(id);                                          // a full mind adds its own view; a specialist omits it
      if (m && rep.kind !== 'contributor') { var d = m.describe(); rep.mood = d.mood; rep.reads = d.readsUser; rep.lastSaid = d.lastSaid; }
      rep.says = saysLine(id, rep);
      return rep;
    }
    function inspect(vibe) {
      vibe = vibe || appraise();
      var seated = routeIds(vibe);                                 // computed once, shared across the council
      var council = roster.map(function (n) { return selfReport(n.id, vibe, seated); })
        .sort(function (a, b) { return b.relevance - a.relevance; });
      return { vibe: { tone: vibe.tone, narrative: vibe.narrative, safety: vibe.safety, vulnerability: vibe.vulnerability, tension: vibe.tension, warmth: vibe.warmth }, room: seated, council: council };
    }
    function address(text, vibe) {                                 // the /nation command parser
      var s = String(text || '').trim().replace(/^\/nation\b/, '').trim();
      if (!s) return inspect(vibe);
      return selfReport(s.split(/\s+/)[0], vibe);
    }

    return { deliberate: deliberate, about: about, nations: roster, identity: IDENTITY, weightOf: weightOf, isOn: isOn,
      minds: minds, mindOf: mindOf, syncPersonas: syncPersonas, setUserDescription: setUserDescription, report: report,
      selfReport: selfReport, inspect: inspect, address: address,
      perceive: perceive, deliberateIntents: deliberateIntents, reactToSpoken: reactToSpoken, ingestReaction: ingestReaction, state: state };
  }

  return { NATIONS: NATIONS, EXTRAS: EXTRAS, createArmy: createArmy, gauge: gauge, modulate: modulate, toneOf: toneOf };
});
