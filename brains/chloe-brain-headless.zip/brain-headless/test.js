'use strict';
// test.js — non-vacuous assertions over the headless brain. No model needed
// (uses the mock adapter). Run: node test.js  ->  prints GREEN: N / N
const assert = require('assert');
const { Brain, Council, MockAdapter, CORE, EXTRA_IDS } = require('./index');

let pass = 0, total = 0;
function check(name, fn) { total++; try { fn(); pass++; console.log('  ok  ' + name); } catch (e) { console.log('  XX  ' + name + '  -> ' + e.message); } }
async function acheck(name, fn) { total++; try { await fn(); pass++; console.log('  ok  ' + name); } catch (e) { console.log('  XX  ' + name + '  -> ' + e.message); } }

(async () => {
  check('core faculties present', () => { assert(CORE.includes('heart') && CORE.includes('reason') && CORE.length === 7); });
  check('extras enumerated', () => { assert(EXTRA_IDS.includes('contrition') && EXTRA_IDS.includes('scene')); });

  const council = new Council({ faculties: ['contrition', 'scene', 'wit'] });
  await acheck('decide() returns an intent + a directive for a fault line', async () => {
    const d = await council.decide('you got that wrong, that was a mistake');
    assert(d.intent === 'own', 'expected own, got ' + d.intent);
    assert(/responsibility/i.test(d.directive), 'directive should mention responsibility');
  });
  check('state evolves (turns advanced)', () => { assert(council.state.turns >= 1); });
  await acheck('inspect() returns a live read', async () => { const r = council.inspect(); assert(r && r.vibe && Array.isArray(r.council)); });
  check('about() answers', () => { assert(/faculties|Nation|mind/i.test(council.about('what are you'))); });

  const brain = new Brain({
    character: { name: 'Mira', persona: 'You are Mira.' },
    user: { name: 'Davie' },
    faculties: ['contrition', 'wit', 'expressive'],
    model: new MockAdapter(),
  });
  await acheck('chat() steers the reply via the directive (mock obeys it)', async () => {
    const { text, decision } = await brain.chat('you got that wrong, that was a mistake');
    assert(decision.intent === 'own');
    assert(/steered/.test(text) && /responsibility/i.test(text), 'mock should echo the steer');
  });
  await acheck('history accumulates across turns', async () => {
    await brain.chat('haha that was great actually');
    assert(brain.history.length === 4, 'expected 4 history entries, got ' + brain.history.length);
  });
  await acheck('frame changes the read (villain seats defiance)', async () => {
    const b = new Brain({ character: { name: 'V' }, faculties: ['defiance'], model: new MockAdapter() });
    b.setFrame({ drive: 'she', alignment: 'adversary', stature: 'commands' });
    const d = await b.decide('you stand in my way');
    const r = b.inspect();
    assert(r.council.some(c => c.id === 'defiance'), 'defiance should be in the roster');
  });
  check('feedback() does not throw', () => { brain.feedback('up'); brain.feedback('down', 'Mira'); });

  console.log('\nGREEN: ' + pass + ' / ' + total);
  process.exit(pass === total ? 0 : 1);
})();
