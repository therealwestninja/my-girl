'use strict';
// council.js — the deterministic decision layer, lifted out of Perchance.
// Wraps the Chloe Solo "Nation" (nation.js) + resolver (brain.min.js) and
// exposes a clean, model-free API: perceive a turn, deliberate, get a
// directive. No DOM, no network — pure JavaScript that runs in plain Node.

const Nation = require('./lib/nation.js');
const Brain = require('./lib/brain.min.js');          // exposes .resolve, used by createArmy
const INTENT_DIRECTIVE = require('./lib/intent-directive.js');

const CORE = Nation.NATIONS.map(n => n.id);
const EXTRA_IDS = Nation.EXTRAS.map(e => e.id);

function buildRoster(faculties) {
  const want = new Set(faculties || []);
  return Nation.NATIONS.concat(Nation.EXTRAS.filter(e => want.has(e.id)));
}

class Council {
  constructor(opts = {}) {
    this.opts = opts;
    this.faculties = opts.faculties || [];
    this.noise = opts.noise || 0;
    this.frame = opts.frame || null;
    this.user = opts.user || { name: 'You', description: '' };
    this._build();
  }

  _build() {
    this.army = Nation.createArmy({
      brain: Brain,
      config: { noise: this.noise },
      nations: buildRoster(this.faculties),
    });
    this.setUser(this.user.name, this.user.description);
  }

  // ---- configuration (rebuilds the roster when faculties change) ----
  setUser(name, description) {
    this.user = { name: name || 'You', description: description || '' };
    try { this.army.setUserDescription([this.user.name, this.user.description].filter(Boolean).join(' \u2014 ') || 'You'); } catch (e) {}
  }
  setFrame(frame) { this.frame = frame || null; }
  setFaculties(faculties) { this.faculties = faculties || []; this._build(); }
  setNoise(noise) { this.noise = noise || 0; this._build(); }

  // ---- live state (evolves continuously, the way it did in the app) ----
  perceiveUser(text, valence) {
    this.army.perceive({ who: this.user.name, role: 'user', text: String(text || ''), valence: (valence == null ? null : valence) });
  }
  hearReply(speakerId, text) {                       // the brain processes a spoken reply (its own or another's)
    try { this.army.reactToSpoken(speakerId || (this.opts.character && this.opts.character.name) || 'Character', String(text || '')); } catch (e) {}
  }
  feedback(kind, toward) { try { this.army.ingestReaction({ kind, toward }); } catch (e) {} }

  // ---- the pure decision: who speaks, with what intent, and the directive ----
  async decide(text) {
    if (text != null) this.perceiveUser(text);
    const dec = await this.army.deliberateIntents({ prompt: String(text || ''), frame: this.frame });
    const kind = dec && dec.intent ? dec.intent.kind : null;
    return {
      intent: kind,
      directive: kind ? (INTENT_DIRECTIVE[kind] || '') : '',
      speaker: dec && dec.speaker ? (dec.speaker.id || dec.speaker) : null,
      vibe: (dec && dec.vibe) || null,
      floor: (dec && dec.floor) || [],
    };
  }

  inspect() { try { return this.army.inspect(); } catch (e) { return null; } }
  about(q) { try { return this.army.about(q); } catch (e) { return ''; } }
  get state() { return this.army.state; }
}

module.exports = { Council, CORE, EXTRA_IDS, INTENT_DIRECTIVE };
