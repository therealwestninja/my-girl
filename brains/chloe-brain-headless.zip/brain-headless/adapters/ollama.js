'use strict';
// adapters/ollama.js — the local-model adapter that takes the place of
// Perchance's ai-text-plugin. Talks to a local Ollama daemon over HTTP
// (default http://127.0.0.1:11434). Streaming and non-streaming. Uses the
// global fetch (Node >= 18); pass your own via opts.fetch if you prefer.

class OllamaAdapter {
  constructor(opts = {}) {
    this.endpoint = String(opts.endpoint || 'http://127.0.0.1:11434').replace(/\/+$/, '');
    this.model = opts.model || opts.name || 'llama3.1';
    this.options = opts.options || {};            // temperature, num_ctx, etc. (ollama "options")
    this.fetchImpl = opts.fetch || globalThis.fetch;
    if (typeof this.fetchImpl !== 'function') throw new Error('No fetch available — use Node >= 18 or pass opts.fetch');
  }

  // is a daemon reachable + does the model exist?
  async available() {
    try {
      const r = await this.fetchImpl(this.endpoint + '/api/tags');
      if (!r.ok) return false;
      const j = await r.json().catch(() => null);
      if (!j || !Array.isArray(j.models)) return true;             // reachable but couldn't introspect — assume ok
      return j.models.some(m => (m.name || '').split(':')[0] === String(this.model).split(':')[0]) || j.models.length > 0;
    } catch (e) { return false; }
  }

  // messages: [{ role: 'system'|'user'|'assistant', content }]
  // opts: { stream, onToken, stop }
  async chat(messages, { stream = false, onToken, stop } = {}) {
    const options = stop ? Object.assign({}, this.options, { stop }) : this.options;
    const res = await this.fetchImpl(this.endpoint + '/api/chat', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ model: this.model, messages, stream: !!stream, options }),
    });
    if (!res || !res.ok) throw new Error('ollama ' + (res && res.status) + ': ' + (res ? await res.text().catch(() => '') : 'no response'));

    if (!stream) {
      const j = await res.json();
      return (j && j.message && j.message.content) || '';
    }
    // streaming: newline-delimited JSON, each with .message.content
    let text = '';
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line) continue;
        try {
          const j = JSON.parse(line);
          const t = j && j.message && j.message.content;
          if (t) { text += t; if (onToken) onToken(t); }
        } catch (e) { /* skip partial/non-JSON line */ }
      }
    }
    return text;
  }
}

// A dependency-free stand-in so the package runs (and demos) with no model
// installed. It visibly "obeys" the brain's directive — useful for tests and
// for proving the steering on a machine with no GPU.
class MockAdapter {
  async available() { return true; }
  async chat(messages, { onToken } = {}) {
    const sys = (messages[0] && messages[0].content) || '';
    const dir = (sys.match(/Direction for your next reply:\s*(.*)$/m) || [])[1] || '';
    const last = (messages[messages.length - 1] || {}).content || '';
    const out = (dir ? '[steered: ' + dir + '] ' : '[no steer] ') + 'responding to: "' + last + '"';
    if (onToken) onToken(out);
    return out;
  }
}

module.exports = { OllamaAdapter, MockAdapter };
