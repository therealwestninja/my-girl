'use strict';
// index.js — the headless Brain. Ties the deterministic Council (decides who
// speaks and how) to a model adapter (generates the words). The council never
// calls a model; the adapter never decides intent. Clean seam.

const { Council, CORE, EXTRA_IDS } = require('./council');
const { OllamaAdapter, MockAdapter } = require('./adapters/ollama');

class Brain {
  constructor(opts = {}) {
    this.character = opts.character || { name: 'Assistant', persona: '' };
    this.user = opts.user || { name: 'You', description: '' };
    this.maxHistory = opts.maxHistory || 24;

    this.council = new Council({
      faculties: opts.faculties,
      noise: opts.noise,
      frame: opts.frame,
      user: this.user,
      character: this.character,
    });

    // model: an object with a .chat(messages, opts) method. Default: Ollama.
    this.model = (opts.model && typeof opts.model.chat === 'function')
      ? opts.model
      : new OllamaAdapter(opts.model || {});

    this.history = [];   // [{ role:'user'|'assistant', content }]
  }

  // ---- pure: the decision only (no model call) ----
  decide(text) { return this.council.decide(text); }

  // ---- full turn: decide -> compose system prompt -> generate -> evolve ----
  async chat(userText, { stream = false, onToken } = {}) {
    const decision = await this.council.decide(userText);
    this.history.push({ role: 'user', content: String(userText || '') });

    const messages = [{ role: 'system', content: this._system(decision) }]
      .concat(this.history.slice(-this.maxHistory));

    const text = await this.model.chat(messages, { stream, onToken });

    this.history.push({ role: 'assistant', content: text });
    this.council.hearReply(decision.speaker, text);          // the brain hears itself; state evolves
    if (this.history.length > this.maxHistory * 2) this.history = this.history.slice(-this.maxHistory * 2);

    return { text, decision };
  }

  _system(decision) {
    const parts = [];
    parts.push(this.character.persona || ('You are ' + this.character.name + '.'));
    if (this.user.description) parts.push("The person you're talking to: " + this.user.description + '.');
    if (decision.directive) parts.push('Direction for your next reply: ' + decision.directive);
    return parts.join('\n\n');
  }

  // ---- passthroughs ----
  feedback(kind, toward) { this.council.feedback(kind, toward || this.character.name); }
  inspect() { return this.council.inspect(); }
  about(q) { return this.council.about(q); }
  setFrame(f) { this.council.setFrame(f); }
  setFaculties(f) { this.council.setFaculties(f); }
  setUser(name, description) { this.user = { name, description }; this.council.setUser(name, description); }
  reset() { this.history = []; this.council.setFaculties(this.council.faculties); }
}

module.exports = { Brain, Council, OllamaAdapter, MockAdapter, CORE, EXTRA_IDS };
