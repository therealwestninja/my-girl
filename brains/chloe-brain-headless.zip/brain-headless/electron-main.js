'use strict';
// electron-main.js — minimal Electron main process that runs the brain
// HEADLESS (no window) and routes any model traffic through a local Tor
// SOCKS5 proxy. This is the skeleton for the USB-portable build.
//
// Two pieces you provide on the stick:
//   1) the `tor` daemon binary (little-t tor, from the Tor Project) listening
//      on 127.0.0.1:9050 — launch it however you like (child_process.spawn).
//   2) an Ollama daemon, or point OllamaAdapter.endpoint at a remote model
//      you reach over Tor (an onion service is ideal: no exit node needed).
//
// Run:  electron electron-main.js     (after `npm i -D electron`)
//
// NOTE: a LOCAL ollama on 127.0.0.1 should NOT go through Tor (loopback).
// Only route OUTBOUND model/API calls through Tor — see proxyForModel below.

const { app, session } = require('electron');
const { Brain, OllamaAdapter } = require('./index');

const TOR_SOCKS = process.env.TOR_SOCKS || 'socks5://127.0.0.1:9050';

// If your model lives behind Tor (e.g. an onion endpoint), build a fetch that
// dials through the SOCKS proxy. For a LOCAL ollama, leave this null so
// loopback traffic stays off Tor.
function torFetch() {
  // Requires: npm i undici  (for ProxyAgent). Only needed for remote/onion models.
  try {
    const { ProxyAgent, fetch } = require('undici');
    const dispatcher = new ProxyAgent({ uri: TOR_SOCKS });
    return (url, opts = {}) => fetch(url, Object.assign({}, opts, { dispatcher }));
  } catch (e) {
    console.warn('[tor] undici not installed; remote-over-Tor disabled. `npm i undici` to enable.');
    return null;
  }
}

app.whenReady().then(async () => {
  // Force Chromium's own network (if you ever open a renderer) through Tor too.
  try { await session.defaultSession.setProxy({ proxyRules: TOR_SOCKS }); } catch (e) {}

  const REMOTE_MODEL = !!process.env.MODEL_ENDPOINT;     // set to use a remote/onion model over Tor
  const model = new OllamaAdapter({
    endpoint: process.env.MODEL_ENDPOINT || 'http://127.0.0.1:11434',
    model: process.env.OLLAMA_MODEL || 'llama3.1',
    fetch: REMOTE_MODEL ? (torFetch() || globalThis.fetch) : globalThis.fetch,
  });

  const brain = new Brain({
    character: { name: 'Mira', persona: 'You are Mira: sharp, warm, in character.' },
    user: { name: 'You' },
    faculties: ['scene', 'want', 'wit', 'expressive', 'contrition'],
    model,
  });

  // No window — headless. Drive it from IPC, a local socket, stdin, etc.
  // Demo: one turn, then keep the process alive.
  const { text, decision } = await brain.chat('hey, what are you?');
  console.log('[brain] intent=' + decision.intent + '  reply=' + text);
  // app stays running; wire your own transport (IPC / WebSocket / stdin) here.
});

app.on('window-all-closed', (e) => e.preventDefault());  // headless: don't quit when no windows
