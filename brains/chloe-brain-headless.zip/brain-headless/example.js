'use strict';
// example.js — a self-contained demo. Runs with Ollama if it's reachable,
// otherwise falls back to the mock model so you can see the brain steer with
// no model installed.  Run:  node example.js
//   OLLAMA_MODEL=llama3.1 node example.js   (to pick a model)

const { Brain, OllamaAdapter, MockAdapter } = require('./index');

(async () => {
  const ollama = new OllamaAdapter({ model: process.env.OLLAMA_MODEL || 'llama3.1' });
  const live = await ollama.available();
  console.log(live
    ? '[using ollama -> ' + ollama.model + ' @ ' + ollama.endpoint + ']'
    : '[ollama not reachable -> using the mock model; install ollama for real replies]');

  const brain = new Brain({
    character: { name: 'Mira', persona: 'You are Mira: sharp, warm, a little playful. Reply in 1-3 sentences, in character.' },
    user: { name: 'Davie' },
    faculties: ['scene', 'want', 'wit', 'expressive', 'contrition'],
    model: live ? ollama : new MockAdapter(),
  });

  const lines = [
    'hey — what are you, exactly?',
    'you got that wrong, that was a mistake',
    'haha okay, that recovery was actually great',
  ];

  for (const line of lines) {
    console.log('\n> ' + line);
    const { text, decision } = await brain.chat(line);
    console.log('  [intent: ' + decision.intent + '  |  ' + (decision.directive || '').slice(0, 64) + ']');
    console.log('  Mira: ' + text);
  }

  console.log('\n[ask the brain about itself]');
  console.log('  ' + brain.about('what are you?'));
})().catch(e => { console.error(e); process.exit(1); });
