# chloe-brain-headless

The deterministic **council** from the Chloe Solo / Memory-Hero project, lifted
out of Perchance and runnable in plain Node or Electron's main process. No DOM,
no Perchance runtime, no phone-home. It decides *who speaks and how*; a model
adapter you choose generates the actual words.

```
council (decides intent, no model)  ──directive──▶  adapter (writes words)
        deterministic, offline                        ollama / your model
```

This is the "self-contained brain" path: pair the council with a **local** model
(Ollama) and it owes perchance.org nothing — works offline, ships on a USB stick,
and Tor becomes optional rather than load-bearing.

## Install / run

```bash
node example.js          # runs with a mock model if Ollama isn't present
node test.js             # GREEN: 10 / 10
node bin/chat.js         # interactive REPL
```

Node >= 18 (uses the built-in `fetch`). No dependencies for the core; `undici`
only if you route a *remote* model over Tor (see below).

## API

```js
const { Brain } = require('chloe-brain-headless');

const brain = new Brain({
  character: { name: 'Mira', persona: 'You are Mira: sharp, warm, in character.' },
  user:      { name: 'Davie', description: '' },
  faculties: ['scene', 'want', 'wit', 'expressive', 'contrition'],  // opt-in extras
  noise: 0,                                                          // 0 = fully deterministic
  model: { endpoint: 'http://127.0.0.1:11434', name: 'llama3.1' },   // ollama
});

// pure decision — no model call:
const d = await brain.decide('you got that wrong, that was a mistake');
// -> { intent:'own', directive:'Own it plainly: take responsibility…', speaker:'contrition', vibe, floor }

// full turn — decide -> steer -> generate -> evolve:
const { text, decision } = await brain.chat('you got that wrong');

// streaming:
await brain.chat('tell me a story', { stream: true, onToken: t => process.stdout.write(t) });

brain.setFrame({ drive:'she', alignment:'adversary', stature:'commands' }); // villain stance
brain.feedback('up');           // nudge sentiment/bonds
brain.about('what are you?');   // the brain's self-report
brain.inspect();                // live read: vibe tone + council standing
```

**Faculties.** 7 always-on core (`heart reason memory instinct voice conscience
play`) plus opt-in extras: `scene lore wit restraint want warden defiance deflect
lead guile expressive contrition almanac touch sight sound smell taste felt calc`.

**Adapters.** Any object with `async chat(messages, { stream, onToken, stop })`.
Ships with `OllamaAdapter` and a dependency-free `MockAdapter` (visibly obeys the
directive — used by the demo/tests).

## Ollama

```bash
# https://ollama.com
ollama pull llama3.1
ollama serve              # listens on 127.0.0.1:11434
OLLAMA_MODEL=llama3.1 node example.js
```

## Tor + Electron + USB

- **Headless Electron.** `electron-main.js` runs the brain with *no window* and
  keeps the process alive (`window-all-closed` is prevented). Drive it from IPC /
  a local socket / stdin — your transport.
- **Tor.** Run the little-t `tor` daemon (Tor Project, **not** Tor Browser) on
  `127.0.0.1:9050`. Chromium's own traffic: `session.setProxy({ proxyRules:
  'socks5://127.0.0.1:9050' })`. **Loopback Ollama should NOT go through Tor** —
  only route *outbound* model calls. For a remote model, an **onion endpoint** is
  ideal (no exit node, no Cloudflare-vs-Tor fight): `npm i undici` and pass the
  `torFetch()` dispatcher (see `electron-main.js`).
- **USB.** Two readings, both work: (a) a *portable Electron build* + bundled
  `tor` + a local model on the stick; or (b) drop this into **Tails** (Debian
  live, amnesic, all traffic through Tor, USB-boot) — the closest match to
  "boot off a USB across Tor," and it hands you transparent torification + amnesia
  for free. With a local model the whole thing runs offline; Tor only matters if
  your model is remote.

The honest constraint is compute: a thin USB-boot client on borrowed hardware may
lack the GPU/RAM for a good local model. Split it — the **brain runs on the stick**
(it's tiny and CPU-only), the **model lives on a box you trust**, reached over an
onion service.

## Notes

- The council is fully deterministic at `noise: 0` — same read always seats the
  same faculties and picks the same intent. Raise `noise` (0–50) for variation.
- `about()` still says "the top layer of Chloe's mind." If your character isn't
  Chloe, edit `IDENTITY` in `lib/nation.js` (or feed the character name through).
- `lib/nation.js` + `lib/brain.min.js` are the original, untouched brain — the same
  bytes that run inside Memory-Hero, so behavior matches the app exactly.
