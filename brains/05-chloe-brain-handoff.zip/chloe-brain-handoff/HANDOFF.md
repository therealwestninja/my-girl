# Chloe — Brain Handoff (complete, consolidated)

This is the **whole handoff package for the Brain of *Chloe Solo*** in one repository of seven files. The Brain is
pure reasoning — given a moment, decide *who speaks and with what intent* — with no DOM, no network, and no app.
Everything runs under plain Node and is deterministic.

**The seven files:** `brain.js` (the pure core — edit this), `brain.min.js` (the compiled artifact the app ships),
`nation.js` (the Nations + the cognitive pipeline above the brain), `harness.js` (all 11 test suites in one
runnable file), `package.json`, `build-brain.sh`, and this `HANDOFF.md` (all documentation).

**Start here:** `npm test` → expect one final `ALL GREEN`. Edit `brain.js`, then `npm run build` and
`npm run parity` so the readable source and the compiled artifact always agree. Then read Part I.

> **A note on cross-references.** The parts below were originally separate files and still cite each other by their
> old names. In this consolidated package: every `DESIGN-*.md`, `CHANGELOG-brain.md`, `ROADMAP-brain.md`, and
> `BRAIN-PATCH-PLAN.md` reference is now a **Part of this document** (see the TOC). Every `harness-solo-<x>.js`
> reference is the **`<x>` suite inside `harness.js`** (e.g. `harness-solo-scene.js` → the `scene` suite). A couple
> of companion docs named in the designs (e.g. `DESIGN-council.md`) were never part of this handoff — the council
> is fully covered by Part I and the `council` suite. No file named below other than the seven in this package
> needs to exist.

## Table of contents

- **Part I** — Orientation — the core handoff
- **Part II** — Roadmap — built vs. not-yet-incorporated
- **Part III** — Changelog — as-built history & design deltas
- **Part IV** — Design — The Appraisal Chamber
- **Part V** — Design — The Routing Layer (built for scale)
- **Part VI** — Design — Specialists, Addressing & the Fringe
- **Part VII** — Patch Plan — the bug triage (T1–T7, B1–B2)


<br>

---

# Part I — Orientation — the core handoff

You're holding the **Brain** of *Chloe Solo*, extracted so it can be developed on its own. It is pure reasoning:
no DOM, no network, no app. Everything here runs under plain Node and is deterministic. This document is written
for an AI picking the work up cold — it covers what the Brain is, the exact API, how to run and build it, how to
write a test harness in the house style, the invariants you must not break, and how your changes plug back into the
app they came from.

If you read nothing else: **edit `brain.js`**, run `npm test`, and after any change to `brain.js` rebuild
`brain.min.js` (`bash build-brain.sh`) and re-run the parity tests. The readable source and the compiled artifact
must always agree.

---

## 0. Current state & the docs (read this first)

This package started as the pure `brain.js` core (the resolver + council). It has since grown a full **scale-first
cognitive pipeline** in `nation.js`, on top of an unchanged `brain.js`. The hot path is now:

```
appraise (one frozen vibe) → route (bounded, core-pinned) → consult contributors → strategize (relevance-weighted) → resolve
```

Built and green here (11 suites + parity): the appraisal chamber, routing layer v1, a dormant contributor tier, the
**vibe contract v2** (`narrative` dimension), the first novel faculty **`scene`**, adversarial hardening, and the
**`/nation` self-report**. None of this is in the app yet — the app (`chloe-solo`) is deliberately kept untouched;
the port is the next step and is a *translation*, not a copy.

**All documentation is consolidated into this single `HANDOFF.md`** — the orientation you're reading now, then the
roadmap, the as-built changelog (with the deviations-from-design table), the three design docs, and the bug-triage
patch plan, in that order. See the **Table of contents** at the very top of this file; each was a standalone doc,
folded in here so the package stays under ten files.

The sections below (§1–§11) describe the **core handoff** — `brain.js`, the build, parity, the house style, the
invariants. They remain accurate; the pipeline that grew on top is documented in the design docs and the changelog.

---

## 1. Project context (where this came from)

*Chloe Solo* is a single self-contained HTML app — an AI companion / roleplay character that runs on Perchance.org
with no server. Its architecture splits cleanly in two:

- **The mouth** (`engine.js`, not included here): memory, personality, image/reply routing, the model calls. It
  owns *what she remembers and how she sounds*.
- **The brain** (this package): the *reasoning* — given a moment, decide **who speaks and with what intent**. It
  owns *the decision*, in pure code, and never writes the actual words or touches memory.

When the brain is driving replies, the pipeline is: the **engine** supplies retrieved memory/context → the **brain**
picks the speaker and the intent → the **model** writes the words to that brief. So the brain is an arbiter, not a
text generator. That separation is the whole point: the brain stays pure, testable, and portable — which is why it
can live in this folder by itself.

---

## 2. The three layers (and what's in this folder)

```
brain.js         ← THE CORE. Pure "Society" deliberation + a nervous-system bus. Edit this.
brain.min.js     ← compiled artifact the app ships (terser). Keep in sync with brain.js (run parity).
build-brain.sh   ← brain.js → brain.min.js
nation.js        ← the Nations + the whole cognitive pipeline above the brain. The brain's primary consumer.
harness.js       ← ALL 11 test suites merged into one runnable file (see "House style" for the per-suite map).
package.json     ← `npm test` (node harness.js) · `npm run parity` (vs brain.min.js) · `npm run build`
HANDOFF.md       ← THIS FILE: orientation + roadmap + changelog + 3 design docs + patch plan (everything).
```

Seven files, by design — the test suites that were eleven separate `harness-solo-*.js` are now one `harness.js`
(each suite folded in verbatim, run in order by a small runner at the bottom), and every doc is folded into this
`HANDOFF.md`. The eleven suites and what each proves:

```
council        ← pure resolve() + a live deliberate() round over the nervous bus
veto           ← the nation veto channel (conscience/instinct can block; she never goes silent)
nation         ← the Nations end-to-end (gauge, weighted deliberation, self-knowledge)
nation-extra   ← role-frame intents + affect→sentiment
appraise       ← the appraisal chamber: one frozen vibe, dampen-only modulation, the guard floor
route          ← routing: metadata, weightOf band, a core-pinned/odd/bounded room that holds at scale
contrib        ← the contributor tier: consulted behind a mandatory-default timeout, never votes
bound          ← the `boundaries` opt-in faculty (proposes 'hold', routes in when pushed)
scene          ← the `scene` faculty + the v2 `narrative` dimension (seats on a beat, yields to hurt)
stress         ← adversarial: invariants hold under misbehaving faculties & degenerate inputs
nation-address ← `/nation` self-report: any node speaks for itself; pure (no decision changes)
```

> **`brain-block.js` is not in this package.** It's the layer that wires the brain into the app's engine
> (the action handlers), it needs `engine.js` to run, and it can't execute standalone — so it would only be
> dead weight here. Its role and the exact integration contract are described in §2 (layers) and §10 (plug-back).
> If you need to see it, it lives in the parent app.

The dependency arrows point **down**, and the coupling is by injection, never by `require`:

```
[ app engine ]  ── brain-block.js bridges the brain into the engine's action loop (not in this package)
      │
      ▼
  nation.js   ── createArmy({ brain: ChloeBrain, ... })   // brain is injected, not required
      │  uses ChloeBrain.resolve
      ▼
  brain.js    (zero dependencies — UMD, self-contained)
```

`brain.js` depends on **nothing**. `nation.js` depends on the brain **only** through `createArmy({ brain })` — so
you can test, swap, or fake the brain freely.

---

## 3. Quick start

```bash
node --version          # needs Node >= 14 (anything modern is fine)
npm test                # all 11 suites against the readable source. Expect one final "ALL GREEN".
npm run parity          # re-run every suite against the COMPILED brain.min.js (must match)
node harness.js                          # all suites directly
BRAIN=./brain.min.js node harness.js     # the same, against the compiled artifact

# after editing brain.js:
npm install             # once, to get terser (needs network)
npm run build           # brain.js -> brain.min.js  (alias for bash build-brain.sh)
npm test && npm run parity   # confirm source AND compiled still pass
```

No build step is needed just to *run* — the harnesses load `brain.js` directly. The build only produces the
shipping artifact.

---

## 4. `brain.js` — the core API

A UMD module. In Node it's `require('./brain.js')`; in a browser it installs `window.ChloeBrain` (alias
`ChloeCouncil`). It exposes five things:

```js
{ createNervous, resolve, member, createCouncil, withTimeout }
```

### 4.1 `resolve(proposals, ballots, vetoes, opts)` — the pure heart

This is the whole decision, deterministic, no side effects. Everything else is scaffolding around it.

**Inputs**

| arg | shape | meaning |
|---|---|---|
| `proposals` | `[{ by, text, conf }]` | one nomination per member (abstain = omit). `by` = member id, `conf` ∈ ~[0,1] |
| `ballots` | `[{ voter, scores: { <by>: num } }]` | each member scores the proposals (~[0,1] each) |
| `vetoes` | `[{ by, against, reason }]` | a member blocks a proposal (`against` = the proposer's id) |
| `opts` | `{ allowSelfVote=false, vetoQuorum=1, consensusMargin=0 }` | tuning |

**Algorithm** (read the source — it's ~60 lines and worth knowing exactly):
1. Count vetoes per target; a proposal is vetoed if its count ≥ `vetoQuorum`.
2. Eligible = non-vetoed proposals. **If every proposal is vetoed, the field is un-vetoed and the round is marked
   `contested`** — the Society never crashes or goes silent.
3. Tally each ballot's scores onto proposals (a voter does **not** score its own proposal unless `allowSelfVote`).
   Record each voter's top pick.
4. Rank by **tally → confidence → nomination order** (stable). Winner is first; margin = winner − runner-up.
5. Agreement = every judging voter's top pick is the winner.

**Returns**

```js
{
  winnerId, text,         // the chosen proposal (null if none)
  status,                 // 'no-proposals' | 'contested' | 'agreed' | 'tie-resolved' | 'carried'
  tally,                  // { by: totalScore }
  margin, consensus,      // number; boolean (unanimous among judges)
  dissent,                // [voterId] who preferred someone else
  vetoed, vetoReasons     // [by]; { by: [{ by, reason }] }
}
```

### 4.2 `createCouncil(deps)` — the Society (async orchestration)

Wraps `resolve` with the *protocol*: members register, get asked to propose/vote/veto, and a stalled member is
**timed out to a default vote, never an abstention**.

```js
createCouncil({
  members,        // [ member(...) ]  — keep the count ODD so votes can't split
  nervous,        // optional ChloeBrain.createNervous() bus (proves the message protocol)
  opts,           // passed straight to resolve (+ defaultScore)
  timeoutMs,      // per-member reply timeout (0 = no timeout)
  idleMs,         // a member idle longer than this is reawakened by the watchdog
  sched,          // { set(fn,ms)->t, clear(t) }  — inject for deterministic tests
  now,            // () => ms                      — inject for deterministic tests
  log
})
// → { deliberate(ctx, seed), resolve, members, nervous, wakeStalled, size }
```

`deliberate(ctx, seed)` runs **one round**: `wakeStalled()` → every member **nominates** (best-effort) → every
member **cross-votes on all proposals (mandatory; timeout → `defaultScore`)** → every member may **veto** →
`resolve`. `seed` optionally injects candidate proposals the whole body votes on (the "a few propose, the many
decide" shape). The result carries a `transcript` (proposals/ballots/vetoes) and `participation` (proof every
member voted).

### 4.3 `member(id, role, fx)`

A member-Brain. `fx` injects behaviour; all default to pure no-ops:

```js
member('heart', 'comfort', {
  propose: ctx => ({ text, conf }) | null,    // a nomination, or null to abstain
  vote:    (p, ctx) => number,                // score a proposal (default: p.conf)
  veto:    (p, ctx) => ({ veto, reason })     // block it? (default: { veto:false })
})
```

### 4.4 `withTimeout(p, ms, fallback, sched)`

Races a promise against an injected clock so a stalled mind can't freeze a round. Returns
`{ __timeout, value }`. Pure-testable because `sched` is injected.

### 4.5 `createNervous(log)`

A registry + pub/sub bus + lifecycle (`register/list/find/setState/wake/sleep/standby/send/ask/publish/subscribe/
health`). Optional — `createCouncil` works without it, but when present the members talk over the bus, which is
what `health()` reports on. Useful if you want to model degraded/asleep members.

---

## 5. `nation.js` — the Seven Nations (the layer the app actually calls)

This is the human-readable layer *above* the brain. Seven faculties — **heart, reason, memory, instinct, voice,
conscience, play** — each with a plain-English purpose and a "lean" (what it values in a reply). Seven is odd on
purpose. It uses `ChloeBrain.resolve` underneath.

```js
var N = require('./nation.js');               // { NATIONS, createArmy, gauge }
var army = N.createArmy({
  brain: require('./brain.js'),               // injected ChloeBrain
  config: { weights:{}, enabled:{}, timeoutMs:8000, useForReplies:false, noise:0 },
  rng: Math.random                            // inject a seeded rng in tests for determinism
});
```

The army has **two deliberation paths** — know which one you're touching:

- **`deliberate(candidates, ctx)`** — the *candidate-text* path. You hand it actual reply texts
  `[{ by, text }]`; each nation scores them via `gauge(text, lean)` × weight, and the brain resolves a winner.
  Used by the app's `/council` and emotion-society demos.
- **`deliberateIntents(ctx)`** — the *intent* path (the everyday one). Each live nation proposes an **intent
  kind** with a strength (`intend`), the others cross-vote (`voteIntent`), the brain resolves, and you get a
  winning **speaker + intent** plus a `floor` readout. One model call then voices that intent. This is what
  `runNation` uses when the council drives replies.

Supporting pieces you'll meet:
- **`perceive(turn)`** → reads `cues` (warmth/distress/humor/anger) from text and updates each nation's running
  **sentiment** toward the speaker.
- **`intend(ctx)`** → a nation's intent. Its `kind` comes from `intentFor(id, ctx.frame)` — base intents
  (`heart:comfort, reason:ground, memory:recall, instinct:caution, voice:express, conscience:protect, play:play`),
  which turn **forceful** (`press/oppose/command/drive/provoke`) under a "driving" role frame.
- **`voteIntent(it, ctx)`** → score another nation's intent through this one's nature and its bond.
- **`VETO`** → `conscience` and `instinct` can veto `play`/`express` when sentiment is low or distress/anger is
  present. (Forceful intents are deliberately *not* `play`/`express`, so a driving frame relaxes the veto for free.)
- **`gauge(text, lean)`** → the pure text-scorer: rates a string on `warm/clear/open/play/calm`.

`config`: `weights` ({id:n}, default 1) scales a nation's vote; `enabled` ({id:false}) drops one; `noise`
(default 0 = deterministic) adds bounded jitter; `useForReplies` is the app's toggle for whether the council
drives replies at all (it does **not** affect the math here).

---

## 6. Invariants — do not break these

1. **Pure & deterministic.** No DOM, no network, no `Date.now()`/`Math.random()` reached for directly in logic
   paths — they're **injected** (`now`, `rng`, `sched`) so tests are reproducible. Keep it that way; it's the
   reason the Brain is testable at all.
2. **Odd membership.** Seven nations so a vote can't tie. `createCouncil` warns on even membership. If you add or
   remove faculties, keep the count odd.
3. **Voting is mandatory, abstention is not a vote.** A member that stalls is timed out to `defaultScore` — it
   never silently drops out. Proposals (text) *can* be abstained (return `null`); votes cannot.
4. **The body never goes silent.** If every proposal is vetoed, the round is `contested` and proceeds. Preserve
   this — "she falls silent" is a failure mode, not an outcome.
5. **The minify contract.** `brain.min.js` is terser with `mangle toplevel` but **property names preserved** —
   the app and `nation.js` call `resolve`, `deliberate`, `winnerId`, `tally`, etc. by name. **Never rename a
   public property or returned field.** If you do, the app breaks *and* parity breaks. Internals (local vars,
   helper function names) are free to change.
6. **Source and artifact agree.** After any `brain.js` edit: rebuild, then run the harnesses against **both**
   `brain.js` (`npm test`) and `brain.min.js` (`npm run parity`). They must give identical results.

**Pipeline-era invariants (the `nation.js` layer that grew on top — see the design docs):**

7. **Neutral-vibe parity.** On a flat turn the appraisal/routing changes are invisible: every `relevance` returns
   exactly `0.5` on a neutral vibe, so `weightOf(id, neutralVibe) === base`, and `route` at the current roster size
   seats everyone (fail-open identity). This is the regression floor for the whole pipeline.
8. **Frozen vibe, non-maskable core.** The `vibe` is `Object.freeze`d (strategy reads, never writes); the core
   `{ heart, instinct, conscience }` is always seated and always able to veto, regardless of config or routing.
9. **Contributors never vote.** Only deliberators enter the ballot; contributors are consulted behind
   `withTimeout` + a mandatory default and fold material into `ctx`. A timeout yields an empty contribution and the
   turn proceeds.
10. **Untrusted faculties can't crash the turn.** `relevanceOf` is the single sanitized path (a throwing/NaN/
    out-of-range `relevance` → safe default, clamped); a contributor's `consult` gets a frozen `ctx` view.
11. **Addressing overrides the vote, never the floor.** `/nation` can select who speaks, but a summoned/promoted
    node still passes the `conscience`/`instinct` veto. `selfReport`/`inspect` are pure and change no decision.

---

## 7. Writing a test harness (the house style)

The harnesses are plain Node scripts — **no framework**, no dependencies. The pattern is deliberately tiny so it
runs anywhere and reads top-to-bottom. Copy this shape:

```js
/* what this proves, in one sentence */
'use strict';
var C = require(process.env.BRAIN || './brain.js');   // ← parity hook: same file runs vs source AND brain.min.js
var fail = 0;
function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

// --- arrange: build proposals/ballots/vetoes (or a council with INJECTED now/rng/sched) ---
var d = C.resolve(
  [{ by:'a', text:'A', conf:0.5 }, { by:'b', text:'B', conf:0.4 }],
  [{ voter:'b', scores:{ a:0.9, b:0.1 } }, { voter:'c', scores:{ a:0.2, b:0.8 } }],
  []
);
// --- assert ---
ok(d.winnerId === 'a' || d.winnerId === 'b', 'a winner is chosen');
ok(typeof d.tally === 'object', 'a tally is returned');

console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — <one-line summary of what held>'));
process.exit(fail ? 1 : 0);
```

Rules that make a harness good here:

- **End with the sentinel.** `npm test` (and the parity run) greps for the exact string `ALL GREEN`. Print it only when `fail === 0`,
  and `process.exit(fail ? 1 : 0)`.
- **Make it parity-safe.** If the harness exercises the resolver, load it via `process.env.BRAIN || './brain.js'`
  so the runner can point it at `brain.min.js`. (Nation-only harnesses just `require('./nation.js')`.)
- **Inject all non-determinism.** For anything async or jittered, pass `now`, `rng`, and `sched`:
  ```js
  var T = 0; var now = function(){ return T; };
  var sched = { set:function(fn,ms){ return setTimeout(fn,0); }, clear:clearTimeout };   // or a fake clock
  var rng = (function(){ var s = 42; return function(){ s = (s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; }; })();
  ```
  A seeded `rng` + fixed `now` make council rounds and nation jitter reproducible.
- **Assert behaviour, not internals.** Check `winnerId`, `status`, `dissent`, `participation`, the `floor` —
  the contract — not private helpers.
- **One concern per harness, many small `ok`s.** Mirror the existing files: `council` (nominate/vote/veto/resolve
  + every member works), `veto` (blocking + the body still speaks), `nation` (perceive/intend/decide), and
  `nation-extra` (a driving frame turns the right nations forceful; sentiment flows from an
  injected valence). Reading those five is the fastest way to learn the conventions.

When you add a behaviour to `brain.js` or `nation.js`, add a harness that pins it, and make sure `npm test`
and `npm run parity` stay green against **both** the source and `brain.min.js`.

---

## 8. The build (`brain.js` → `brain.min.js`)

```bash
npm install            # gets terser (only needed once; needs network access)
bash build-brain.sh
```

`build-brain.sh` runs terser with `compress passes=3` + `mangle toplevel` but `comments=false` and **property
names preserved**, then `node --check`s the output and prints the size delta. The compiled file is what the app
ships; this folder keeps it only so you can prove equivalence. **Always rebuild + re-run parity after editing
`brain.js`** — a green `brain.js` with a stale `brain.min.js` is the easiest way to ship a silent regression.

If you don't have network access for `npm install`, you can still develop and test entirely against `brain.js`;
just hand the rebuild + parity step back to someone who can run terser, and don't ship a `brain.min.js` you
haven't regenerated.

---

## 9. Gotchas (things that have bitten before)

- **Don't rename public properties** (see invariant 5). The minifier preserves them by design; renaming desyncs
  the app and the parity tests at once.
- **`brain-block.js` is not in this package** — it bridges the brain into the app's engine, needs `engine.js`, and
  can't run standalone (see §2). Its role and the integration contract are in §2 and §10; the file lives in the app.
- **Keep membership odd**, and keep every member voting (timeout → default, never abstain).
- **Parity is not optional.** The two most recent regressions in this codebase were caught *only* by running a
  harness against `brain.min.js` after it had drifted from `brain.js`.
- **The harnesses were de-absolutised for this package** — their `require` paths are now relative (`./brain.js`,
  `./nation.js`). If you copy a harness from the parent app later, fix its paths the same way.

---

## 10. How your changes plug back into the app

When this work goes home, the integration points in the app (`solo.html`) are:

- The army is built once: `createArmy({ brain: window.ChloeBrain, config: state.nation, rng, ... })`.
- On a user turn, `runNation` does: `perceive(turn)` → `deliberateIntents(ctx)` → the brain resolves a **speaker +
  intent** → the app voices that intent with **one** model call, threading in the engine's retrieved context.
- `state.nation.useForReplies` (off by default) decides whether the council drives replies at all; `/nation`
  invokes it manually.

So the contract you must preserve for a clean drop-in: the **shape of `deliberateIntents`'s result** (`winnerId`,
`text` = the intent kind, `floor`, `dissent`) and the **shape of `resolve`'s result**. Add fields freely; don't
rename or remove existing ones.

---

## 11. What is deliberately NOT in this package

- **`engine.js`** — memory, personality, the model calls, context assembly. The brain never touches these.
- **The readers** (`stance/affect/topics/frame/measure`) — glue-side perception that *feeds* the brain (e.g. the
  role frame that flips nations forceful, the affect valence that feeds `perceive`). Here they appear only as the
  plain inputs the harnesses pass in (`ctx.frame`, `turn.valence`), so you can develop against the contract
  without them.
- **The app glue** (`solo.html`) — the queue, the UI, `runNation`. Section 10 is the summary of how it calls in.

The Brain is the part that thinks. Everything left behind is the part that remembers and the part that speaks. Keep
it pure, keep it odd, keep the two builds in agreement, and it stays as portable as it is right now in this folder.

---

## Patch log

The full, current history — the bug fixes, the appraisal/routing/contributor pipeline, the v2 contract, the `scene`
faculty, the hardening, the `/nation` self-report, **and the deviations-from-design table** — is in the
**Changelog** part of this document (newest first). What's built vs. not-yet-incorporated is in the **Roadmap**
part. Those two parts are the source of truth for state; this orientation part is the tour of the core.

The original five verified bug patches (Tasks 1–5) that this package shipped with: `resolve` honours an explicit
`vetoQuorum:0`; `resolve` de-duplicates proposals by author; `gauge.open` reads a question through a trailing
`*action*`; `gauge.play` strips `**bold**` before detecting an emote; `createCouncil` short-circuits a
once-stalled member. Held (not bugs): T6 per-mind `user` redundancy, T7 peer spoken-text consistency; two tuning
calls (B1 length cliff, B2 `'shared'` drive) remain design decisions. Full detail is in the **Changelog** and
**Patch plan** parts below.


<br>

---

# Part II — Roadmap — built vs. not-yet-incorporated

Where the cognitive pipeline stands and what's next. Companion to `CHANGELOG-brain.md` (as-built history + the
deviations-from-design table) and the three `docs/DESIGN-*.md`. Newest thinking at the top of each track.

> **One status line:** the full scale-first pipeline is **built and green in this handoff** (19 suites + parity).
> It is **not yet ported to the app** — `chloe-solo` is deliberately kept untouched ("anesthetized"). The port is
> the next big step and is a *translation*, not a copy (the app uses the browser `root.Chloe*` / `assemble.py`
> `__NATION__` pattern, not this package's Node UMD wrappers).

---

## Where we are (built & green, handoff only)

- Verified bug fixes **T1–T5** (each test-pinned).
- **Appraisal chamber** — `appraise → strategize`, one frozen `vibe`.
- **Routing layer v1** — faculty metadata (`kind/core/domain/relevance`), `weightOf(id, vibe)`, bounded `route`,
  `seatBudget`.
- **Contributor tier** — built dormant (consult behind `withTimeout` + mandatory default; never votes).
- **Vibe contract v2** — `narrative` dimension + `scene` tone.
- **First novel faculty `scene`** — opt-in roleplay deliberator that yields to distress.
- **Adversarial hardening** — `relevanceOf` sanitized; contributor `consult` gets a frozen ctx view.
- **`/nation` self-report (slice 1)** — `selfReport`/`inspect`/`address`, pure, zero behaviour change.
- **“The Nation” re-theme** — user-facing collective/member vocabulary (incl. the brain's self-description).
- **Two new opt-in faculties** — `wit` (safety-gated `lighten` intent) and `restraint` (4th guard: force-on-withdrawal).
- **`want` opt-in faculty** — the first *self-originated* faculty (proposes `initiate`; escalates under a driving frame), plus full council-voicing coverage for every faculty intent.
- **`almanac` opt-in faculty** — a self-contained topic *contributor* (bundled offline fact book; supplies material, never votes), and contributor material now reaches the spoken reply.

Roster: 7 `NATIONS` (heart, instinct, conscience [core]; reason, memory, voice, play) + `EXTRAS`
[boundaries, scene, lore (contributor), **wit**, **restraint**, **want**, **almanac** (contributor)]. With every opt-in deliberator enabled the candidate
pool now exceeds the default `seatBudget` cap of 9, so `route`'s top-K pruning runs by design — the room stays
core-pinned, odd, and bounded while the least-relevant voices bench.

---

## DONE (2026-06-16) — the port (app un-anesthetized)

The full pipeline + every fix were transplanted into `chloe-solo` and the app was wired to take advantage of them.
- **Transplant:** the app's `brain.js`/`brain.min.js`/`nation.js` (304-line ancestor) were replaced with this
  handoff's matured trio. A reversible dry run first proved zero breakage; the real swap kept **all 65 app harnesses
  green** + parity, because the handoff is a backward-compatible superset and `solo.html`'s call sites
  (`createArmy({brain,config})`, `perceive({…valence})`, async `deliberateIntents({prompt,frame})`, `reactToSpoken`,
  `ingestReaction`, `about`) were already a drop-in match. `.orig` backups retained; `solo-app.html` rebuilt.
- **Take-advantage batches**, each harness-verified: (1) **telemetry** — a "Live read" panel + enriched in-chat
  transcript render `decision.vibe`/`decision.routing` from a pure throwaway `inspect()`; (2) **EXTRAS** —
  `boundaries`/`scene` opt-in (off by default → the seven preserved); (3) **addressing** — `/nation <id> --speak`
  routes through `deliberateIntents({promote:id})`, the floor invariant holding in the live path; (4) **the lore
  contributor** — its consult bound to the app's real `engine.assembleContext` (filtered to the continuity lanes),
  pulled in by `scene`'s nomination on a beat.
- Two honest follow-ups (non-blocking): `assembleContext` runs twice on a lore-beat turn (cacheable); and
  deliberators don't yet *read* contributor `material` when forming intents (the natural next depth step).

The standalone brain in this handoff remains the source of truth; the app holds a translated copy.

## Specialists / addressing / fringe (`docs/DESIGN-specialists-addressing-fringe.md`)

- **[DONE]** slice 1 — `/nation` self-report (pure observability).
- **[DONE — 2026-06-16]** slice 2 — **addressing promotion:** `deliberateIntents(ctx, { promote: id })` force-seats
  the addressed node and, after the vote, makes it the speaker — *unless* a guard vetoed it. `/nation <id> --speak`
  parses to `{ action: 'promote', id }` for the caller to run. Hard invariant **held & pinned** (suite `promote`):
  overrides the *vote*, never the *floor* — promoting a frivolous node into a crisis is blocked by conscience and a
  guard speaks instead. Disabled/unknown nodes and contributors are refused gracefully (`decision.promotion` carries
  the reason).
- **[DONE — 2026-06-16]** slice 3 — **the specialist archetype:** `createSpecialist` builds contributors as lean
  nodes (`self` + `consult` + a minimal `describe`; **no** temper/bonds/user/vote), the roster maps heterogeneously
  (`createSpecialist` vs `createMind` by kind), and the feeling-loops (`perceive`/`react`/`ingestReaction`/
  personas) run over `deliberatorMinds()` so specialists genuinely don't feel. First real contributor registered:
  **`lore`** (scene's companion) — narrative-selected, dormant on plain chat, supplies a continuity note when a beat
  is in play, never seats or votes. Contributor-as-speaker promotion lands too: `promote` a contributor and its
  material becomes the reply — **gated by the safety floor** (refused when `vibe.safety < 0.5`, so a tangent never
  overrides a hurting moment). Pinned by the `specialist` suite.
- **[DONE — 2026-06-16]** slice 4 — **the live fringe:** a registry index (`findByDomain`/`fringeFor`/
  `resolveNomination`) resolves a domain to its owners, and a seated deliberator's declared `nominate(vibe, ctx)`
  calls in those specialists by domain mid-turn (force-consulted regardless of their own relevance). Resolution is
  **honest** — `owned` / `referred` (a fringe recognizes it, doesn't own it) / `unknown` (nobody does) — so the
  fleet never fabricates a capability. `scene` nominates `continuity` (→ `lore`) when seated; nominations ride in
  `decision.routing.nominations`. Pinned by the `fringe` suite (incl. "benched faculties don't nominate",
  "nomination pulls in a low-relevance specialist without changing the vote", and a throwing `nominate` can't crash
  the turn). **The specialists track is complete.**

## Faculty track

- **[DONE — 2026-06-16]** `scene`'s contributor companion `lore` — a lean `lore`/`continuity` specialist,
  selected on the `narrative` dimension (sidesteps needing a topic classifier yet). Shipped with slice 3.
- **[OPEN]** further novel members / sub-divisions as domains demand them.
- **[PARKED]** a prose-RP signal for `narrative` beyond `*emotes*` (quotes, second-person) — noisier; emotes are
  the high-precision v2 signal.

## Guard tiers / defense-in-depth (more *layers*, not more triggers)

Principle: a few narrow guards each at a real trust boundary, every one cheap to verify — so the conservative veto
never turns trigger-happy and mutes her.

- **[NEXT, with the contributor tier] Ingestion gate (fail CLOSED).** Validate/filter contributor material *before*
  it reaches the model. Note the asymmetry: liveness guards fail **open** (a timed-out contributor → default,
  proceed); a **content** gate fails **closed** (suspect material dropped). Same fleet, opposite fail-modes.
- **[LATER] Appraisal-layer guard.** A single "re-appraise if the strategy pass stalls" hook (ties to the
  appraisal doc's no-backtracking limitation) — not a full feedback loop.
- **[LATER] Guard-tier overlap.** As the fleet grows, the guard tier itself wants overlap so no single faculty
  failing opens the gate. Non-maskable core + both conscience and instinct is the start.
- **[PARKED — instability risk] Meta-watcher.** A guard on cross-turn *trends* (veto-storms, sentiment tailspins,
  a contributor flooding every turn). Neighbours the deferred plasticity work; keep parked until a concrete
  failure points at it.

## Held bug-triage items (`docs/BRAIN-PATCH-PLAN.md`)

- **[HELD]** T6 — per-mind `user` redundancy refactor (verified; cosmetic/inert today).
- **[HELD]** T7 — peer spoken-text consistency.
- **[DESIGN CALL]** B1 — the clear/calm length cliff (the ~600-char gauge behaviour).
- **[DESIGN CALL]** B2 — the `'shared'` drive mapping.

## Consistency / cleanup

- **[OPEN]** `deliberate(candidates, ctx)` — the candidate-reply-**ranking** path — still uses base `weightOf(id)`
  with no vibe. A future consistency item (make it vibe-aware like `deliberateIntents`). *Not* a divergence — the
  design docs only ever spec'd the intent path — but a loose end.
- **[OPEN]** packaging cadence — keep `CHANGELOG-brain.md` and this roadmap current per slice; the zip folds tests
  + docs.

## Observability & tuning (adopted from the external review)

Three concrete, in-scope wins surfaced by the external review (the rest of it is reconciled below):

- **[DONE — 2026-06-16] Routing & weight telemetry.** `decision.routing` now exposes the seating decision —
  `seated` (each with `relevance` + effective `weight`), `benched` (with relevance), `contributors`, `seatBudget`,
  `coreCount` — and `selfReport`/`inspect` carry per-node `weight`. Pure (the decision is byte-identical). Pinned by
  the `telemetry` suite. (Review 1.7 / 3.9 / 4.6.)
- **[DONE — 2026-06-16] Passive-ingestion parity test.** The `passive` suite drives a benched node and a seated
  node through an identical conversation and asserts the benched one ends with the same sentiment/engagement/mood/
  bonds — confirming `perceive`/`react`/`ingestReaction` run on every mind and the seated-only methods
  (`intend`/`voteIntent`/`veto`, all verified pure reads) never desync a benched node. (Review 2.10.)
- **[INVESTIGATED — 2026-06-16, no change] Weight-band contrast.** Probed across representative turns
  (tender/hostile/warm/playful/neutral/scene/question/mixed): **zero blurred decisions** — the winner is always
  rank 1–2 by relevance, dropping to a sensible base tiebreak only when the relevance field is genuinely flat. The
  bounded linear band `[0.5×, 1.5×]` gives enough separation; relevance is a *tilt*, not a dictator (by design).
  Keep it linear; revisit only if a real blurred decision surfaces (the telemetry now makes winner-rank visible).
  Still **not** `pow(rel,2)`+zeroing.

## External review — reconciled (2026-06-16)

An outside analysis (two uploaded files) proposed a 10-section / 100-item roadmap. Verified against source, most of
it is already handled; the genuine items are adopted above. Recorded here so it isn't re-litigated.

**Already true in the code (verified):**
- *Passive ingestion / "context amnesia"* — `perceive`/`react`/`ingestReaction` already loop every mind each turn;
  benching only gates propose/vote. Benched nodes stay synced. (Its strongest claim; empirically false for us.)
- *Health-vs-topology "collision"* — `nation.js` never calls `sleep`/`setState`; routing is pure selection. Sleep
  is the async council's bus-state, set only on timeout. The state-spaces are already separate.
- *Proportional ballot power* — `weightOf = base × (0.5 + relevance)` already scales the vote in a `[0.5×, 1.5×]`
  band. Seating is binary; *power* is continuous.
- *Neutral parity* — already an invariant and tested (relevance 0.5 → identity).

**Already designed / on this roadmap:**
- *Hierarchical/cascading routing for a large fleet* → the contributor tier + `find(domain)` registry + the
  referral fringe/nomination (Specialists track). It conflated the small deliberator *council* (stays flat —
  "who she is") with the *contributor* fleet (hierarchical — "what she knows"); hierarchy belongs to the latter.
- *Plugin micro-faculty framework* → the specialist archetype (Specialists slice 3).
- *Scene/narrative anchoring + `ctx.scene`* → the `scene` faculty + the v2 `narrative` dimension (Faculty track).
- *Afferent-efferent feedback / re-appraise on deadlock* → the deferred single re-appraise hook (appraisal §10).
- *Meta-cognitive drift watchdog* → the parked meta-watcher (Guard tiers).
- *Synchronized memory exchange* → the engine↔brain contract (Orientation §10; contributor material into `ctx`).

**Declined (would regress a tested invariant) — see Out of scope:** weighting inside `resolve`; `pow(rel,2)`+zeroing
ballot power; speculative prefetch. **Adopted:** the three *Observability & tuning* items above.

## Out of scope (standing — and why)

- **Weighted referral fringe edges** — a graph with a consistency burden; a flat `fringe` list preserves
  grow-by-addition. Adopt only if flat lists prove too coarse.
- **Specialists voting** — reintroduces retrieval-noise at scale and couples async nodes into the deterministic
  vote. Consult, don't enfranchise.
- **Addressing bypassing the guards** — would make `/nation` a jailbreak around the protective floor.
- **Plasticity / self-warping weights** — instability, worse with dynamic routing. Relevance is a pure function of
  the current vibe, not an accumulating weight.
- **Speculative prefetch** — optimizes the ~microsecond brain, not the ~second model/contributor latency.
- **Weighting inside `resolve`** — `resolve` stays pure and weight-blind; all relevance weighting lives in
  `weightOf` (the glue). Raised by the external review; it would unwind a tested invariant.
- **Squared / zeroing ballot power** (`pow(rel,2)` + 0× for unseated) — collapses marginal voices and breaks
  never-silent / never-zero. We keep the bounded `[0.5×, 1.5×]` band; *contrast within the band* is the open
  tuning question (see Observability & tuning).


<br>

---

# Part III — Changelog — as-built history & design deltas

The `DESIGN-*.md` docs are **design intent**. This file is the **as-built record**: what actually landed, in
what order, and — where the build deliberately departed from a doc — *what* changed and *why*. Where this file and
a design doc disagree, **this file is ground truth** and the divergence is intentional (each was flagged at build
time). Newest first. Scope: the `brain-handoff` sandbox (`nation.js` glue + `brain.js`/`brain.min.js` pure core).

Format: `Added` / `Changed` / `Hardened` / `Fixed`, plus a standing **Deviations from design intent** section that
the eventual app port should translate from (not the stale doc text).

---

## 2026-06-16 — `almanac` faculty (self-contained topic contributor) + contributor material reaches voicing

**Added — `almanac` (EXTRAS, contributor).** A self-contained topic contributor — proves the Dewey-scale pattern
(drop in a faculty per subject). Unlike `lore` (app-backed, material injected from real memory), `almanac` ships a
small bundled, static, offline `ALMANAC` book (~24 facts across astronomy, geography, biology, chemistry, history,
physics, maths, units, language) plus a pure `almanacLookup(text)` keyword scan. `consult(ctx, vibe)` reads
`ctx.prompt` and returns the best-matching `{ subject, fact, on }` or null. Relevance
`clamp01(0.55 + openness·0.2 − vulnerability·0.7 − tension·0.4)` gates *consultation*: live on a safe turn, benched
when the room is vulnerable/tense — so it never offers trivia over a hurting person, even when the text names a
subject it knows. It supplies material; it never proposes or votes (never on the floor). Suite `almanac`.

**Contributor material now reaches the spoken reply (app).** `voiceInstruction` / `composeVoicePrompt` thread
`decision.material` into the council voicing as a “you happen to know (use only if it fits)” reference, via a new
`materialToReference` (recites fact-bearing material like almanac; continuity-shaped material like lore still only
shapes deliberation). `nationRoster` now adds self-contained contributors (almanac) directly from EXTRAS; `lore`
stays app-backed. Before this, contributor material shaped deliberation but never reached what was said.

`almanac` is an **opt-in EXTRA** (NATIONS stays 7). Harness **20 → 21 suites**, parity green. Mirrored to the app
(`nation.js` byte-identical), wired as an "Optional faculties" toggle, **app sweep 72/72 green**, `solo-app.html`
rebuilt.

## 2026-06-16 — `want` faculty (self-originated agency) + full intent-voicing coverage

**Added — `want` (EXTRAS, deliberator).** The first faculty whose intent is *self-originated*: where every other
faculty reacts to the user's state, `want` brings Chloe's own initiative. Proposes `initiate`. Relevance keys on an
OPENING — `clamp01(0.12 + openness·0.5 + warmth·0.25 + pos(sentiment)·0.25 − tension·0.6 − vulnerability·0.9)`
— so it seats on a question/warm turn, benches on a flat or withdrawn turn (deferring to `restraint`), and collapses
to 0 in crisis (agency must never be selfish). Under a driving frame `intentFor` escalates it like the other agentic
faculties: `initiate → drive` (she drives) / `command` (commands) / `press` (adversary). `modulate('want')` scales
strength by `safety·(1−0.85·vuln)·(1−0.4·tension)`. Guards backstop a bare `initiate` — added to `conscience`/`instinct`
`blocks` (`/^(play|express|lighten|initiate)$/`). `INTENT.want='initiate'` + `TEMPER.want`. Suite `want` (17 asserts):
opening → seats + proposes initiate; flat/hurting → self-benches; driving frame → drive/command; guards veto initiate
on distress/anger; no over-block on a glad turn.

**Full intent-voicing coverage (app).** Added the missing `INTENT_DIRECTIVE` entries so every faculty intent is voiced
in character on the council floor: `initiate` (want), and the previously-missing `lighten` (wit), `ease` (restraint),
`hold` (boundaries), `inhabit` (scene) — each had been silently falling back to a generic directive. New regression
`harness-solo-intent-voicing` cross-checks the brain's full `INTENT` map + `FORCE` kinds against the app directive map.

`want` is an **opt-in EXTRA** (NATIONS stays 7 — every `NATIONS.length===7` pin holds). Harness **19 → 20 suites**,
parity green. Mirrored to the app (`nation.js` byte-identical), wired as an "Optional faculties" toggle, **app sweep
71/71 green**, `solo-app.html` rebuilt.

## 2026-06-16 — "The Nation" re-theme + two new opt-in faculties (wit, restraint)

**Changed (copy only).** The collective is now **"The Nation"** (one mind), its members **faculties**, the per-turn
seated body **the council** — replacing "the Seven Nations". In this package the only surface touched is the brain's
self-description: `IDENTITY` (`about()`/`selfReport`) now says "The Nation"/"faculties" and drops the count-bound
"seven, so a vote never ties" for "an odd number is always seated, so a vote can't tie". Pinning assertion retargeted
(`/seven nations/i` → `/the nation/i`). Code identifiers, comments, and logic untouched. (App settings/interface
strings re-themed in `solo.html`.)

**Added — `wit` (EXTRAS, deliberator).** Proves a *safety-gated intent*. Proposes `lighten` (a tease, a warm bit of
play). Self-suppresses three ways so it can never reach a hurting turn: (1) `relevance` keys on warmth/openness and
collapses to 0 on tension/vulnerability (benched); (2) `modulate('wit')` scales strength by `safety·(1−0.7·vuln)`
(erases on an unsafe/tender vibe); (3) **defense-in-depth** — `lighten` was added to the conscience+instinct `blocks`
regex, so a guard vetoes it on a genuine distress/anger signal even if it were force-seated. `INTENT.wit='lighten'` +
`TEMPER.wit`. Suite `wit`: glad room → seats + proposes lighten; hurting turn → self-benches, winner `protect`; both
backstops fire; no over-block in a glad room.

**Added — `restraint` (EXTRAS, deliberator + 4th GUARD).** Proves a *new veto layer* at a boundary the existing two
miss: not distress (conscience) or anger (instinct) but **withdrawal**. Proposes `ease` (say less, gently). As a guard
(`VETO.restraint`, force-only — `blocks:/^$/`) it vetoes force on a plain (non-scene) turn whose last user line is
terse/disengaged (`r.len<25 && !r.question && engagement<0.4`); stands down in a consensual scene (`force:!scene`).
Key seating insight: **withdrawal is invisible to the appraised `vibe`** (a terse "ok. fine." reads as an all-zero
neutral; `engagement` is ~0 for everyone early), and a guard's veto only counts when **seated** (resolve collects
vetoes from `live` minds). So `relevance` is a **ready-brake** curve — base **0.55**, present on any non-warm room,
benched only on a clearly warm one — which keeps the veto *live* on real withdrawn turns. Verified end-to-end: a
withdrawn turn under a driving frame seats restraint, its veto lands on the force (reason/voice), conscience+instinct
stay silent, and the winner falls back to `ease`. `INTENT.restraint='ease'` + `TEMPER.restraint`. Suite `restraint`.

Both are **opt-in EXTRAS** (NATIONS stays 7 — the "seven seed faculties" identity and every `NATIONS.length===7` pin
hold). Harness **17 → 19 suites**, parity green. Mirrored to the app (`nation.js` byte-identical), wired as two
"Optional faculties" toggles, **app 65 → 67 harnesses green**, `solo-app.html` rebuilt.

## 2026-06-16 — App port complete (brain transplanted + app wired to use it)

Roadmap's last big item, done. The matured trio was transplanted into `chloe-solo` (reversible dry run → zero
breakage → real swap, **65/65 app harnesses + parity green**, `.orig` backups kept, `solo-app.html` rebuilt). Then
four take-advantage batches, each harness-verified: telemetry readout (`decision.vibe`/`routing` surfaced), EXTRAS
opt-in (`boundaries`/`scene`), `/nation <id> --speak` addressing (floor invariant intact in-app), and the `lore`
contributor wired to the app's real retrieval (`engine.assembleContext`, continuity lanes only). The standalone
brain here stays the source of truth. See the "DONE — the port" roadmap section for detail.

## 2026-06-16 — Stress test (adversarial) — 2 fixes, broad hardening confirmed

Threw ~120 hostile scenarios at the brain (malformed/huge/non-string text, junk configs, junk frames, junk promote
ids, contributor consults that throw/reject/never-resolve/return circular, a 2000-turn longevity run, and a
determinism fuzz). Invariants checked on every decision: no throw, no rejected/sync-thrown turn, no silent-she, vibe
in range, finite tally/strength, deterministic at noise 0. **Two real defects found and fixed:**
- **A `nominate()` returning a non-array crashed the whole turn.** `collectNominations`'s `try/catch` wrapped only
  the call, not the `doms.forEach` — so a faculty returning a bare string/number/object threw *synchronously* out of
  `deliberateIntents`. Now the return is coerced (`Array.isArray` → use it; bare string → one domain; junk → none),
  so a misbehaving faculty truly can't crash the turn. Regression-pinned in `fringe`.
- **A config-disabled core reported `'off'` while still seated.** `route` seats core regardless of `isOn` (core is
  non-maskable, by design), but `standingOf` checked `isOn` before `isCore`, so `selfReport('heart')` said `'off'`
  while heart was in the room and a core node was speaking. Reordered (`isCore` first); `about()` no longer labels a
  core as off either. Regression-pinned in `nation-address`.

**Confirmed robust (no change needed):** 100k-char and all-emote/unbalanced-asterisk text; cue floods (sat()
saturates cleanly, no overflow); `seatBudget` 0/negative/NaN/huge (falls back to the core floor, she still speaks);
negative/NaN/huge weights and huge/negative noise (scores stay finite); empty roster and contributors-only
(legitimate `no-minds`); duplicate roster ids; relevance fns that throw/return NaN/huge (the sanitizer holds [0,1]);
a never-resolving consult (bounded by the timeout — turn completed in ~50ms); junk frames and junk promote ids (all
refused gracefully); 2000 turns (working buffer caps, state stays finite); and full determinism across the
input×frame fuzz. **17 suites**; parity green; `brain.js` untouched.

## 2026-06-16 — Close the driving-frame veto gap (force tier)

The audit's top flagged item, now implemented. The guards (conscience/instinct) gained a **force tier**: beyond the
frivolous set (`play`/`express`), they now also block the forceful kinds a driving/adversary frame produces
(`command`/`oppose`/`press`/`drive`/`provoke`, via the new `FORCE` matcher) — so a frame can no longer slip force
past the floor on a genuinely hurting turn. Resolved the safety-vs-roleplay tension with the signal the appraiser
already uses, an **emote beat** (`inScene`):
- **Plain text** (a person speaking) + distress/anger → force is **blocked**, a protective core takes the floor.
- **Emote-beat scene** + anger, or mild distress → guards **stand down**; consensual in-character force is preserved
  (the whole point of the driving frame).
- **Emote-beat scene** + **severe** distress (≥2 cues) → conscience **still blocks** force — a person breaking down
  is protected even mid-scene.
- **Neutral / non-distressed** + frame → not clamped; force still wins when it should.

Per-guard policy lives in the `VETO` table (`force(r, u, scene)`); force vetoes carry their own de-escalation
`forceReason`, distinct from the frivolous reason. `veto()` now gates on the genuine-signal `when` first, then
frivolous, then force. New `force` suite (7 cases incl. the in-scene/severe-distress split). **17 suites**; parity
green; `brain.js` untouched.

## 2026-06-16 — Logic pass / audit (whole brain) — 3 real fixes + flagged design calls

A full read of `brain.js` + `nation.js` against the source. Confirmed-with-repro defects fixed:
- **`report()` didn't know about lean specialists** — it called `describe()` and read `mood`/`readsUser` on a
  contributor, printing "mood undefined, reads you undefined". Now renders a contributor line ("specialist (…);
  supplies material, doesn't feel or vote").
- **`deliberate()` (the candidate path) let contributors vote** — it filtered `roster` by `isOn` only, so `lore`
  entered the ballot (size 8, contributor in the breakdown). They scored 0 (no `lean`) so the winner was safe, but
  it was inconsistent with `deliberateIntents`. Now filters to `isOn && deliberator`. (Known remaining loose end,
  *flagged not fixed*: `deliberate` weights with no vibe — relevance-blind — because the candidate path doesn't
  appraise. The hot path `deliberateIntents` is vibe-aware.)
- **A promoted decision kept the vote's `status`/`tally`** — `winnerId` was overridden to the addressed node while
  `status` still read `agreed`/`carried` and `tally`'s top was a different faculty. Granted promotion now sets
  `status:'promoted'` so the headline fields stop contradicting each other (tally is retained as the genuine,
  now-superseded vote).
- **Telemetry honesty:** `routing.contributors[].consulted` was relevance-*predicted*; now reflects the **actual**
  consulted set (relevance OR nomination/promotion force-consults).
- **`localResolve`** quorum aligned to `resolve` (`!= null` rather than `|| 1`) for fallback parity.

**Flagged for ratification (no behavior changed):**
- **The driving-frame veto gap (top item).** [RESOLVED 2026-06-16 — see the entry above.] Under `isDrivingFrame`
  (`drive:she|shared`, `alignment:adversary`, `stature:commands`) `intentFor` makes voice/reason/play propose forceful kinds (`command`/`oppose`/`press`/
  `drive`/`provoke`). `VETO.blocks` is `/^(play|express)$/`, which does **not** cover those — so a driving frame is
  unguarded on genuine distress/anger (the code comment already concedes "the frame relaxes the guard for free").
  The supportive floor still exists (guards keep proposing), but the guards can't *block* the forceful intents.
  Options: widen `blocks` to include the forceful kinds when distress/anger is real; or have the guards veto force
  under genuine distress regardless of frame. Davie's call — it changes roleplay behavior.

**Non-issues (verified, left as-is):** even-membership rooms can't truly tie (resolve's conf/order tie-break is
total); contributor material is inert w.r.t. the standalone vote *by design* (generic deliberators don't read it —
an app's faculties would); `rosterKind` defaults unknown ids to 'deliberator' (harmless in every call path);
`standingOf` is a static snapshot and doesn't reflect per-turn nominations (the live read does). 16 suites; parity
green; `brain.js` untouched.

## 2026-06-16 — The live fringe (specialists slice 4 — track complete)

The fleet can route itself from the edges.
- **Registry index:** `findByDomain(d)` / `fringeFor(d)` / `resolveNomination(d)` resolve a domain to its owning /
  recognizing contributors. `resolveNomination` returns `{ domain, servedBy, referredBy, status }` with status
  **`owned` / `referred` / `unknown`** — honest deferral, never a fabricated capability. Exposed on the army.
- **Nomination:** a seated deliberator's declared `nominate(vibe, ctx)` returns domains; `collectNominations` reads
  the seated faculties, resolves the domains, and force-consults the owners that turn (via the now-array `forceIds`
  through `selectContributors`/`consultContributors`). A throwing `nominate` is caught (can't crash the turn).
  `scene` nominates `continuity` (→ `lore`) when seated. Nominations are recorded in `decision.routing.nominations`.
- Pure w.r.t. the vote: nomination only adds contributor material; contributors never vote, so the winner is
  unchanged. New `fringe` suite. **16 suites**; parity green; `brain.js` untouched. **Specialists track complete**
  (slices 1–4): self-report → addressing promotion → specialist archetype → the live fringe.

## 2026-06-16 — The specialist archetype + first real contributor (specialists slice 3)

Contributors are now lean nodes, not full minds.
- **`createSpecialist`** builds a `kind:'contributor'` record as `{ self, consult, describe }` — **no**
  temper/mood/bonds/user/intend/voteIntent/veto. The roster maps heterogeneously (`createSpecialist` vs
  `createMind` by kind), and the feeling-loops (`perceive`/`react`/`ingestReaction`/`syncPersonas`/
  `setUserDescription`) now iterate `deliberatorMinds()`, so a specialist genuinely never feels or remembers.
- **`lore`** — the first real contributor and `scene`'s companion: narrative-selected
  (`relevance = 0.3 + 0.5·narrative`, so dormant on plain chat, consulted once a beat is in play), supplies a
  deterministic continuity note, never seats or votes. (An app injects real memory in place of the stub.)
- **Contributor-as-speaker promotion:** `selectContributors`/`consultContributors` gained a `forceId` so a promoted
  contributor is always consulted; `applyPromotion` surfaces its material as the speaker (`intent.kind:'material'`)
  — **gated by the safety floor** (`vibe.safety < 0.5` → refused), so a tangent never overrides a hurting moment.
- New `specialist` suite; the `promote` suite's contributor case updated to the new grant path. **15 suites**;
  parity green; `brain.js` untouched.

## 2026-06-16 — Addressing promotion (specialists slice 2)

`/nation <id> --speak` — make the addressed node the speaker, around the vote but not around the floor.
- `deliberateIntents(ctx, opts)` gains `opts.promote`: `ensureSeated` force-seats the addressed deliberator if it
  was benched, then `applyPromotion` (post-resolve) makes it `winnerId`/`speaker`/`intent` — **unless** a guard
  vetoed its proposal, in which case the promotion is refused (`decision.promotion = { granted:false, vetoedBy }`)
  and resolve's protective winner keeps the floor. Overrides the vote, never the floor.
- `address('/nation <id> --speak')` returns `{ action: 'promote', id }` for the caller to feed to
  `deliberateIntents`; `/nation <id>` without the flag is still a pure self-report.
- Disabled/unknown nodes and contributors are refused gracefully (a contributor is "material, not a speaker" until
  slice 3). Pure when unused: a turn without `promote` carries no `promotion` field and the normal vote stands.
- New `promote` suite (incl. the crisis-floor invariant). Harness now **14 suites**; parity green; `brain.js`
  untouched.

## 2026-06-16 — Adopted items from the external review (telemetry, passive test, band probe)

Built the three items the external review actually warranted (`nation.js`-layer only; `brain.js` untouched, parity
holds):
- **Routing telemetry.** `decision.routing` = `{ seatBudget, coreCount, seated:[{id,core,relevance,weight}],
  benched:[{id,relevance}], contributors:[{id,relevance,consulted}] }`; `weight` added to `selfReport`/`inspect`.
  Pure/additive — the decision is byte-identical. New `telemetry` suite pins it.
- **Passive-ingestion parity.** New `passive` suite drives a benched node and a seated node through the identical
  conversation and asserts identical sentiment/engagement/mood/bonds. Verified the seated-only methods
  `intend`/`voteIntent`/`veto` are pure reads, so benching never desyncs — the review's "context amnesia" doesn't
  apply here, and is now guarded against future regression.
- **Weight-band contrast — investigated, no change.** Probed representative turns: zero blurred decisions; the
  linear `[0.5×, 1.5×]` band stays. Recorded in the roadmap.
- Harness is now **13 suites**; `npm test` and parity both green.

## 2026-06-16 — External review reconciled into the roadmap

An outside analysis (a critique + a 100-item roadmap) was verified against source and folded into the **Roadmap**
part: three of its four "critical gaps" were already solved in code (passive ingestion via per-mind
`perceive`/`react`; health-vs-topology separation — `route` never sleeps; proportional ballot via the `weightOf`
band), most of its sections map to already-designed roadmap tracks, and a few fixes were **declined** for unwinding
tested invariants (weighting inside `resolve`; `pow(rel,2)`+zeroing ballot power; prefetch). **Adopted** as new
roadmap items: routing/weight telemetry in `decision.transcript`/`inspect`; an explicit passive-ingestion parity
test; and weight-band contrast as an open tuning question. No code changed — roadmap + this note only.

## 2026-06-16 — `/nation` addressing & self-report (specialists slice 1)

Design: `DESIGN-specialists-addressing-fringe.md` pins the node taxonomy's third kind — the **specialist** (a
contributor that doesn't feel or remember, never votes, but is addressable and promotable) — the `/nation`
addressing protocol (**overrides the vote, never the floor**), and the **referral fringe** (a plain adjacent-domain
list: what a node recognizes but doesn't own, for honest deferral and mutual nomination). Three decisions pinned:
specialists don't vote; fringe is a flat list (weighted edges parked); the self-report is a pure structured object
plus a first-person line.

### Added (build-order slice 1 — pure, zero behaviour change)
- `selfReport(id, vibe)` — any node speaks for itself: kind/core/purpose/domain/fringe, live `relevance`, whether
  it `wouldSeat`, its `standing` (`core|seated|benched|consulted|idle|off`), `lastIntent`, `spokeLast`, a full-mind
  view (mood/reads/lastSaid) that specialists omit, and a deterministic first-person `says` line.
- `inspect(vibe)` — the debug layer: the whole council ranked by relevance, the seated `room` (== `route`), a vibe
  summary. Computes the room once; never runs a deliberation.
- `address(text, vibe)` — the `/nation` parser: `/nation` → inspect, `/nation <id>` → that node's report, unknown
  id → an error + the known roster (never throws). Exposed on the army alongside `selfReport`/`inspect`.
- Last-turn state stashed additively in `deliberateIntents` (`state.lastRoom/lastIntents/lastWinner`) — new keys,
  decision path untouched.
- `harness-solo-nation-address.js` (21 pins): **purity** (a run drenched in inspect/address decides identically),
  honest standing, `says` reflects standing+relevance, inspect ranking, fringe surfacing, contributor omits the
  mind-view, `/nation` parsing, unknown-id.

### Honest finding
At small N, `route` **fail-opens to seat everyone**, so "seated" is *membership, not relevance*. The first `says`
draft conflated the two ("this reads like my moment (0)"); fixed so a seated-but-low-relevance node says it will
defer. The distinction is now explicit in both the report and the tests.

---

## 2026-06-16 — Vibe contract **v2** + first novel faculty `scene`

### Added
- **Vibe contract bumped to `v: 2`** — first growth of the frozen contract. New dimension **`narrative` ∈ [0,1]**:
  how much the turn reads as a roleplay/scene beat. Computed in `appraise()` from emote spans — strip `**bold**`,
  then count `*…*` spans, `clamp01(sat(emotes))`. `0` on ordinary chat (parity), saturates at 2+ emotes.
  - The bump is principled, not gratuitous: adding a key alone is allowed without a version bump
    (DESIGN-appraisal-chamber §3), but we also **widened the `tone` enum** (below), which is a contract change, so
    the version moves to 2 and the schema harness is updated in lock-step — exactly the discipline §3 prescribes.
  - Port note: the `/\*[^*]+\*/g` emote regex is **DSL-safe** (asterisks aren't brace/bracket constructs), so it
    survives the translation to the app's `nation.js` unchanged.
- **`tone` label `'scene'`** — derived, lowest non-neutral priority (`narrative ≥ 0.5 → 'scene'`, just above
  `neutral`). It can never mask a protective/affective label: crisis/hostile/tender/tense/warm/playful all win
  first, so a hurting user mid-scene still reads `tender`/`crisis`, not `scene`.
- **`scene` faculty** (opt-in, in `EXTRAS` — keeps the canonical *seven nations* identity intact). A **roleplay
  deliberator**: proposes `inhabit` (stay in-character, advance the beat). `relevance` is centered at `0.5` on a
  neutral vibe (parity), **rises with `narrative`**, and **yields to distress/tension** (drops below 0.5 when the
  user reads hurt or hostile) so the protective core takes the floor mid-scene. `TEMPER.scene` is enlivened by
  warmth/humor, damped by distress. Added to the dampen-only `modulate` table (backs off on
  vulnerability/tension), so it self-quiets before the veto even needs to fire — defense in depth.
- `harness-solo-scene.js` — pins: v2 schema (`narrative` present & in range, `v === 2`), narrative parity on plain
  chat, `**bold**` does **not** count as an emote, narrative rises on an emote turn, `scene` seated on a roleplay
  turn but benched on plain chat, **`scene` yields on a hurting roleplay turn** (relevance < 0.5, protective wins /
  guard holds, tone reads tender not scene), seven-identity preserved (NATIONS-only roster unaffected),
  determinism, modulate dampen.

### Changed
- `harness-solo-appraise.js` schema pin updated for v2: `KEYS` gains `narrative`; `v.v === 2`; `TONES` gains
  `scene`; `narrative` range-checked. (The sanctioned schema-harness update that accompanies a contract version
  bump.)

---

## 2026-06-16 — Adversarial hardening (untrusted-faculty surface)

A pressure-test of the full pipeline found three real vulnerabilities in the surface a *fleet* exposes — a
misbehaving or remote faculty. The design docs assume well-behaved faculties; this hardening is **above** the spec.

### Hardened
- **`relevanceOf` is now the single sanitized path.** A faculty whose `relevance` **threw** crashed the entire turn
  synchronously; one whose `relevance` returned out-of-range (e.g. `100`) broke the `[0.5×, 1.5×]` weight band; NaN
  /Infinity leaked into sorting and tallies. `relevanceOf` now: `try/catch → 0.5`, coerce `Number`, non-finite →
  `0.5`, clamp `[0,1]`. `selectContributors` routed through it too. Clamping in-range values is identity, so
  well-behaved faculties are unaffected (parity preserved).
- **Contributor `consult` gets a frozen `ctx` view** (`Object.freeze(Object.assign({}, ctx))`) — a contributor can
  read the turn but can no longer mutate it (e.g. inject an adversarial frame). The real `ctx` the deliberators
  vote over is untouched.
- `harness-solo-stress.js` — 17 invariant-under-attack pins codify the whole battery (never silent, core
  non-maskable, room odd & bounded, vibe frozen & in range, weight band intact, contributors can't crash/hang/sway/
  mutate, determinism with a bad faculty present). Confirmed already-robust (no fix needed): empty/contributor-only
  rosters → `no-minds`; `seatBudget:0` → core only; all-disabled → core seated & speaks; cue flood → vibe in range.

---

## 2026-06-15/16 — Scale-first cognitive pipeline (built on the appraisal + routing designs)

Hot path is now **appraise → route → consult contributors → strategize (relevance-weighted) → resolve.**

### Added
- **Appraisal Chamber** (`DESIGN-appraisal-chamber.md`): `appraise()` builds one frozen `vibe`
  (`safety/tension/vulnerability/warmth/sentiment/engagement/openness/tone/v`); pure helpers `sat/pos/neg/lift/
  toneOf/modulate`; `intend(ctx, vibe)` self-modulates before the veto; `decision.vibe` attached.
  `societySentiment`/`meanEngagement` scoped to **deliberators only** so contributors never sway the feeling read.
- **Routing Layer v1** (`DESIGN-routing-layer.md`): faculty metadata (`kind/core/domain/relevance`, relevance
  centered at 0.5); `weightOf(id, vibe)` (band `[0.5×,1.5×]`, exact base on neutral, outside `resolve`);
  `route(vibe, ctx)` (core always seated, top-K by relevance, bounded by `seatBudget` cap 9, fail-open, pure, odd/
  tie-safe, never empty); wired as `var live = route(...)`.
- **Contributor tier** (dormant): `kind:'contributor'`, `selectContributors`, `consultContributors` —
  each consulted behind `withTimeout` + a **mandatory null default**, material folds into `ctx`, contributors
  **never vote**. No contributor registered yet; tier exists and is tested before the first remote faculty.
- **`boundaries` faculty** (first opt-in `EXTRAS` deliberator): proposes `hold`, routes in on tension / negative
  sentiment, benched when calm. First proof that relevance-seating does real work (swaps with `play`).
- Harnesses: `harness-solo-appraise.js`, `-route.js`, `-contrib.js`, `-bound.js`.

### Verified (conformance audit, 2026-06-16)
Code **meets both designs at minimum**; the only gaps are doc *text* lagging the as-built code (see Deviations).
Parity proven numerically: every relevance returns exactly `0.5` on neutral → `weightOf@neutral === base`; `route`
at N=7 seats all seven (identity).

---

## 2026-06-15 — Bug fixes (verified against source, each test-pinned)

### Fixed
- **T1** `resolve` (brain.js): `vetoQuorum` now `(opts.vetoQuorum != null) ? … : 1` — `0` no longer coerced to `1`.
- **T2** `resolve`: proposals de-duplicated by author before tally (a faculty can't double-count itself).
- **T3** `gauge.open` (nation.js): a question still reads through a trailing `*action*`.
- **T4** `gauge.play`: strip `**bold**` before detecting a single `*action*` emote.
- **T5** `createCouncil` (brain.js): `reach` short-circuits on a mind already stalled this turn (`deadSet`), cutting
  repeat timeouts.

> These live in the **handoff** (`brain.js` T1/T2/T5, `nation.js` T3/T4). The shipping app `chloe-solo` does **not**
> yet have them — they port over with the pipeline.

---

## Deviations from design intent (standing — translate the *port* from these, not the doc text)

| # | Doc | Doc says | As-built | Why |
|---|-----|----------|----------|-----|
| 1 | appraisal §4 | `appraise(ctx)` reads `ctx.turn.text` | `appraise()` reads `state.lastUserText` | `ctx` is `{}` at the call site; `perceive` stashes the text first |
| 2 | appraisal §5 | dampen play/voice **and lift** heart/conscience | **dampen-only** (`lift` helper kept, reserved) | lifting flipped the supportive winner / broke the "conscience holds the floor" pin |
| 3 | appraisal §6 | `m.veto(p, vibe)` | `m.veto(p)` | doc called it optional/behavior-preserving; the vibe encodes the same guard trigger |
| 4 | appraisal §8 | a `route`-stub forward-guard test | none | superseded — `route` is real, with its own harness |
| 5 | routing §6 | `route(minds, vibe, ctx)` | `route(vibe, ctx)` (closure `minds`) | functionally identical; `odden`/`coreOrOn` were pseudocode, implemented inline |

Refinement beyond the docs (conformant): sentiment/engagement scoped to **deliberators**, so contributors can't
move the feeling read (routing §8: "the vibe stays authoritative").

Out of these docs' scope: `deliberate(candidates, ctx)` — the candidate-reply-**ranking** path (distinct from
`deliberateIntents`) — still uses base `weightOf(id)` with no vibe. A future consistency item, not a divergence.

---

## Roster (current)

- **Core deliberators** (non-maskable, always seated): `heart`, `instinct`, `conscience`.
- **Strategist deliberators** (routed/weighted): `reason`, `memory`, `voice`, `play`.
- **`EXTRAS`** (opt-in): `boundaries` (proposes `hold`) and `scene` (proposes `inhabit`) are deliberators; `lore`
  is a contributor.
- **Contributors** (lean specialists, no feel/vote): `lore` — narrative-selected, supplies scene continuity.
- Exports: `{ NATIONS, EXTRAS, createArmy, gauge, modulate, toneOf }`. Vibe contract: **v2**.


<br>

---

# Part IV — Design — The Appraisal Chamber

> **For the engineer/agent building this:** this is a design, not a patch. It formalizes something already
> half-present in `nation.js` — the system already *reads* the situation (cues, sentiment) and already lets the
> protective faculties *block* on it; this splits that into an explicit **appraise → strategize** order with one
> shared, frozen `vibe` contract. It is deliberately scoped to stay synchronous, deterministic, and
> behavior-identical on neutral turns. It is also the **prerequisite for the Hierarchical Routing layer**: the
> `vibe` defined here is exactly the signal a future router consumes, so the seams it will plug into are specified
> at the end. Companion to `DESIGN-council.md`.

---

## 1. Why

`deliberateIntents` (the everyday hot path, `nation.js`) does three things in a single undifferentiated pass: every
live mind forms an intent, everyone cross-votes, and the guards (`conscience`/`instinct`) veto afterward. Two
consequences:

- **The appraisal is scattered and implicit.** Each mind independently calls `read(turn.text)` inside `intend`,
  `voteIntent`, and `veto`; there is no single agreed read of *what kind of moment this is*. `user.sentiment` and
  `societySentiment()` exist and are good, but they're consulted ad hoc, not established up front as the frame the
  whole turn reasons inside.
- **Constraint is reactive, not proactive.** The only way appraisal currently shapes strategy is the veto — i.e.
  `play` proposes a joke at a hurting user, *then* `conscience` blocks it. That works (and stays), but it's a
  cleanup after a tone-deaf proposal was already on the floor, rather than `play` reading the room and never
  raising the joke with full confidence in the first place.

The fix is the cognitively honest order: **appraise the situation first, then decide how to act, with the appraisal
as an upfront constraint.** This is the synchronous core of the "Phase-Gated Blackboard" / Bicameral / Actor-Critic
ideas — three framings that converge on one structure — minus the async, the plasticity, and the prefetch (see
§10, out of scope).

It is also the thing routing needs. You cannot seat the right faculties for a turn until you know whether the turn
is playful, tender, hostile, or a crisis. The appraisal pass produces that read; the router (later) consumes it.

---

## 2. Shape

Two synchronous passes over one shared object, inside the existing `deliberateIntents`. No bus, no ticks, no
promises beyond the one `deliberateIntents` already returns.

```
[ turn ]
   │
   ▼
PASS 1 — APPRAISAL  (the non-routable core: instinct, conscience, heart)
   reads the turn into ONE shared `vibe`  ───────────►  vibe { safety, tension, vulnerability,
   (pure; no proposals, no text)                                 warmth, sentiment, engagement, openness, tone }
   │
   ▼
( routing seam — §9: route(minds, vibe, ctx) chooses the strategy roster + weights; core always seated )
   │
   ▼
PASS 2 — STRATEGY  (the live roster)
   each mind forms its intent READING the vibe (self-modulating), then everyone cross-votes
   the guards still veto on the same vibe (the floor is retained — defense in depth)
   │
   ▼
resolve(proposals, ballots, vetoes)  ── unchanged, still pure ──►  decision (+ decision.vibe attached)
```

`resolve` does not change and does not learn about `vibe`. The appraisal lives entirely in the `nation.js` glue,
above the pure heart.

---

## 3. The `vibe` contract (the central artifact)

`vibe` is a plain object with a **frozen key set and fixed ranges**. This contract is the interface that the
strategy pass, the guards, the future router, and the harnesses all depend on. Adding a key later is allowed;
renaming, removing, or changing the range/type of an existing key is a breaking change and must bump the version
and update the schema harness (§8). This rule is the entire mitigation for the "tight state coupling" failure mode
(§10).

| key             | type   | range    | meaning                                                        | owning appraiser |
|-----------------|--------|----------|---------------------------------------------------------------|------------------|
| `safety`        | number | `[0,1]`  | how safe/stable the moment reads (1 = calm, 0 = threat)       | instinct         |
| `tension`       | number | `[0,1]`  | conflict / anger in the air                                   | instinct         |
| `vulnerability` | number | `[0,1]`  | how hurt / fragile the user reads                             | conscience       |
| `warmth`        | number | `[0,1]`  | positive connection / affection                               | heart            |
| `sentiment`     | number | `[-1,1]` | **signed** user polarity — the established source of truth    | (shared)         |
| `engagement`    | number | `[0,1]`  | how invested/present the user is                              | (shared)         |
| `openness`      | number | `[0,1]`  | invitation to respond (a question, an opening)                | (shared)         |
| `tone`          | string | enum     | a **derived** convenience label (see below)                   | derived          |
| `v`             | number | int      | contract version (starts at `1`)                              | —                |

**`sentiment` keeps its existing single source of truth.** It is `societySentiment()` today, which is fed by
`turn.valence` (the affect reader) when present and by cues otherwise — see the comment already in `perceive`. The
appraisal pass inherits that rule unchanged: when the mouth supplies `valence`, it drives `sentiment`; the council
and the affect reader never disagree about how the user feels.

**`tone` is derived, never authoritative.** It is computed by a single pure function `toneOf(vibe)` from the
numeric fields, for logging/readability and as a coarse routing hint. Nothing load-bearing branches on the string;
anything that matters reads the numbers. One derivation function = one source, so the enum-vs-float trap the
architecture notes warned about cannot bite. Suggested labels: `crisis | tender | hostile | tense | playful | warm
| neutral` (the function picks the highest-priority matching band; ties resolve toward the more protective label).

### Calibration (initial, tunable)

The **contract is the keys and ranges**; the coefficients below are a starting calibration, expected to be tuned,
and must not be treated as part of the contract. Grounded in the existing `read(text)` →
`{warmth, distress, humor, anger, question, len}` and `user.sentiment`:

```
sat(x)   = Math.min(1, x / 2)              // cue counts -> [0,1] (presence-ish; 2+ hits saturate)
pos(s)   = Math.max(0, s)                  // positive part of signed sentiment
neg(s)   = Math.max(0, -s)

tension       = clamp01( sat(cues.anger) )
vulnerability = clamp01( sat(cues.distress) * 0.7 + neg(sentiment) * 0.5 )
safety        = clamp01( 1 - Math.max(tension, vulnerability * 0.7) )
warmth        = clamp01( sat(cues.warmth + cues.humor) * 0.6 + pos(sentiment) * 0.5 )
openness      = clamp01( cues.question )    // already 0/1 in read(); leaves room for a graded version later
engagement    = (mean of minds' user.engagement)        // already tracked per mind
sentiment     = societySentiment()                       // unchanged, authoritative
```

**Neutral input must yield a neutral vibe**: no cues, sentiment ≈ 0 → `safety≈1, tension=0, vulnerability=0,
warmth≈0, sentiment≈0, openness=0`. This is what makes §6's parity invariant hold.

---

## 4. Pass 1 — Appraisal (the non-routable core)

A pure builder assembles the `vibe` from the core faculties' reads. The core is **`{ instinct, conscience, heart }`**
— the perceptual/protective faculties. They are the appraisers and (for the two guards) also the floor. They run
**every turn, always**, regardless of config or routing (§6 invariant). They do not propose text and do not vote in
this pass; they only write their dimension.

```js
function appraise(ctx) {
  var turn = ctx && ctx.turn;                      // the user turn under consideration
  var cues = read(turn ? turn.text : '');
  var sentiment = societySentiment();
  var vibe = {
    v: 1,
    tension:       /* instinct  */ clamp01(sat(cues.anger)),
    vulnerability: /* conscience*/ clamp01(sat(cues.distress) * 0.7 + neg(sentiment) * 0.5),
    warmth:        /* heart     */ clamp01(sat(cues.warmth + cues.humor) * 0.6 + pos(sentiment) * 0.5),
    sentiment:     sentiment,
    engagement:    meanEngagement(),
    openness:      clamp01(cues.question)
  };
  vibe.safety = clamp01(1 - Math.max(vibe.tension, vibe.vulnerability * 0.7));
  vibe.tone   = toneOf(vibe);
  return Object.freeze(vibe);                       // immutable once built — strategy reads, never writes
}
```

`Object.freeze` is intentional: Pass 2 **reads** the vibe and never mutates it. (No back-channel writes, no
afferent loop — see §10's no-backtracking note and the accepted limitation.)

The per-faculty attribution in the comments is real, not decorative: it is the contract the router relies on
(instinct owns threat, conscience owns fragility, heart owns warmth). If you later split these into micro-faculties,
each still writes exactly its dimension.

---

## 5. Pass 2 — Strategy (reads the vibe, self-modulates, then the floor still holds)

The live roster forms intents **with the vibe in hand**, so a strategist can damp or lift its own confidence before
anything reaches the veto. `intend` gains an optional second argument; the veto path gains the vibe too.

```js
function intend(ctx, vibe) {
  var last = working[working.length - 1], cues = last ? read(last.text) : {};
  var pull = Math.abs(felt(cues));
  var strength = clamp01(0.3 + self.mood * 0.3 + pull * 0.15 + (self.persona ? 0.15 : 0));
  var kind = intentFor(nation.id, ctx && ctx.frame);
  strength = modulate(nation.id, kind, strength, vibe);   // <-- NEW: vibe-aware, identity when vibe is neutral/absent
  return { by: self.id, kind: kind, strength: strength, persona: self.persona };
}
```

`modulate` is a small, conservative, pure table. **It must be the identity function for a neutral or absent
`vibe`** (so old callers and neutral turns are byte-identical to today — §6). Initial calibration:

```
play:        strength *= (1 - 0.7*vibe.vulnerability) * (1 - 0.6*vibe.tension)   // back off the joke, don't wait to be vetoed
voice:       strength *= (1 - 0.4*vibe.vulnerability)                            // ease the showy register when they're fragile
heart:       strength  = lift(strength, 0.5*vibe.vulnerability)                  // comfort surfaces when it's needed
conscience:  strength  = lift(strength, 0.4*vibe.vulnerability)                  // protection leans in
reason/memory/instinct: unchanged (no modulation) for now
```

(`lift(s, k) = clamp01(s + (1-s)*k)`.) The effect: on a hurting turn, `play` proposes *weakly* and `heart`
proposes *strongly*, so comfort wins the vote on its own — the appraisal shaped the outcome **proactively**. The
veto is **retained unchanged** as the hard floor: if a dampened-but-still-present frivolous intent somehow wins,
`conscience`/`instinct` still block it exactly as today. Proactive modulation + reactive floor = defense in depth.

`voteIntent` may optionally also take `vibe` later (e.g. vibe-aware alignment), but **not in v1** — keep the change
surface small. v1 touches `intend`/`modulate` and threads `vibe` into the existing `veto` read only if a guard's
trigger should read the unified vibe instead of its own `read()` (recommended, but behavior-preserving: the guard
already fires on `user.sentiment < -0.2` and distress/anger cues, which the vibe encodes faithfully).

---

## 6. The two-pass `deliberateIntents` (concrete, additive, sync)

```js
function deliberateIntents(ctx) {
  // PASS 1 — APPRAISAL (fixed core; pure; one shared vibe)
  var vibe = appraise(ctx);

  // ── routing seam (§9): TODAY this is the existing static filter; LATER it becomes route(minds, vibe, ctx),
  //    with the core { instinct, conscience, heart } always present. Appraisal has already run on the core,
  //    so the router only ever selects among STRATEGY faculties. ──
  var live = minds.filter(function (m) { return isOn(m.self.id); });
  if (!live.length) return Promise.resolve({ status: 'no-minds', speaker: null, intent: null, floor: [], vibe: vibe });

  // PASS 2 — STRATEGY (reads the vibe)
  var proposals = live.map(function (m) { var it = m.intend(ctx, vibe); return { by: it.by, text: it.kind, conf: it.strength, intent: it }; });
  var ballots   = live.map(function (m) { var sc = {}; proposals.forEach(function (p) { sc[p.by] = jitter(m.voteIntent(p.intent, ctx) * weightOf(p.by)); }); return { voter: m.self.id, scores: sc }; });
  var vetoes    = [];
  live.forEach(function (m) { proposals.forEach(function (p) { var v = m.veto && m.veto(p, vibe); if (v) vetoes.push(v); }); });

  var decide = (brain && brain.resolve) ? brain.resolve : localResolve;
  var decision = decide(proposals, ballots, vetoes, { vetoQuorum: 1 });
  // ... winner / speaker / intent / floor as today ...
  decision.vibe = vibe;                       // expose the read: debuggable, and the router's input next turn
  return Promise.resolve(decision);
}
```

Diff summary: add `appraise(ctx)`; pass `vibe` into `intend` (and optionally `veto`); attach `decision.vibe`.
Everything else — `live`, `weightOf`, `resolve`, the winner/floor assembly — is untouched. `brain.js` /
`brain.min.js` **do not change**, so no rebuild and no parity run is needed for the core; only the `nation.js`
harnesses move.

---

## 7. Invariants (do not break)

1. **Determinism.** `appraise` and `modulate` are pure; injected `noise:0` stays exactly reproducible.
2. **Neutral-vibe parity.** With a neutral vibe, `deliberateIntents` produces the *same* decision it does today.
   `modulate` is the identity on neutral/absent vibe. This is the regression floor for the whole feature.
3. **Non-maskable core.** `{ instinct, conscience, heart }` always appraise, every turn, regardless of config or
   (future) routing. The guard veto (`conscience`/`instinct`) is always active. Routing may *widen* the roster,
   never drop below this core (§9).
4. **`resolve` stays pure and vibe-blind.** No `vibe`, no weights, no domain knowledge enters the heart. Weighting
   stays in `weightOf` (glue), exactly where it already is.
5. **Frozen schema.** The `vibe` key set + ranges are the contract. Vibe is `Object.freeze`d; Pass 2 never writes it.
6. **Never silent.** If appraisal over-constrains and every intent is dampened/vetoed, `resolve` still seats one
   (its existing all-blocked → contested fallback). She never refuses to speak.

---

## 8. Test plan — `harness-solo-appraise.js` (house style)

New harness, one concern per `ok`, plus existing suites stay green (the change is additive).

- **Schema pin (the coupling guard).** For a spread of inputs (neutral, distressed, hostile, warm, a question),
  assert every contract key is present, every numeric is finite and in range, `sentiment ∈ [-1,1]`, `tone` is one of
  the allowed labels, `v === 1`. This is the test that fails loudly if someone changes a field's shape.
- **Neutral parity.** A neutral turn → vibe reads neutral, and the `deliberateIntents` decision equals the
  pre-change decision on the same input (pin the winner + floor). Guards the regression floor.
- **Proactive modulation, distress.** A distressed turn → `vibe.vulnerability` high, `safety` low; `play`'s
  proposed `strength` is strictly lower than its neutral-turn strength; `heart`'s is strictly higher; the seated
  speaker is a comforting faculty — **with the guard turned off**, proving the *vote* alone (not the veto) produced
  the kind outcome.
- **Floor still holds.** Same distressed turn, guard on, `play` forced to high weight: `conscience` veto still
  blocks `play`/`express`. Defense in depth intact.
- **Hostile / warm.** Hostile → `tension` high, frivolous damped; warm → `warmth` high, `play` free (no veto).
- **Determinism.** `noise:0` → identical vibe and decision across runs.
- **Core is non-maskable.** Even if config "disables" `conscience`/`instinct`/`heart`, `appraise` still includes
  their dimensions (you cannot disable the appraisal core). Pins invariant 3 before routing exists.
- **Route-stub core invariant (forward guard).** Provide `route` as a stub equal to today's `isOn` filter and
  assert its result always contains the core ids. When real routing lands, this test already protects the floor.

---

## 9. The routing seam (how the Hierarchical layer slots on top — defined, not built here)

This feature deliberately leaves two named seams so the router is a drop-in, not a rewrite. **Routing is out of
scope for v1**; only the seams and their invariants are fixed here.

- **Membership.** Today: `var live = minds.filter(m => isOn(m.self.id))`. Later:
  `var live = route(minds, vibe, ctx)`. `route` is **pure**, **fails open** (when unsure, seat *more*), and is
  bound by invariant 3: its result is always a superset of the non-routable core. Because Pass 1 already ran on the
  fixed core, the router only ever selects among **strategy** faculties — it can never deprive the turn of its
  appraisal or its floor. (This is why the order is appraise-then-route, not route-then-appraise.)
- **Weighting.** Today: `weightOf(p.by)`. Later: `weightOf(p.by, vibe)` — relevance/competence becomes a function
  of the read. This is where the "domain competence matrix" belongs: **in `weightOf`, outside `resolve`**, exactly
  where weighting already lives. It does **not** go into the resolver.
- **No sleep-based pruning.** Routing selects the member *set*; it must not express itself by toggling
  `nervous.setState(id,'asleep')`. Sleep/standby is the council's *liveness* mechanism, and `deliberate`'s
  `wakeStalled()` reawakens sleepers each round — overloading it for routing fights the watchdog. (The hot path
  doesn't touch the bus at all; the bus registry/`find`/`setState` is the separate, extensible *plugin-host* track
  for the async council, not the everyday router.)
- **Grow by addition.** Adding a faculty stays a local act: add a mind with its lean (hot path) or `register` a
  faculty with `does[]` (bus). No central router switch to edit. The route function reads each faculty's declared
  domain/cues; it never hardcodes a roster.

The router's *input* is `decision.vibe` (or the current turn's `appraise`); the router's *job* is to turn a read
into a seated room. Build the read first (this doc); the room comes next.

---

## 10. Out of scope (and why)

- **Async / tick-based blackboard** — breaks the determinism and testability everything here relies on. The
  synchronous two-pass keeps the win (shared appraisal, appraise-then-act) without the cost.
- **Synaptic plasticity / self-warping vote weights** — instability risk (runaway dominance, oscillation), and it
  gets *worse* combined with dynamic routing (two coupled feedback loops). Bonds/sentiment already give bounded
  adaptation. Not now.
- **Speculative prefetch** — optimizes the ~microsecond brain, not the ~second model call. No user-visible latency
  to win. Not now.
- **The router itself / competence matrix values** — §9 fixes the seams and invariants; the route function and the
  per-domain weights are the *next* design doc, written against the `vibe` this one defines.
- **No-backtracking feedback loop** — a single forward appraise→strategize pass can misread (e.g. sarcasm as
  threat) and act on it. For a 1:1 companion this is an accepted limitation, backstopped by invariant 6 (never
  silent). If it proves real in practice, the minimal future hook is a *single* re-appraise when the strategy pass
  comes back `contested`/all-vetoed — **not** a general afferent-efferent loop.

---

## 11. Build order

1. Add the pure helpers: `sat`, `pos`, `neg`, `meanEngagement`, `toneOf`, `appraise`, `modulate`. (`nation.js`,
   glue layer — `brain.js` untouched.)
2. Thread `vibe`: `intend(ctx, vibe)` + `modulate`; attach `decision.vibe`; optionally pass `vibe` into `veto`.
3. Write `harness-solo-appraise.js` (§8). Add the `route` stub + its core-invariant test.
4. Gauntlet: `node --check nation.js`; run all nation/council/veto harnesses (must stay green — additive change);
   confirm neutral-parity pin. No `brain.min.js` rebuild needed.
5. Only then start the routing-layer design doc, written to consume `vibe`.

The Brain stays pure, odd, and never silent; the appraisal lives one layer up, where perception belongs; and the
room the router will later seat is chosen on a read this pass makes honest and explicit.


<br>

---

# Part V — Design — The Routing Layer (built for scale)

> **For the engineer/agent building this:** this is a design, not a patch. It sits **on top of the Appraisal
> Chamber** (`DESIGN-appraisal-chamber.md`): it consumes the frozen `vibe` and turns it into a *seated room*. The
> declared end goal is **scale** — a large fleet of faculties (imagine one per knowledge subject, some running as
> remote servers) with this code as the backbone. So every seam here is judged twice: does it work at seven, and
> does it survive a thousand. The build is **staged** (the parity-safe slice ships first), but nothing in the
> staging may bake in a seven-faculty assumption that shatters at N-large. Synchronous, pure, deterministic,
> fail-open, parity-safe on day one. Companion to `DESIGN-council.md` and `DESIGN-appraisal-chamber.md`.

---

## 1. The end goal: a fleet, not a council of seven

Seven faculties is the seed, not the target. The target is a large, growing fleet — many specialized faculties,
some local and pure, some potentially remote services — with this Brain as the routing and arbitration backbone
others build on. That ambition sets the bar: **a backbone can't have hidden state, undocumented coupling, or
contracts that only hold at small N.** The discipline already in this codebase (a pure heart, frozen contracts,
harness-pinned invariants, a cold-start handoff) is exactly what infrastructure requires; this doc keeps it.

Two consequences shape everything below:

- **The vote is O(N²).** Every deliberator proposes and every deliberator scores every proposal. At seven that's
  ~49 trivial ops; at a thousand it's ~10⁶ per turn before `resolve` runs. The routing *tree* exists to cut N down
  to a small seated set **before** the vote, so `resolve`'s cost tracks the *seated-room* size, not the fleet size.
- **Not every faculty belongs in the ballot.** The council votes to arbitrate competing *intentions*. A history
  faculty and a math faculty don't disagree about intent — they *supply material*. A thousand of them casting
  ballots would drown the decision in retrieval noise. So scale forces a split in the node model (§2).

The staging still holds — ship the parity-safe weighting first (§7) — but we lay the scale seams (bounded-K,
the registry index, the contributor tier) now, dormant, so we never have to retread.

---

## 2. The shape that makes scale work: deliberators vs contributors

The single most important refinement for scale. Faculties divide into two kinds:

- **Deliberators** — they *vote on what to do*. Pure, local, synchronous, in the ballot. Subdivided into:
  - **Core deliberators** `{ instinct, conscience, heart }` — *who she is*. Always seated, non-routable, the
    appraisal/guard floor. Never dropped, never remote.
  - **Strategist deliberators** `{ reason, voice, play, memory, ... }` — routed and weighted by the vibe, but still
    local, pure, and in the ballot.
- **Contributors** — they *supply material*. Routed **in** on demand to inform the decision, but **never in the
  ballot**. They may be remote, async, and timeout-guarded. This is where the knowledge fleet lives — *what she
  knows*, consulted, not a thousand competing selves.

```
[ turn ] -> appraise -> vibe
                 |
                 v
   route(vibe, ctx):  (a) seat a bounded set of DELIBERATORS (core + top-K strategists)
                      (b) select which CONTRIBUTORS to consult (by domain/capability)
                 |
                 v
   consult contributors  --(async, withTimeout, mandatory default)-->  material -> ctx (additive context)
                 |
                 v
   deliberators propose / vote / veto over the enriched ctx  ->  resolve (pure)  ->  speaker + intent
```

`resolve` only ever sees **deliberator** ballots. Contributors feed `ctx`; deliberators decide how to use what came
back. This is the honest hierarchical tree: you route to *which subjects to consult*, they return facts, and a
small council decides. It also resolves the determinism tension a remote fleet raises — see §8.

---

## 3. The two seams on the hot path

The everyday path is `deliberateIntents` (sync, no bus). It exposes two seams.

```js
// today:
var live = minds.filter(function (m) { return isOn(m.self.id); });        // seam 1: membership
... jitter(m.voteIntent(p.intent, ctx) * weightOf(p.by)) ...              // seam 2: weight
```

Routing replaces these with vibe-aware versions that operate on **deliberators**:

```js
var live = route(minds, vibe, ctx);                                       // seam 1 -> the router (bounded)
... jitter(m.voteIntent(p.intent, ctx) * weightOf(p.by, vibe)) ...        // seam 2 -> relevance weight
```

Contributor consultation is a third step that happens **inside `route`/before the vote** and writes into `ctx`; it
is not one of these two ballot seams (contributors don't vote). See §8.

**Not the router:** the nervous-bus registry (`find`/`does`/`setState`/`register`) lives on the *async council*,
not the hot path. At seven it's a plugin nicety; at scale it *is* the router's **capability index** (§5, §8) — how
`route` discovers which contributors can serve a domain without enumerating the fleet. Sleep/standby stays the
council's liveness mechanism (`wakeStalled` reawakens sleepers), never a pruning lever. `resolve` stays pure.

---

## 4. The `vibe` it consumes

Unchanged from `DESIGN-appraisal-chamber.md`: `{ safety, tension, vulnerability, warmth, sentiment, engagement,
openness, tone, v }`. Read-only here (the vibe is frozen). `decision.vibe` is already attached each turn, giving the
router its input for this turn and as last-turn context.

---

## 5. Faculty metadata (what makes "grow by addition" safe at scale)

Each faculty record (`NATIONS`, today `{ id, purpose, lean }`) gains four optional fields. The router reads these;
it never hardcodes a roster, so adding a faculty — local or remote — is a single local record.

```js
{
  id: 'play',
  purpose: 'Keep it alive, curious, and human.',
  lean: { open: 1.0, play: 0.5 },                 // existing — the gauge lens
  kind: 'deliberator',                            // NEW: 'deliberator' (votes) | 'contributor' (supplies material)
  core: false,                                    // NEW: true = non-routable, always seated (deliberators only)
  domain: ['banter', 'roleplay'],                 // NEW: experiential/knowledge domains — the registry index key
  relevance: function (vibe) {                     // NEW: pure [0,1], CENTERED AT 0.5 on a neutral vibe
    return clamp01(0.5 + (vibe.warmth + vibe.openness) * 0.4 - (vibe.vulnerability + vibe.tension) * 0.6);
  }
}
```

Contract:

- **`kind`** — `'deliberator'` (default) or `'contributor'`. Only deliberators enter the ballot and `weightOf`.
  Contributors are consulted via §8. A contributor record may also carry `does: [{ name }]` (the bus capability
  list) so the registry can index it.
- **`core`** — `true` only for `{ instinct, conscience, heart }`; structurally always seated. Default `false`.
- **`domain`** — experiential domains for deliberators (`support`, `roleplay`, `lore`, `banter`, `meta`) and
  knowledge domains for contributors (the Dewey-style subjects). This is the key the router/registry selects on.
- **`relevance(vibe) -> [0,1]`** — for deliberators, drives weight and top-K seating; for contributors, drives
  whether to consult. **Must return ~0.5 on a neutral vibe** so weighting is parity-safe (§7). Default: constant
  `0.5`.

A record without the new fields is a non-core, general, neutral-relevance deliberator — exactly today.

---

## 6. `route(minds, vibe, ctx)` — choosing a *bounded* room

Pure, deterministic, fails open, always seats the core, and — for scale — **bounded**. Fail-open does NOT mean
"seat everyone" (a seven-faculty luxury that's fatal at a thousand); it means "core plus the **top-K** most
relevant strategists" — generous when unsure, never unbounded.

```js
function route(minds, vibe, ctx) {
  var deliberators = minds.filter(function (m) { return (m.kind || 'deliberator') === 'deliberator'; });
  var seated = [];
  deliberators.forEach(function (m) { if (m.core) seated.push(m); });                 // 1. the non-routable floor
  var pool = deliberators.filter(function (m) { return !m.core && isOn(m.self.id); }); // 2. routable, user-on
  pool.sort(function (a, b) {                                                          //    by relevance, desc
    return (b.relevance ? b.relevance(vibe) : 0.5) - (a.relevance ? a.relevance(vibe) : 0.5);
  });
  var K = seatBudget(deliberators.length);            // 3. bounded fan-in: small N -> all; large N -> top-K
  for (var i = 0; i < pool.length && seated.length < seated.length + K; i++) seated.push(pool[i]); // (top-K)
  if (seated.length % 2 === 0) seated = odden(seated, pool, vibe);                     // 4. odd / tie-safe
  return seated.length ? seated : deliberators.filter(coreOrOn);                       // 5. never empty
}
```

`seatBudget(n)` is the one scale knob: at small `n` it returns `n` (seat all — today's behaviour, parity), and as
`n` grows it caps at a bounded `K` (e.g. `min(n, 9)` or a configured ceiling). **The bounded path exists from v1**,
dormant while `n` is small; it never has to be retrofitted.

Invariants (the tests pin these, not specific rooms):

1. **Core always present** — `instinct`, `conscience`, `heart` are in every room; routing widens, never subtracts
   below the floor (the `conscience`/`instinct` veto needs them live).
2. **Bounded fan-in** — the seated set is `≤ |core| + K`; `resolve`'s cost tracks the seated set, not the fleet.
3. **Fail open** — unknown/neutral vibe → core + the top-K (at small N, everyone); over-inclusion's worst case is
   today's council; under-inclusion would silently drop a voice, so when unsure, seat more (up to the bound).
4. **Pure & deterministic** — no `now()`, no RNG, no mutation; same inputs → same room. (Ties in relevance break by
   stable faculty order.)
5. **Config wins** — a faculty the user turned off stays off (core excepted, structural).
6. **Odd / tie-safe, never empty, never silent** — preserved as today.

**v1 = fail-open identity:** with `seatBudget(7) === 7`, the room is unchanged. The machinery (core-pinning,
bounded loop, fallback) is in place and tested; the bound only bites once the roster grows.

---

## 7. `weightOf(id, vibe)` — the parity-safe v1 win, and the top-K score

Applies to **deliberators**. It scales the user's configured weight by a bounded relevance multiplier — louder when
relevant, quieter when not, never zero, and **exactly the configured weight on a neutral vibe**.

```js
function weightOf(id, vibe) {
  var base = (cfg.weights || {})[id]; base = (base == null) ? 1 : Number(base);
  if (!vibe) return base;                                   // old callers unchanged
  var m = mindOf(id), rel = (m && m.relevance) ? m.relevance(vibe) : 0.5;
  return base * (0.5 + rel);                                // rel 0.5 -> 1.0x (parity);  [0,1] -> [0.5x, 1.5x]
}
```

- **Parity floor:** every `relevance` returns `0.5` on a neutral vibe → `weightOf(id, neutralVibe) === base`. The
  change is invisible on flat turns.
- **The signal:** the same `relevance` that weights the vote also ranks the top-K seating in §6 — one function,
  two uses, no second source. The "competence matrix" lives here, in `weightOf`, **outside `resolve`**.

Ship this first: real value, fully parity-safe, no pruning required.

---

## 8. Contributors and the async tier (how the fleet plugs in without poisoning determinism)

A contributor is consulted, not voted. The flow, reusing machinery the async council already has:

1. **Select** — `route` asks the registry which contributors serve the turn's domain(s):
   `nervous.find('history')`, `nervous.find('lore')`. At scale this index is load-bearing — it's how the router
   avoids enumerating the fleet.
2. **Consult** — each selected contributor is invoked behind **`withTimeout(call, ms, DEFAULT, sched)`** with a
   **mandatory default** (empty contribution). The council was built for exactly this: "the node didn't answer in
   time → take the default, move on." A remote, networked, non-deterministic service is fine here because a timeout
   yields a defined empty result and the decision proceeds.
3. **Fold** — returned material is written into `ctx` (e.g. `ctx.material`), additive context the deliberators may
   read. It is **never** a second source of truth for who feels what — the `vibe` stays authoritative.
4. **Decide** — core + seated strategist deliberators propose/vote/veto over the enriched `ctx` → `resolve`. The
   ballot contains only deliberators; contributors influence *content*, not the *vote*.

So: **deliberators stay pure, local, synchronous; contributors may be remote, async, timeout-guarded.** Two
execution models, one `resolve`. The determinism of the *decision* is preserved because the only async part is
retrieval, and retrieval is timeout-bounded to a default — the same discipline that already keeps a stalled council
member from hanging a turn.

(The synchronous hot path stays the deliberator path. The contributor tier is the async council's domain — which is
why the bus registry, not the hot-path router, is where contributors register and are discovered.)

---

## 9. Group spaces (faculties handling a beat together)

A "group space" is a routed sub-room sharing the frozen `vibe`. At scale, a group is a **small deliberator core +
routed contributors** for the beat: a roleplay scene seats `{ scene, voice, play } ∪ core` as deliberators and
consults `{ lore, continuity, the relevant subject contributors }` for material. The group decides through the same
`resolve` on the same `vibe` — no second decision path, the protective core in every group. Domain material rides
`ctx` (`ctx.scene`, `ctx.material`) as additive context; the vibe remains the authoritative read of feeling.

---

## 10. Taxonomy — who she is vs what she knows

- **Deliberators are experiential** — `support`, `roleplay`, `banter`, `meta`. The core `{ heart, conscience,
  instinct }` is *who she is*: always seated. Strategists shape *how* she responds.
- **Contributors are knowledge** — the Dewey-style fleet, *what she knows*: routed in, consulted, never voting.

This is what lets her stay herself at a thousand faculties: the thousand are tools she consults, not a thousand
competing selves. The core/strategist/contributor tiers are the mechanism, not a slogan.

---

## 11. Invariants (consolidated)

1. Core `{ instinct, conscience, heart }` always seated; routing widens, never subtracts below it.
2. The `conscience`/`instinct` veto floor is always live (follows from 1).
3. Only **deliberators** vote; **contributors** never enter the ballot.
4. **Bounded fan-in:** the seated deliberator set is `≤ |core| + K`; `resolve` cost tracks the seated set, not the
   fleet.
5. `route` and `weightOf(vibe)` are pure and deterministic; the `vibe` is read-only.
6. **Fail open is bounded:** unknown/neutral → core + top-K (at small N, everyone); never unbounded, never below
   core.
7. `resolve` stays pure and weight-blind; all weighting is in `weightOf`.
8. **Contributors are off the deterministic vote path:** consulted async behind `withTimeout` + a mandatory
   default; a timeout yields an empty contribution and the decision proceeds. Deliberators stay pure/sync.
9. No sleep-based pruning; routing selects a member set. User config is honoured (core excepted).
10. Odd / tie-safe; never empty; never silent.
11. Grow by addition: a new faculty (deliberator or contributor) is one record with
    `kind`/`core`/`domain`/`relevance`; no central switch.

---

## 12. Test plan — `harness-solo-route.js` (pin invariants, including scale)

- **Core always seated** across crisis/hostile/warm/neutral, even with config disabling them.
- **Fail-open parity (small N).** Neutral vibe → `route` returns every on deliberator; `weightOf(id, neutralVibe)
  === weightOf(id)` for all. The regression floor.
- **Relevance shifts weight, not membership (v1).** Tense vibe → `weightOf('play', vibe) < weightOf('play')`, play
  still seated; warm → `>`. Nobody dropped.
- **Bounded fan-in (scale).** Inject a synthetic roster of, say, 30 strategist deliberators; assert
  `route(...).length <= core + K`, the room is odd, and the core is present. Pins that the bound works *before* the
  fleet exists.
- **Top-K picks the relevant.** With many faculties, on a given vibe the seated strategists are the K highest by
  `relevance(vibe)` — deterministically.
- **Contributors never vote.** A registered `kind:'contributor'` faculty is consulted (its material lands in `ctx`)
  but never appears in `decision.transcript.ballots`/`participation`.
- **Contributor timeout → default, decision proceeds.** A contributor that never resolves yields an empty
  contribution within the timeout and the turn still decides (mandatory-default discipline).
- **Determinism.** Same vibe → same room, same weights, same decision.
- **Add-a-faculty-no-regress.** A new non-core faculty leaves neutral-vibe decisions unchanged and only gains
  weight/seating on its domain's vibe.
- Existing suites (council/veto/nation/nation-extra/appraise) stay green — additive.

---

## 13. Migration / build order (staged, scale-seams dormant from v1)

1. Add `kind`/`core`/`domain`/`relevance` to `NATIONS`; `core:true` on `instinct`/`conscience`/`heart`; relevance
   centered at 0.5. (Defaults cover untouched records.)
2. **Ship `weightOf(id, vibe)`** (the v1 win) + thread `vibe` into the ballot call. Parity test first.
3. **Ship `route`** as bounded fail-open with `seatBudget(7) === 7` (identity at current N); wire `var live =
   route(minds, vibe, ctx)`. Pin core-always + bounded-fan-in (with a synthetic large roster) now, so the bound is
   proven before it's needed.
4. Write `harness-solo-route.js` (§12); keep all suites green. No `brain.js` rebuild (nation-layer).
5. **Lay the contributor seam dormant:** define `kind:'contributor'`, the `route`→registry→consult→`ctx` path, and
   the `withTimeout`+default consultation on the async council — even with zero contributors registered — so the
   tier exists and is tested before the first remote faculty arrives.
6. Then, as the fleet grows: real contributors (registered on the bus, discovered by `find`), per-domain group
   rooms, and `seatBudget` tuned to bite.

---

## 14. Out of scope (and why)

- **Plasticity / self-warping weights** — instability, worse with dynamic membership. Relevance is a *pure function
  of the current vibe*, not an accumulating weight. Keep it pure.
- **Speculative prefetch** — optimizes the microsecond brain, not the model/contributor latency. No win.
- **Async on the *deliberator* path** — breaks determinism. Async belongs to the *contributor* tier only (§8).
- **Building the actual fleet** — this doc defines the router, the metadata, and the two tiers faculties plug into;
  designing the first real specialized faculty (deliberator) and the first contributor is the next step, written
  against these contracts.

---

## 15. Parked for future-us (not now)

A reactive **plugin UI** on top of this: abilities/contributors lazy-load on start and "ready up" in the interface
as they come online, and the app keeps a **persisted capability index** so startup doesn't re-probe every plugin's
ready-state on each reload. This rides existing seams — the index *is* the bus registry (`find`/`does`); a
not-yet-ready ability *is* a contributor that times out to its default (§8), so the brain never blocks on a
half-loaded fleet and the UI just subscribes to readiness. **One discipline to remember when we build it:** the
cached index is *optimistic*, not ground truth — render cached capabilities instantly, then reconcile each
ready-state in the background and update the UI reactively; a stale-but-dead plugin simply times out to its default.
Cache for speed, reconcile for truth. (Presentation-layer + persistence work; no change to the pure decision path.)

---

Routing is the room; the vibe is the read it stands on; `resolve` is the judge underneath. Build the weighting
first (parity-safe, real value), keep the core non-routable, bound the fan-in from day one, let contributors inform
without voting, and let the fleet grow one safe record at a time.


<br>

---

# Part VI — Design — Specialists, Addressing & the Fringe

> **For the engineer/agent building this:** this sits on top of the Appraisal Chamber and the Routing Layer. Those
> two answered *what kind of moment is this* and *which of her selves should be in the room*. This one answers a
> different question the fleet forces: **what kind of NODE is a faculty, can it be called by name, and does it know
> where its own competence ends?** It introduces a node archetype that isn't a full mind (the *specialist*), a way
> to address any node directly (`/nation`), and a way for a node to declare its edges so it can defer and nominate
> (the *fringe*). It is deliberately staged: the first slice (`/nation` self-report) is pure and changes no
> behaviour. Companion to `DESIGN-appraisal-chamber.md` and `DESIGN-routing-layer.md`; as-built deltas live in
> `CHANGELOG-brain.md`.

---

## 1. Why this isn't subdivision

Subdividing `memory` into `recall` + `continuity`, or `instinct` into `threat` + `wrongness`, splits one signal
into two nodes **of the same kind** — both still full minds that feel, model the user, hold bonds, and vote. It
redistributes existing signal; it doesn't add a capability.

The fleet needs something else. Most of a thousand Dewey-scale faculties **won't have an emotion or a memory**, and
many are **only one thing** — a lookup, a fact, a single skill. Forcing each into the full `createMind` apparatus
(temper, mood, bonds, a user-model, a ballot) is wrong three ways: it's wasteful, it pollutes the vote with a
thousand non-opinions (§ routing-layer 1), and it's dishonest — a history node doesn't *feel* anything about your
turn, it either knows the answer or it doesn't.

So the unlock is a new **axis**, not a finer cut on the old one:

- **a node archetype with variable apparatus** — a *specialist* that can speak and defer but doesn't feel or
  remember (§4);
- **addressing** — call any node by name, around the vote but never around the floor (§5);
- **the referral fringe** — a node declaring the edges of its own competence, so it can defer honestly and nominate
  others (§6).

All three are the same shift: from *uniform full minds chosen by a central vote* → *heterogeneous nodes with
declared competence that can be addressed, can defer, and can nominate each other.*

---

## 2. The node taxonomy, completed

The routing-layer doc split faculties into **deliberators** (vote) and **contributors** (supply material). This doc
fills in what a contributor actually *is* and adds the operations that make a large fleet tractable.

| | **Core deliberator** | **Strategist deliberator** | **Specialist (contributor)** |
|---|---|---|---|
| examples | heart, instinct, conscience | reason, voice, play, scene, boundaries | history, medicine, a single skill |
| *who/what* | **who she is** | **how she responds** | **what she knows** |
| feels / has mood | yes | yes | **no** |
| models the user / bonds | yes | yes | **no** |
| votes in the ballot | yes (always seated) | yes (routed) | **never** |
| supplies material (`consult`) | — | — | **yes** |
| addressable by name (§5) | yes | yes | yes |
| can be promoted to speaker | yes (wins the vote) | yes (wins the vote) | **yes — by addressing/nomination** |
| has a `fringe` (§6) | optional | optional | **yes (the point)** |
| may be remote / async | no | no | **yes** |

The three left columns are *her*; the right column is *her tools*. That's what lets her stay one person at a
thousand faculties: the thousand are consulted specialists, not a thousand competing selves.

---

## 3. The three decisions (pinned)

### Decision 1 — Does a specialist vote? **No.**

A specialist is a contributor: it never enters the routine ballot (that's what keeps the O(N²) vote bounded and the
decision deterministic — § routing-layer 1, 8). But it is **addressable** (a user can summon it) and **nominable**
(a deliberator can call it in), and when addressed or nominated its material can be **promoted to be the speaker**
for that turn. Promotion is the controlled exception to "the vote picks the speaker": addressing picks the speaker
*directly*. It is **never** an exception to the floor — see Decision/Invariant in §5.

> Rejected alternative: letting specialists cast low-weight ballots. It reintroduces the retrieval-noise drowning
> problem at scale and couples a remote, possibly-timing-out node into the synchronous deterministic vote. Consult,
> don't enfranchise.

### Decision 2 — How is the fringe represented? **A plain adjacent-domain list (now); weighted edges parked.**

```js
{ id: 'history', domain: ['history'], fringe: ['geography', 'politics', 'art'] }
```

`domain` is what it **owns** (professional); `fringe` is what it **recognizes but doesn't own** (amateur — enough
to know who to call). A plain list is one local record, no graph to keep consistent — it preserves grow-by-addition
(§ routing-layer 11). **Weighted referral edges** (a node rating *how strongly* it points each way) are deferred:
they're a graph with its own consistency burden, and we adopt them only if flat lists prove too coarse in practice
(§11).

### Decision 3 — The shape of "speak for itself". **A pure structured self-report + a first-person line.**

Every node answers `selfReport(vibe)` — a structured, side-effect-free description of *who it is and where it
stands in this moment* — plus a deterministic first-person `says` string so it can speak for itself with no model
call. Two surfaces consume it: the user-facing summon and the debug inspector (§5, §7). It reads only state that
already exists, so it changes no behaviour.

---

## 4. The specialist archetype — variable apparatus

Today `createMind` bundles everything into every faculty: `temper`/`mood` (emotion), `user`/`bonds` (a
user-model), `working` (memory), and `intend`/`voteIntent`/`veto` (a vote). A specialist needs almost none of it.

The build is to make the apparatus **modular** — a node declares what it has, and the machinery provides only that:

- **full mind** (deliberator) = perception + emotion + user-model + memory + vote + `selfReport`.
- **specialist** (contributor) = a `domain`, a `fringe`, a `consult(ctx, vibe) -> material`, and `selfReport`.
  No temper, no bonds, no ballot. It may be a local pure function or a remote service behind `withTimeout`.

The shared protocol across all node kinds is exactly two methods: **`selfReport(vibe)`** (everyone) and the
kind-specific work method (`intend`/`voteIntent`/`veto` for deliberators, `consult` for specialists). This is
"grow by addition" applied to the *machinery*, not just the roster: a new specialist is one record with a
`consult`, not a full mind.

> Staging note: in the current sandbox `minds = roster.map(createMind)` gives every record a full mind. The
> self-report slice (§ build order 1) works inside that uniform model; factoring `createMind` into a lean
> `createSpecialist` path is build-order step 3, after the protocol exists.

---

## 5. Addressing — `/nation`

A path to a node that goes **around the vote**. Two modes, one protocol; the app parses the command, the brain
answers it.

```
/nation                  -> inspect the whole council (the debug layer): every node's selfReport, ranked by
                            relevance to the live vibe, with the would-be room and each node's standing.
/nation <id>             -> that node speaks for itself: its selfReport + first-person `says`. (User summon.)
/nation <id> --speak     -> PROMOTE: <id> is made the speaker for this turn; its intent/material becomes the reply
                            (subject to the floor — see the invariant).
```

- **User summon** is the memory-recall case: "let me hear from memory" → memory reports/speaks for itself.
- **Debug** is `/nation` (or `--why` on one node): a faculty reports its live standing — relevance, whether it'd
  seat and why, what it last proposed. Observability falls out for free because every node already carries this
  state; we're only exposing it.

**The one hard invariant — addressing overrides the *vote*, never the *floor*.** You can summon `scene` or `play`,
but if she reads the user in crisis, `conscience`/`instinct` still veto exactly as in a normal turn. Addressing
selects *who tries to speak*; the guards still decide *whether that's allowed*. A promoted speaker runs the same
veto gate as a vote-winner. (This is why promotion routes through the existing resolve/veto path, not around it.)

---

## 6. The referral fringe — honest deferral and mutual nomination

The registry (`find(domain)`) is the **central** index: "who serves X?" The fringe is its **distributed**
complement: a node knowing where its *own* competence ends. That buys two things a central index can't:

- **Honest deferral.** A history specialist asked a medical question consults its `domain`/`fringe`, sees the topic
  is neither, and says *"not mine — that's medicine's,"* instead of confidently inventing an answer. This is the
  same "honest about its constraints" discipline the boundaries card already embodies, pushed down to every node.
- **Mutual nomination (distributed routing).** A seated deliberator, reading the turn, calls in a specialist *by
  domain* — `nominate('medicine')` → the router consults that specialist this turn. The fleet routes itself from
  the edges; the central router doesn't have to know all thousand nodes, only how to resolve a domain to a node.

Nomination is consultation, not enfranchisement (Decision 1): a nominated specialist supplies material (or is
promoted to speaker if addressed), it does not gain a vote. A specialist's "fringe" gives it just enough peripheral
awareness to hand off well — the *minor amateur skill set* on top of its *one professional domain*.

---

## 7. The self-report shape (the §3 artifact, concretely)

```js
selfReport(id, vibe) -> {
  id, kind,                     // 'core' | 'deliberator' | 'contributor'
  core,                         // bool
  purpose,                      // its declared job
  domain: [...], fringe: [...], // what it owns / recognizes
  relevance,                    // relevanceOf(id, vibe) — how this moment reads to it, [0,1]
  wouldSeat,                    // route(vibe) includes it (deliberators)
  standing,                     // 'core'|'seated'|'benched'|'consulted'|'idle'|'off'
  lastIntent,                   // {kind, strength} it last proposed, or null
  spokeLast,                    // was it the speaker last turn
  // full minds only (specialists omit these):
  mood, reads,                  // 'warming'|'steady'|'struggling'
  lastSaid,
  says                          // a deterministic first-person line built from purpose + standing + relevance
}
```

`inspect(vibe)` returns `{ vibe: <summary>, room: [seated ids], council: [selfReport...] sorted by relevance }`.
It does **not** run a deliberation (no jitter, no side effects) — it shows who's *in the running* and how relevant
each reads, which is the debug value; *who actually wins* stays the vote's job.

---

## 8. Invariants (do not break)

1. **Specialists never vote.** They are consulted; they may be promoted to speaker only by addressing/nomination.
2. **Addressing overrides the vote, never the floor.** A summoned/promoted node still passes the
   `conscience`/`instinct` veto. The guards are never disabled by `/nation`.
3. **Self-report is pure.** `selfReport`/`inspect` read existing state and never mutate the decision path; with
   them unused, every decision is byte-identical (the regression floor for the first slice).
4. **Grow by addition.** A new specialist is one record (`kind:'contributor'`, `domain`, `fringe`, `consult`); a
   new fringe edge is one list entry. No central switch, no graph rebuild.
5. **The fringe is declarative.** Until the nomination slice lands, `fringe` is read-only metadata that changes no
   routing; adding it to a record is parity-safe.
6. **Deterministic addressing.** `/nation <id>` and `inspect` are pure functions of (roster, state, vibe); same
   inputs → same report.

---

## 9. Test plan

- **Self-report is pure (regression floor).** A run with `inspect`/`selfReport` called all over it produces the
  same decisions as a run without — byte-identical winners/floors.
- **Per-faculty standing.** On a tender vibe, `play.selfReport.standing === 'benched'` and `relevance < 0.5`; on a
  playful vibe, `'seated'` and `> 0.5`. On every vibe, the three core read `standing:'core'`.
- **`says` speaks in the first person** and reflects standing (a benched node says it's sitting out; a relevant one
  says it'd take the floor). Deterministic — no model call.
- **`inspect` ranks by relevance** and its `room` equals `route(vibe)`; it never runs a deliberation.
- **Addressing overrides the vote.** `/nation play --speak` on a neutral turn makes `play` the speaker; the **same
  command on a crisis turn is vetoed** and a guard speaks instead. Pins invariant 2.
- **Unknown id** is handled (reports the error + the known roster), never throws.
- **Fringe is declarative/parity-safe.** Adding `fringe` to records leaves all existing suites green.
- Existing suites (council/veto/nation/nation-extra/appraise/route/contrib/bound/scene/stress) stay green.

---

## 10. Build order (staged; first slice is pure)

1. **`/nation` self-report (this slice).** `selfReport(id, vibe)` + `inspect(vibe)` + an `address(text, vibe)`
   parser for the `/nation` command; stash last-turn intents/room additively in `deliberateIntents`. Pure, zero
   behaviour change. Harness: purity + standing + `says` + inspect-ranking + unknown-id.
2. **Addressing promotion.** `/nation <id> --speak` routes <id> through the existing resolve/veto path as the
   proposed speaker; pin "overrides the vote, not the floor."
3. **The specialist archetype.** Factor a lean `createSpecialist` (no temper/bonds/vote; `consult` + `selfReport`);
   register the first real specialist (a `lore`/`continuity` contributor — scene's companion) on the contributor
   tier. Pin "specialists never vote."
4. **The fringe, made live.** `nominate(domain)` from a seated deliberator → the router consults that domain's
   specialist this turn; honest-deferral path when a topic is outside `domain ∪ fringe`. Pin distributed routing.
5. Later: per-domain group rooms; `seatBudget` tuned to bite (we're at 9 = the cap now, so the 10th node triggers
   real top-K pruning — already noted in the changelog).

---

## 11. Out of scope (and why)

- **Weighted referral edges** — a graph with a consistency burden; a flat `fringe` list preserves grow-by-addition.
  Adopt only if flat lists prove too coarse (Decision 2).
- **Specialists voting** — reintroduces retrieval-noise at scale and couples async nodes into the deterministic
  vote (Decision 1). Consult, don't enfranchise.
- **Letting addressing bypass the guards** — would make `/nation` a jailbreak around the protective floor; the
  invariant in §5/§8 forbids it.
- **A full plugin UI / persisted capability index** — already parked in `DESIGN-routing-layer.md §15`; the
  self-report is the data such a UI would subscribe to, but the presentation layer is separate work.

---

Specialists are her tools, not more of her selves; addressing lets you reach one by name without dissolving the
vote; the fringe lets each node know where it ends and who to call next. Build the self-report first — it's free,
it makes the whole council inspectable, and it's the protocol everything else here reuses.


<br>

---

# Part VII — Patch Plan — the bug triage (T1–T7, B1–B2)

> **STATUS — 2026-06-16: Tasks 1–5 LANDED** in `brain-handoff/` (and the shipped `brain.min.js`), each pinned by a
> test; `npm test` + `npm run parity` all green. Held (not bugs): **Task 6** (per-mind `user` redundancy refactor)
> and **Task 7** (peer spoken-text consistency) — verified but cosmetic/inert today, awaiting a go-ahead.
> Deferred design calls: **B1** (clear/calm length cliff) and **B2** (`'shared'` drive mapping). See the README
> Patch log in the handoff package for the per-task summary.


> **For the engineer/agent executing this:** every claim below was checked against the actual source before being
> planned. Where a review's *fix* was wrong or its *diagnosis* overstated, the corrected version is in the task.
> Work top-to-bottom; tiers are ordered by certainty and value. This package has no git — "validate" steps replace
> "commit" steps. Steps use `- [ ]` for tracking.

**Goal:** Apply the genuinely-correct fixes from the two reviews to `brain.js` / `nation.js`, with a test pinning
each, while rejecting the non-issues and surfacing the two items that are actually design decisions, not bugs.

**Architecture:** The Brain is pure, deterministic, DOM/network-free. `brain.js` is the resolver/Society; `nation.js`
is the Seven Nations above it (injected `brain`). Tests are plain-Node harnesses that print `ALL GREEN`. Any
`brain.js` change must be followed by `bash build-brain.sh` + a parity run against `brain.min.js`.

**Tech stack:** Node ≥14, terser (build only). Validation commands: `npm test` (4 source suites), `npm run parity`
(resolver+veto vs `brain.min.js`), `node harness-solo-<name>.js` (one suite), `bash build-brain.sh` (rebuild).

---

## Triage — what survived verification

| # | Review claim | Verdict | Why (verified against source) |
|---|---|---|---|
| A1 | `vetoQuorum \|\| 1` coerces `0`→`1` (brain.js) | **VALID, fix** | Confirmed line 62. `0` is meaningful (all-contested). Trivial `!= null`. |
| A2 | Tally double-counts duplicate `by` ids (brain.js) | **VALID, fix** | `eligible` can hold two `{by:'x'}` (seed + member); `tally['x'] += s` runs twice. Real footgun for the documented `seed` feature. |
| A3 | `open` regex misses a question before a `*action*` (nation.js) | **VALID bug, fix is wrong** | `/\?\s*$/` confirmed. But the reviewer's `/\?[^\w]*$/` and "last quarter" both FAIL the reviewer's own example (`*smiles warmly*` has word chars after `?`). Corrected fix below. |
| A4 | `play` regex flags `**bold**` as an action (nation.js) | **VALID bug, fix has compat risk** | `/\*[^*]+\*/` matches the inner `*…*` of `**bold**`. Reviewer's lookbehind fix risks old-browser breakage; use strip-bold-first. |
| A5 | Stalled member times out **3×** per round (brain.js) | **VALID issue, magnitude wrong** | Vote+veto run in **parallel** (`Promise.all(votePs.concat(vetoPs))`), so it's **2× not 3×**. Blacklisting after propose cuts it to ~1×. Only affects the async-member council path (`/council`,`/society`); the everyday nation path is synchronous and never hits this. |
| A6 | 7 identical per-mind `user` objects (nation.js) | **VALID redundancy, careful refactor** | `perceive`'s nudge is mind-independent → all 7 `user.sentiment` evolve identically; `societySentiment` averages identical numbers. Hoist to one shared object — but the update must run **once**, not 7×, or the EWMA math changes. |
| A7 | Peers don't record what was just said (nation.js) | **REAL asymmetry, impact overstated** | Confirmed peers get `react()` but not a `working` push. But `intend`/`veto` only read the last turn / last *user* turn (both present regardless), so **no current decision changes**. Worth fixing for consistency/future-proofing, not the "massive bug" billed. |
| B1 | `clear`/`calm` cliff at 600 chars (nation.js) | **REAL discontinuity, but TUNING** | Confirmed `len>600?0.3` / `len>600?0.2`. Smoothing changes the length-scoring curve (a behavioral choice). Recommend a curve; needs your sign-off. Candidate-path only. |
| B2 | `'shared'` drive forces "adversarial/commanding" (nation.js) | **DESIGN CALL, diagnosis wrong** | `'shared'` produces `press`/`drive` (initiative), **not** `oppose`/`command` — those require `adversary`/`commands`. It is not adversarial. Whether `'shared'` should let her co-lead is a design decision, not a bug. |
| — | `withTimeout` timer leak (prior review) | **REJECTED** | Already cleared in both resolve handlers; no change. (Listed for completeness.) |

---

## Part A — Patches to implement (TDD, full code)

### Task 1: Respect an explicit `vetoQuorum: 0` (A1)

**Files:** Modify `brain.js` (`resolve`, line ~62); Test `harness-solo-council.js`.

- [ ] **Step 1 — failing test** (add near the other `resolve` cases in `harness-solo-council.js`):
```js
// vetoQuorum 0 is a real value (every proposal blocked -> contested), not a falsy to coerce back to 1
var dq = C.resolve(
  [{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .5 }],
  [{ voter: 'c', scores: { a: .9, b: .1 } }],
  [{ by: 'c', against: 'a', reason: 'x' }], { vetoQuorum: 0 });
ok(dq.status === 'contested', 'vetoQuorum:0 is honored (not coerced to 1): with a 0 threshold every proposal is blocked -> contested');
```
- [ ] **Step 2 — run, expect FAIL:** `node harness-solo-council.js` → the new line FAILs (status is `carried`, because `0` was coerced to `1` and only `a` got blocked).
- [ ] **Step 3 — implement** in `brain.js`, change the quorum default:
```js
var allowSelf = !!opts.allowSelfVote, vetoQuorum = (opts.vetoQuorum != null) ? opts.vetoQuorum : 1;
```
- [ ] **Step 4 — run, expect PASS:** `node harness-solo-council.js` → `ALL GREEN`.
- [ ] **Step 5 — validate (brain.js changed):** `bash build-brain.sh` then `npm run parity` → both `ALL GREEN`.

---

### Task 2: De-duplicate proposers in `resolve` (A2)

**Files:** Modify `brain.js` (`resolve`, right after the existing proposals filter, line ~60); Test `harness-solo-council.js`.

- [ ] **Step 1 — failing test:**
```js
// a seed and a member can share an id; the cross-vote must count that voice ONCE, not twice
var dd = C.resolve(
  [{ by: 'x', text: 'X1', conf: .5 }, { by: 'x', text: 'X2', conf: .9 }, { by: 'y', text: 'Y', conf: .5 }],
  [{ voter: 'y', scores: { x: .4, y: .1 } }], [], {});
ok(dd.tally.x === 0.4, 'a duplicate proposer id is collapsed: tally counts the voter once (0.4), not doubled (0.8)');
ok(dd.winnerId === 'x' && dd.text === 'X1', 'the first proposal for that id is kept');
```
- [ ] **Step 2 — run, expect FAIL:** `tally.x` is `0.8` (double-counted).
- [ ] **Step 3 — implement** in `brain.js`, immediately after `proposals = (proposals || []).filter(function (p) { return p && p.by != null; });`:
```js
// a proposer appears at most once. If a seed and a member (or two seeds) share an id, keep the first —
// otherwise the cross-vote tallies that voice twice and silently doubles its weight.
var seenBy = {}; proposals = proposals.filter(function (p) { if (seenBy[p.by]) return false; seenBy[p.by] = true; return true; });
```
- [ ] **Step 4 — run, expect PASS.**
- [ ] **Step 5 — validate:** `bash build-brain.sh` + `npm run parity` → `ALL GREEN`.

---

### Task 3: `open` recognizes a question before a trailing action/emoji (A3)

**Files:** Modify `nation.js` (`gauge`, `open:` line ~ in the `f` object); Test `harness-solo-nation.js`.

> The reviewer's `/\?[^\w]*$/` fails the very example given (`*smiles warmly*` contains word chars after the `?`).
> Correct approach: drop `*action*` spans first, then accept a `?` followed only by non-word decoration.

- [ ] **Step 1 — failing test** (`gauge(text, {open:1})` isolates the `open` trait):
```js
ok(N.gauge('How are you feeling? *smiles warmly*', { open: 1 }) === 1, 'a question before a *roleplay action* still reads as open (the real bug)');
ok(N.gauge('How are you feeling?', { open: 1 }) === 1, 'a plain trailing question still reads as open');
ok(N.gauge('Are you ok? 🙂', { open: 1 }) === 1, 'a trailing emoji does not hide the question');
ok(N.gauge('I am here with you. *holds your hand*', { open: 1 }) === 0, 'a statement plus an action is not open');
```
- [ ] **Step 2 — run, expect FAIL:** the action/emoji cases return `0`.
- [ ] **Step 3 — implement** in `nation.js`, replace the `open:` line inside `gauge`'s `f`:
```js
      open:  (function () { var s = String(t).replace(/\*[^*]+\*/g, ' '); return /\?[^\w]*$/.test(s) ? 1 : 0; })(),
```
- [ ] **Step 4 — run, expect PASS:** `node harness-solo-nation.js` → `ALL GREEN`.
- [ ] **Step 5 — validate:** `npm test` → all four suites `ALL GREEN`. (nation.js isn't compiled; no parity rebuild needed.)

---

### Task 4: `play` ignores `**bold**` markdown (A4)

**Files:** Modify `nation.js` (`gauge`, `play:` line); Test `harness-solo-nation.js`.

> The reviewer's lookbehind regex can throw on older browsers (Perchance targets a wide range). Strip `**bold**`
> spans first, then look for a single-asterisk action — no lookarounds.

- [ ] **Step 1 — failing test:**
```js
ok(N.gauge('*smiles softly*', { play: 1 }) === 1, 'a *roleplay action* reads as play');
ok(N.gauge('**This is very serious**', { play: 1 }) === 0, '**bold** markdown is NOT misread as a playful action');
ok(N.gauge('**emphasis** and then *winks*', { play: 1 }) === 1, 'a real action still counts even alongside bold');
```
- [ ] **Step 2 — run, expect FAIL:** the `**bold**` case returns `1`.
- [ ] **Step 3 — implement** in `nation.js`, replace the `play:` line inside `gauge`'s `f`:
```js
      play:  (function () { var s = String(t).replace(/\*\*[^*]+\*\*/g, ' '); return /\*[^*]+\*/.test(s) ? 1 : 0; })(),
```
- [ ] **Step 4 — run, expect PASS.**
- [ ] **Step 5 — validate:** `npm test` → `ALL GREEN`.

---

### Task 5: Blacklist a stalled member for the rest of the round (A5)

**Files:** Modify `brain.js` (`reach` + `deliberate` in `createCouncil`); Test `harness-solo-council.js`.

> Corrects the magnitude: it's 2× (propose, then vote∥veto), not 3×. Marking a member dead after a propose
> timeout makes vote/veto return their fallbacks immediately, cutting a stalled round to ~1× timeout. Mandatory
> participation is preserved (the dead member still contributes a default vote). `deadSet` is optional, so any
> caller not passing it behaves exactly as before.

- [ ] **Step 1 — failing test** (async; add to the council harness's promise chain):
```js
// a member whose propose never resolves must NOT be re-asked to vote/veto (no repeated timeout waits)
var calls = { propose: 0, vote: 0, veto: 0 };
var ghost = C.member('ghost', 'x', {
  propose: function () { calls.propose++; return new Promise(function () {}); },   // never resolves -> times out
  vote: function () { calls.vote++; return 0.5; }, veto: function () { calls.veto++; return { veto: false }; } });
var liveA = C.member('liveA', 'y', { propose: function () { return { text: 'hi', conf: .5 }; }, vote: function () { return .5; }, veto: function () { return { veto: false }; } });
var liveB = C.member('liveB', 'z', { propose: function () { return null; }, vote: function () { return .5; }, veto: function () { return { veto: false }; } });
return C.createCouncil({ members: [ghost, liveA, liveB], timeoutMs: 10 }).deliberate({}).then(function (dg) {
  ok(dg.participation.indexOf('ghost') >= 0, 'a stalled member still participates with a default vote (mandatory participation preserved)');
  ok(calls.vote === 0 && calls.veto === 0, 'after a propose timeout the stalled member is not re-asked to vote/veto (round no longer pays the timeout twice)');
});
```
- [ ] **Step 2 — run, expect FAIL:** `calls.vote`/`calls.veto` are `> 0` today.
- [ ] **Step 3 — implement** in `brain.js`. Give `reach` an optional `deadSet`:
```js
    function reach(m, type, proposal, ctx, fallback, deadSet) {         // bus or direct; always times out cleanly
      if (deadSet && deadSet[m.id]) return Promise.resolve(fallback);   // stalled earlier this round — don't wait again
      var call = nervous ? Promise.resolve(nervous.ask(m.id, { type: type, proposal: proposal, ctx: ctx }))
                         : Promise.resolve(type === 'propose' ? m.propose(ctx) : type === 'vote' ? m.vote(proposal, ctx) : m.veto(proposal, ctx));
      return withTimeout(call, timeoutMs, fallback, sched).then(function (res) {
        if (res.__timeout) { if (nervous) nervous.sleep(m.id); if (deadSet) deadSet[m.id] = true; }   // mark dead for the round
        else lastSeen[m.id] = now();
        return res.value;
      });
    }
```
Then in `deliberate`, create `var dead = {};` after `wakeStalled();` and thread it through all three phases:
```js
    function deliberate(ctx, seed) {
      wakeStalled();
      var dead = {};
      return Promise.all(members.map(function (m) {
        return reach(m, 'propose', null, ctx, null, dead).then(function (r) { return { by: m.id, r: r }; });
      })).then(function (props) {
        var proposals = (seed || []).slice().concat(props.map(function (x) { var r = x.r; return (r && r.text != null) ? { by: x.by, text: String(r.text), conf: Number(r.conf) || 0 } : null; }).filter(Boolean));
        if (!proposals.length) return { status: 'no-proposals', text: null, winnerId: null, transcript: { proposals: [], ballots: [], vetoes: [] }, participation: members.map(function (m) { return m.id; }) };
        var ballots = [], vetoes = [];
        var votePs = members.map(function (m) {
          var scores = {};
          return Promise.all(proposals.map(function (p) {
            return reach(m, 'vote', p, ctx, DEFAULT_SCORE, dead).then(function (s) { scores[p.by] = (typeof s === 'number' && isFinite(s)) ? s : DEFAULT_SCORE; });
          })).then(function () { ballots.push({ voter: m.id, scores: scores }); });
        });
        var vetoPs = members.map(function (m) {
          return Promise.all(proposals.map(function (p) {
            return reach(m, 'veto', p, ctx, { veto: false }, dead).then(function (vr) { if (vr && vr.veto) vetoes.push({ by: m.id, against: p.by, reason: vr.reason || '' }); });
          }));
        });
        return Promise.all(votePs.concat(vetoPs)).then(function () {
          var decision = resolve(proposals, ballots, vetoes, opts);
          decision.transcript = { proposals: proposals, ballots: ballots, vetoes: vetoes };
          decision.participation = ballots.map(function (b) { return b.voter; });
          return decision;
        });
      });
    }
```
- [ ] **Step 4 — run, expect PASS.**
- [ ] **Step 5 — validate:** `bash build-brain.sh` + `npm run parity` → `ALL GREEN`.

---

### Task 6: One Society-level user model instead of seven identical copies (A6)

**Files:** Modify `nation.js` (`createMind`, the army-level `perceive`, `societySentiment`, `setUserDescription`, and where minds are constructed); Test `harness-solo-nation.js`.

> No behavioral change is intended. The key risk is the EWMA update: today each of the 7 minds applies *one*
> update to its *own* user, so all land on the same value. After hoisting, the shared user must be updated
> **exactly once per turn** — do NOT leave the update inside `mind.perceive` (that would apply it 7× and change the
> math). Per-mind `bonds` stay per-mind; only `user` is shared.

- [ ] **Step 1 — failing/guard test** (pins the post-refactor contract):
```js
var hv = N.createArmy({ config: {} });
for (var hi = 0; hi < 4; hi++) hv.perceive({ who: 'You', role: 'user', text: 'i feel awful', valence: -0.8 });
var s1 = hv.mindOf('heart').user, s2 = hv.mindOf('reason').user;
ok(s1 === s2, 'all faculties share ONE user model (same object reference), not seven copies');
ok(s1.sentiment < 0, 'the shared user sentiment moved with the negative turns');
ok(hv.mindOf('heart').bonds !== hv.mindOf('reason').bonds, 'bonds stay per-mind (only the user model is shared)');
```
- [ ] **Step 2 — run, expect FAIL:** `s1 === s2` is false today (separate objects).
- [ ] **Step 3 — implement** in `nation.js`:
  1. In `createArmy`, before minds are built, add the shared model:
```js
    var societyUser = { description: '', sentiment: 0, engagement: 0, lastSaid: null };
```
  2. Build minds with it (find the `roster.map`/`createMind(` construction and pass it):
```js
    var minds = roster.map(function (n) { return createMind(n, societyUser); });
```
  3. Change `createMind`'s signature and drop its private `user`, using the passed one:
```js
  function createMind(nation, user) {                 // `user` is the Society-shared model (single source of truth)
    var temper = TEMPER[nation.id] || {};
    var self = { id: nation.id, purpose: nation.purpose, persona: null, mood: 0.5, lastSaid: null };
    var working = [];
    var bonds = {};
    // (no local `var user = …` — it now comes in shared)
```
  4. In `mind.perceive`, REMOVE the user-update block, keeping only memory + cues:
```js
    function perceive(turn) {
      remember(turn);
      return read(turn.text);   // the shared user model is updated once at the Society level (see army.perceive)
    }
```
  5. In `createArmy`'s `perceive`, update the shared model **once** per turn (replicating the exact old EWMA):
```js
    function perceive(turn) {
      if (!turn || turn.text == null) return null;
      var reactions = [];
      minds.forEach(function (m) { m.perceive(turn); reactions.push(m.react(turn)); });
      if (turn.role === 'user') {
        var cues = read(turn.text);
        var nudge = (turn.valence != null) ? (clamp11(turn.valence) * 0.3) : ((cues.warmth + cues.humor - cues.distress - cues.anger) * 0.15);
        societyUser.sentiment = clamp11(societyUser.sentiment * 0.7 + nudge);
        societyUser.engagement = clamp01(societyUser.engagement * 0.8 + Math.min(1, cues.len / 120) * 0.2);
        societyUser.lastSaid = turn.text;
      }
      state.turns++;
      return { cues: read(turn.text), sentiment: societySentiment(), reactions: reactions };
    }
```
  6. Simplify `societySentiment` (no more averaging identical numbers) and point `setUserDescription` at the shared model:
```js
    function societySentiment() { return r2(societyUser.sentiment); }
```
```js
    function setUserDescription(d) { societyUser.description = String(d || ''); }   // (match the existing body)
```
- [ ] **Step 4 — run, expect PASS:** `node harness-solo-nation.js` → `ALL GREEN` (the existing sentiment/veto tests must still pass — that's the regression guard).
- [ ] **Step 5 — validate:** `npm test` → all `ALL GREEN`. nation.js isn't compiled; no parity step.

> If any existing assertion that reads `mind.user.sentiment` breaks, that's the signal a reference wasn't
> repointed — search `nation.js` for `.user.` and confirm each now resolves to the shared `societyUser`.

---

### Task 7: Every faculty remembers what was just said (A7)

**Files:** Modify `nation.js` (`reactToSpoken`); Test `harness-solo-nation.js`.

> Low impact today (no decision reads beyond the last/last-user turn), but it removes a real asymmetry and
> future-proofs anything that walks `working`. The speaker already records via `said()`; give the non-speakers the
> same record (as `role:'other'`), respecting the 8-item cap.

- [ ] **Step 1 — failing test:**
```js
var rm = N.createArmy({ config: {} });
rm.perceive({ who: 'You', role: 'user', text: 'i had a rough day' });
rm.reactToSpoken('heart', 'I hear you. That sounds really hard.');
var peer = rm.mindOf('reason').working.some(function (w) { return w.role === 'other' && /hear you/.test(w.text); });
ok(peer, 'a non-speaking faculty now remembers what was just said (no longer blind to her own reply)');
var spkCount = rm.mindOf('heart').working.filter(function (w) { return /hear you/.test(w.text); }).length;
ok(spkCount === 1, 'the speaker records it exactly once (no double-entry from the new peer path)');
```
- [ ] **Step 2 — run, expect FAIL:** the `reason` peer has no record of the spoken line.
- [ ] **Step 3 — implement** in `nation.js`, replace the body of `reactToSpoken`'s minds loop:
```js
    function reactToSpoken(speakerId, text) {
      var sp = mindOf(speakerId); if (sp) sp.said(text);
      var t = String(text || '').slice(0, 400);
      minds.forEach(function (m) {
        var role = m.self.id === speakerId ? 'self' : 'other';
        if (role === 'other') { m.working.push({ who: speakerId, role: 'other', text: t }); if (m.working.length > 8) m.working.shift(); }
        m.react({ who: speakerId, role: role, text: text });
      });
    }
```
(Keep any other lines `reactToSpoken` already had, e.g. an `ingestReaction`/bond step, untouched — only the loop changes.)
- [ ] **Step 4 — run, expect PASS.**
- [ ] **Step 5 — validate:** `npm test` → `ALL GREEN`.

---

## Part B — Decisions for you (not auto-patched)

These are real observations, but the "fix" is a behavioral/semantic choice, not a correctness repair. Each needs a
call before any code lands.

### B1 — The `clear`/`calm` length cliff at 600 chars

Confirmed: `clear: len>600?0.3` and `calm: len>600?0.2` step instantly at 600. A 600-char reply scores `clear=1.0`;
a 601-char reply scores `0.3`. It only affects the **candidate-text** path (`/council`, the emotion society,
`nation.deliberate`) — the everyday intent path doesn't call `gauge`.

The reviewer's replacement (`max(0.2, 1-(len-400)/400)`) doesn't just remove the cliff — it **re-shapes** how length
is valued (it starts penalising at 400 and is already flat-1.0 from 240–600 today). That's a tuning decision about
what "a good length" means.

**Recommendation if you want it smoothed** (preserves today's curve up to ~400, then decays gently instead of a
cliff):
```js
      clear: len < 8 ? 0 : Math.max(0.3, Math.min(1, 0.4 + Math.min(len, 240) / 240 * 0.6) - Math.max(0, len - 400) / 1000),
      calm:  len < 8 ? 0.3 : Math.max(0.2, 1 - Math.max(0, len - 400) / 1000),
```
**Decision needed:** keep the cliff (simple, and replies rarely sit near 600), or adopt a smooth decay (and if so,
where should the knee be — 400? 600?). If you say go, it becomes a Task with the same TDD shape: a test asserting
continuity across 599→601 and monotonic non-increase past the knee.

### B2 — Does a `'shared'` drive let her co-lead, or stay supportive?

The diagnosis in the review is **factually wrong**: `'shared'` does not produce an "adversarial, commanding posture."
`intentFor` only yields `oppose`/`command` under `alignment:'adversary'` / `stature:'commands'`. With
`drive:'shared'`, `ally`, `equal` you get `voice:'press'`, `reason:'drive'`, `play:'play'` — i.e. she *takes
initiative / co-leads*, not hostility.

So the real question is design intent: when the user sets a **shared** drive, should she be allowed to push the
scene forward (current behavior), or should "shared" stay in the supportive register (`express`/`ground`/`comfort`)
and reserve initiative for `drive:'she'`?

**Decision needed.** If you want `'shared'` to be supportive-only, the one-line change is removing it from the
trigger — `function isDrivingFrame(f){ return !!f && (f.drive === 'she' || f.alignment === 'adversary' || f.stature
=== 'commands'); }` — and `harness-solo-nation-extra.js` gets a case asserting `'shared'+ally+equal` yields
`voice:'express'`. I'd lean toward **keeping** it (shared = mutual driving reads naturally as "she may lead too"),
but it's your character call.

---

## Part C — Corrected or rejected, for the record

- **"3× timeout cascade" → it's 2×.** Vote and veto are one parallel `Promise.all`. Task 5 still helps (cuts it to
  ~1×), but anyone reasoning about latency should use the right number, and remember the everyday nation path is
  synchronous and never pays this at all.
- **"`'shared'` is adversarial" → no.** See B2; it's `press`/`drive`, not `oppose`/`command`.
- **"Peers are blind, a massive bug" → real but inert.** Task 7 fixes the asymmetry, but no current decision depends
  on it; don't expect behavior to change, only consistency.
- **`withTimeout` "memory leak" (earlier review) → already handled.** No action.

---

## Validation protocol (applies to every task)

1. One test per fix, asserting the *behavior*, added to the matching harness (`council` for `resolve`/`createCouncil`;
   `nation` for `gauge`/minds/`reactToSpoken`; `nation-extra` for frame intents).
2. After **any `brain.js`** edit: `bash build-brain.sh`, then `npm run parity`. A green `brain.js` with a stale
   `brain.min.js` is how a silent regression ships.
3. End state: `npm test` (4 suites) and `npm run parity` (2 suites) all `ALL GREEN`.

## Suggested order

Tier 1 (clear, cheap, high-confidence): **Task 1 → 2 → 3 → 4.** (1+2 are `brain.js`; batch their rebuild/parity.)
Tier 2 (real, more surface): **Task 5 → 7 → 6.** (6 last: highest churn, zero intended behavior change — do it when
the suite is otherwise green so any drift is obvious.)
Tier 3 (your call, no code yet): **B1, B2.**

## Self-review

- **Coverage:** all 9 review items mapped — 7 to tasks, 2 to decisions (B1/B2), plus the rejected `withTimeout`
  claim noted in C.
- **Placeholders:** none — every code step shows the actual patch and the actual test.
- **Consistency:** `gauge(text, {trait:1})` is used uniformly to isolate a trait; `deadSet` threads identically
  through all three `reach` calls in Task 5; `societyUser` is the single name used across Task 6's steps.
- **Risk flagged:** Task 6 is the one with refactor risk (the "update once, not 7×" trap) and is sequenced last with
  an explicit regression guard.
