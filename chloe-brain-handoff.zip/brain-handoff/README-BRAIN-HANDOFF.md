# The Brain — standalone handoff

You're holding the **Brain** of *Chloe Solo*, extracted so it can be developed on its own. It is pure reasoning:
no DOM, no network, no app. Everything here runs under plain Node and is deterministic. This document is written
for an AI picking the work up cold — it covers what the Brain is, the exact API, how to run and build it, how to
write a test harness in the house style, the invariants you must not break, and how your changes plug back into the
app they came from.

If you read nothing else: **edit `brain.js`**, run `npm test`, and after any change to `brain.js` rebuild
`brain.min.js` (`bash build-brain.sh`) and re-run the parity tests. The readable source and the compiled artifact
must always agree.

---

## 1. Project context (where this came from)

*Chloe Solo* is a single self-contained HTML app — an AI companion / roleplay character that runs on Perchance.org
with no server. Its architecture splits cleanly in two:

- **The mouth** (`engine.js`, not included here): memory, personality, image/reply routing, the model calls. It
  owns *what she remembers and how she sounds*.
- **The brain** (this package): the *reasoning* — given a moment, decide **who speaks and with what intent**. It
  owns *the decision*, in pure code, and never writes the actual words or touches memory.

When the brain is driving replies, the pipeline is: the **engine** supplies retrieved memory/context → the **brain**
picks the speaker and the intent → the **model** writes the words to that brief. So the brain is an arbiter, not a
text generator. That separation is the whole point: the brain stays pure, testable, and portable — which is why it
can live in this folder by itself.

---

## 2. The three layers (and what's in this folder)

```
brain.js                     ← THE CORE. Pure "Society" deliberation + a nervous-system bus. Edit this.
brain.min.js                 ← compiled artifact the app ships (terser). Keep in sync with brain.js.
build-brain.sh               ← brain.js → brain.min.js
nation.js                    ← the Seven Nations: the readable layer ABOVE the brain. Its primary consumer.
package.json                 ← `npm test` (all suites) · `npm run parity` (vs brain.min.js) · `npm run build`
harness-solo-council.js      ← pure resolve() + a live deliberate() round over the nervous bus
harness-solo-veto.js         ← the nation veto channel (conscience/instinct can block; she never goes silent)
harness-solo-nation.js       ← the Seven Nations end-to-end (gauge, weighted deliberation, self-knowledge)
harness-solo-nation-extra.js ← role-frame intents + affect→sentiment (two suites, combined for packaging)
```

> **`brain-block.js` is not in this package.** It's the layer that wires the brain into the app's engine
> (the action handlers), it needs `engine.js` to run, and it can't execute standalone — so it would only be
> dead weight here. Its role and the exact integration contract are described in §2 (layers) and §10 (plug-back).
> If you need to see it, it lives in the parent app.

The dependency arrows point **down**, and the coupling is by injection, never by `require`:

```
[ app engine ]  ── brain-block.js bridges the brain into the engine's action loop (not in this package)
      │
      ▼
  nation.js   ── createArmy({ brain: ChloeBrain, ... })   // brain is injected, not required
      │  uses ChloeBrain.resolve
      ▼
  brain.js    (zero dependencies — UMD, self-contained)
```

`brain.js` depends on **nothing**. `nation.js` depends on the brain **only** through `createArmy({ brain })` — so
you can test, swap, or fake the brain freely.

---

## 3. Quick start

```bash
node --version          # needs Node >= 14 (anything modern is fine)
npm test                # all four suites against the readable source. Expect "ALL GREEN" from each.
npm run parity          # re-run resolver + veto against the COMPILED brain.min.js (must match)
node harness-solo-council.js                        # one suite directly
BRAIN=./brain.min.js node harness-solo-council.js   # the same suite against the compiled artifact

# after editing brain.js:
npm install             # once, to get terser (needs network)
npm run build           # brain.js -> brain.min.js  (alias for bash build-brain.sh)
npm test && npm run parity   # confirm source AND compiled still pass
```

No build step is needed just to *run* — the harnesses load `brain.js` directly. The build only produces the
shipping artifact.

---

## 4. `brain.js` — the core API

A UMD module. In Node it's `require('./brain.js')`; in a browser it installs `window.ChloeBrain` (alias
`ChloeCouncil`). It exposes five things:

```js
{ createNervous, resolve, member, createCouncil, withTimeout }
```

### 4.1 `resolve(proposals, ballots, vetoes, opts)` — the pure heart

This is the whole decision, deterministic, no side effects. Everything else is scaffolding around it.

**Inputs**

| arg | shape | meaning |
|---|---|---|
| `proposals` | `[{ by, text, conf }]` | one nomination per member (abstain = omit). `by` = member id, `conf` ∈ ~[0,1] |
| `ballots` | `[{ voter, scores: { <by>: num } }]` | each member scores the proposals (~[0,1] each) |
| `vetoes` | `[{ by, against, reason }]` | a member blocks a proposal (`against` = the proposer's id) |
| `opts` | `{ allowSelfVote=false, vetoQuorum=1, consensusMargin=0 }` | tuning |

**Algorithm** (read the source — it's ~60 lines and worth knowing exactly):
1. Count vetoes per target; a proposal is vetoed if its count ≥ `vetoQuorum`.
2. Eligible = non-vetoed proposals. **If every proposal is vetoed, the field is un-vetoed and the round is marked
   `contested`** — the Society never crashes or goes silent.
3. Tally each ballot's scores onto proposals (a voter does **not** score its own proposal unless `allowSelfVote`).
   Record each voter's top pick.
4. Rank by **tally → confidence → nomination order** (stable). Winner is first; margin = winner − runner-up.
5. Agreement = every judging voter's top pick is the winner.

**Returns**

```js
{
  winnerId, text,         // the chosen proposal (null if none)
  status,                 // 'no-proposals' | 'contested' | 'agreed' | 'tie-resolved' | 'carried'
  tally,                  // { by: totalScore }
  margin, consensus,      // number; boolean (unanimous among judges)
  dissent,                // [voterId] who preferred someone else
  vetoed, vetoReasons     // [by]; { by: [{ by, reason }] }
}
```

### 4.2 `createCouncil(deps)` — the Society (async orchestration)

Wraps `resolve` with the *protocol*: members register, get asked to propose/vote/veto, and a stalled member is
**timed out to a default vote, never an abstention**.

```js
createCouncil({
  members,        // [ member(...) ]  — keep the count ODD so votes can't split
  nervous,        // optional ChloeBrain.createNervous() bus (proves the message protocol)
  opts,           // passed straight to resolve (+ defaultScore)
  timeoutMs,      // per-member reply timeout (0 = no timeout)
  idleMs,         // a member idle longer than this is reawakened by the watchdog
  sched,          // { set(fn,ms)->t, clear(t) }  — inject for deterministic tests
  now,            // () => ms                      — inject for deterministic tests
  log
})
// → { deliberate(ctx, seed), resolve, members, nervous, wakeStalled, size }
```

`deliberate(ctx, seed)` runs **one round**: `wakeStalled()` → every member **nominates** (best-effort) → every
member **cross-votes on all proposals (mandatory; timeout → `defaultScore`)** → every member may **veto** →
`resolve`. `seed` optionally injects candidate proposals the whole body votes on (the "a few propose, the many
decide" shape). The result carries a `transcript` (proposals/ballots/vetoes) and `participation` (proof every
member voted).

### 4.3 `member(id, role, fx)`

A member-Brain. `fx` injects behaviour; all default to pure no-ops:

```js
member('heart', 'comfort', {
  propose: ctx => ({ text, conf }) | null,    // a nomination, or null to abstain
  vote:    (p, ctx) => number,                // score a proposal (default: p.conf)
  veto:    (p, ctx) => ({ veto, reason })     // block it? (default: { veto:false })
})
```

### 4.4 `withTimeout(p, ms, fallback, sched)`

Races a promise against an injected clock so a stalled mind can't freeze a round. Returns
`{ __timeout, value }`. Pure-testable because `sched` is injected.

### 4.5 `createNervous(log)`

A registry + pub/sub bus + lifecycle (`register/list/find/setState/wake/sleep/standby/send/ask/publish/subscribe/
health`). Optional — `createCouncil` works without it, but when present the members talk over the bus, which is
what `health()` reports on. Useful if you want to model degraded/asleep members.

---

## 5. `nation.js` — the Seven Nations (the layer the app actually calls)

This is the human-readable layer *above* the brain. Seven faculties — **heart, reason, memory, instinct, voice,
conscience, play** — each with a plain-English purpose and a "lean" (what it values in a reply). Seven is odd on
purpose. It uses `ChloeBrain.resolve` underneath.

```js
var N = require('./nation.js');               // { NATIONS, createArmy, gauge }
var army = N.createArmy({
  brain: require('./brain.js'),               // injected ChloeBrain
  config: { weights:{}, enabled:{}, timeoutMs:8000, useForReplies:false, noise:0 },
  rng: Math.random                            // inject a seeded rng in tests for determinism
});
```

The army has **two deliberation paths** — know which one you're touching:

- **`deliberate(candidates, ctx)`** — the *candidate-text* path. You hand it actual reply texts
  `[{ by, text }]`; each nation scores them via `gauge(text, lean)` × weight, and the brain resolves a winner.
  Used by the app's `/council` and emotion-society demos.
- **`deliberateIntents(ctx)`** — the *intent* path (the everyday one). Each live nation proposes an **intent
  kind** with a strength (`intend`), the others cross-vote (`voteIntent`), the brain resolves, and you get a
  winning **speaker + intent** plus a `floor` readout. One model call then voices that intent. This is what
  `runNation` uses when the council drives replies.

Supporting pieces you'll meet:
- **`perceive(turn)`** → reads `cues` (warmth/distress/humor/anger) from text and updates each nation's running
  **sentiment** toward the speaker.
- **`intend(ctx)`** → a nation's intent. Its `kind` comes from `intentFor(id, ctx.frame)` — base intents
  (`heart:comfort, reason:ground, memory:recall, instinct:caution, voice:express, conscience:protect, play:play`),
  which turn **forceful** (`press/oppose/command/drive/provoke`) under a "driving" role frame.
- **`voteIntent(it, ctx)`** → score another nation's intent through this one's nature and its bond.
- **`VETO`** → `conscience` and `instinct` can veto `play`/`express` when sentiment is low or distress/anger is
  present. (Forceful intents are deliberately *not* `play`/`express`, so a driving frame relaxes the veto for free.)
- **`gauge(text, lean)`** → the pure text-scorer: rates a string on `warm/clear/open/play/calm`.

`config`: `weights` ({id:n}, default 1) scales a nation's vote; `enabled` ({id:false}) drops one; `noise`
(default 0 = deterministic) adds bounded jitter; `useForReplies` is the app's toggle for whether the council
drives replies at all (it does **not** affect the math here).

---

## 6. Invariants — do not break these

1. **Pure & deterministic.** No DOM, no network, no `Date.now()`/`Math.random()` reached for directly in logic
   paths — they're **injected** (`now`, `rng`, `sched`) so tests are reproducible. Keep it that way; it's the
   reason the Brain is testable at all.
2. **Odd membership.** Seven nations so a vote can't tie. `createCouncil` warns on even membership. If you add or
   remove faculties, keep the count odd.
3. **Voting is mandatory, abstention is not a vote.** A member that stalls is timed out to `defaultScore` — it
   never silently drops out. Proposals (text) *can* be abstained (return `null`); votes cannot.
4. **The body never goes silent.** If every proposal is vetoed, the round is `contested` and proceeds. Preserve
   this — "she falls silent" is a failure mode, not an outcome.
5. **The minify contract.** `brain.min.js` is terser with `mangle toplevel` but **property names preserved** —
   the app and `nation.js` call `resolve`, `deliberate`, `winnerId`, `tally`, etc. by name. **Never rename a
   public property or returned field.** If you do, the app breaks *and* parity breaks. Internals (local vars,
   helper function names) are free to change.
6. **Source and artifact agree.** After any `brain.js` edit: rebuild, then run the harnesses against **both**
   `brain.js` (`npm test`) and `brain.min.js` (`npm run parity`). They must give identical results.

---

## 7. Writing a test harness (the house style)

The harnesses are plain Node scripts — **no framework**, no dependencies. The pattern is deliberately tiny so it
runs anywhere and reads top-to-bottom. Copy this shape:

```js
/* what this proves, in one sentence */
'use strict';
var C = require(process.env.BRAIN || './brain.js');   // ← parity hook: same file runs vs source AND brain.min.js
var fail = 0;
function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

// --- arrange: build proposals/ballots/vetoes (or a council with INJECTED now/rng/sched) ---
var d = C.resolve(
  [{ by:'a', text:'A', conf:0.5 }, { by:'b', text:'B', conf:0.4 }],
  [{ voter:'b', scores:{ a:0.9, b:0.1 } }, { voter:'c', scores:{ a:0.2, b:0.8 } }],
  []
);
// --- assert ---
ok(d.winnerId === 'a' || d.winnerId === 'b', 'a winner is chosen');
ok(typeof d.tally === 'object', 'a tally is returned');

console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — <one-line summary of what held>'));
process.exit(fail ? 1 : 0);
```

Rules that make a harness good here:

- **End with the sentinel.** `npm test` (and the parity run) greps for the exact string `ALL GREEN`. Print it only when `fail === 0`,
  and `process.exit(fail ? 1 : 0)`.
- **Make it parity-safe.** If the harness exercises the resolver, load it via `process.env.BRAIN || './brain.js'`
  so the runner can point it at `brain.min.js`. (Nation-only harnesses just `require('./nation.js')`.)
- **Inject all non-determinism.** For anything async or jittered, pass `now`, `rng`, and `sched`:
  ```js
  var T = 0; var now = function(){ return T; };
  var sched = { set:function(fn,ms){ return setTimeout(fn,0); }, clear:clearTimeout };   // or a fake clock
  var rng = (function(){ var s = 42; return function(){ s = (s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; }; })();
  ```
  A seeded `rng` + fixed `now` make council rounds and nation jitter reproducible.
- **Assert behaviour, not internals.** Check `winnerId`, `status`, `dissent`, `participation`, the `floor` —
  the contract — not private helpers.
- **One concern per harness, many small `ok`s.** Mirror the existing files: `council` (nominate/vote/veto/resolve
  + every member works), `veto` (blocking + the body still speaks), `nation` (perceive/intend/decide), and
  `nation-extra` (a driving frame turns the right nations forceful; sentiment flows from an
  injected valence). Reading those five is the fastest way to learn the conventions.

When you add a behaviour to `brain.js` or `nation.js`, add a harness that pins it, and make sure `npm test`
and `npm run parity` stay green against **both** the source and `brain.min.js`.

---

## 8. The build (`brain.js` → `brain.min.js`)

```bash
npm install            # gets terser (only needed once; needs network access)
bash build-brain.sh
```

`build-brain.sh` runs terser with `compress passes=3` + `mangle toplevel` but `comments=false` and **property
names preserved**, then `node --check`s the output and prints the size delta. The compiled file is what the app
ships; this folder keeps it only so you can prove equivalence. **Always rebuild + re-run parity after editing
`brain.js`** — a green `brain.js` with a stale `brain.min.js` is the easiest way to ship a silent regression.

If you don't have network access for `npm install`, you can still develop and test entirely against `brain.js`;
just hand the rebuild + parity step back to someone who can run terser, and don't ship a `brain.min.js` you
haven't regenerated.

---

## 9. Gotchas (things that have bitten before)

- **Don't rename public properties** (see invariant 5). The minifier preserves them by design; renaming desyncs
  the app and the parity tests at once.
- **`brain-block.js` is not in this package** — it bridges the brain into the app's engine, needs `engine.js`, and
  can't run standalone (see §2). Its role and the integration contract are in §2 and §10; the file lives in the app.
- **Keep membership odd**, and keep every member voting (timeout → default, never abstain).
- **Parity is not optional.** The two most recent regressions in this codebase were caught *only* by running a
  harness against `brain.min.js` after it had drifted from `brain.js`.
- **The harnesses were de-absolutised for this package** — their `require` paths are now relative (`./brain.js`,
  `./nation.js`). If you copy a harness from the parent app later, fix its paths the same way.

---

## 10. How your changes plug back into the app

When this work goes home, the integration points in the app (`solo.html`) are:

- The army is built once: `createArmy({ brain: window.ChloeBrain, config: state.nation, rng, ... })`.
- On a user turn, `runNation` does: `perceive(turn)` → `deliberateIntents(ctx)` → the brain resolves a **speaker +
  intent** → the app voices that intent with **one** model call, threading in the engine's retrieved context.
- `state.nation.useForReplies` (off by default) decides whether the council drives replies at all; `/nation`
  invokes it manually.

So the contract you must preserve for a clean drop-in: the **shape of `deliberateIntents`'s result** (`winnerId`,
`text` = the intent kind, `floor`, `dissent`) and the **shape of `resolve`'s result**. Add fields freely; don't
rename or remove existing ones.

---

## 11. What is deliberately NOT in this package

- **`engine.js`** — memory, personality, the model calls, context assembly. The brain never touches these.
- **The readers** (`stance/affect/topics/frame/measure`) — glue-side perception that *feeds* the brain (e.g. the
  role frame that flips nations forceful, the affect valence that feeds `perceive`). Here they appear only as the
  plain inputs the harnesses pass in (`ctx.frame`, `turn.valence`), so you can develop against the contract
  without them.
- **The app glue** (`solo.html`) — the queue, the UI, `runNation`. Section 10 is the summary of how it calls in.

The Brain is the part that thinks. Everything left behind is the part that remembers and the part that speaks. Keep
it pure, keep it odd, keep the two builds in agreement, and it stays as portable as it is right now in this folder.
