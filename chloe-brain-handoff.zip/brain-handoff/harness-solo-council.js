/* The council — three Brains that deliberate (DESIGN-council.md). node harness-solo-council.js
 * Covers the PURE resolve() (majority, veto, all-vetoed, tie-break, consensus, dissent, no self-voting) and a
 * live deliberate() round both directly and over the real nervous bus (proving members-as-neurons). */
'use strict';
var C = require(process.env.BRAIN || './brain.js');   // run against ./brain.js and ./brain.min.js (equivalence)
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }
function approx(a, b){ return Math.abs(a - b) < 1e-9; }

var P = [{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .9 }, { by: 'c', text: 'C', conf: .4 }];

// --- majority with dissent (no self-voting) ---
var d = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .3 } },
  { voter: 'b', scores: { a: .4, c: .5 } },
  { voter: 'c', scores: { a: .9, b: .8 } } ], [], {});
ok(d.winnerId === 'b', 'majority winner is b (1.7 vs 1.3 vs 0.8)');
ok(approx(d.tally.b, 1.7) && approx(d.tally.a, 1.3), 'tally sums cross-votes and excludes self-votes');
ok(d.status === 'carried' && d.dissent.join() === 'c', 'carried with the c-voter dissenting (preferred a)');

// --- unanimous among the judging members -> agreed ---
var d2 = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .1 } },
  { voter: 'b', scores: { a: .2, c: .3 } },
  { voter: 'c', scores: { a: .2, b: .9 } } ], [], {});
ok(d2.winnerId === 'b' && d2.status === 'agreed' && d2.consensus === true && d2.dissent.length === 0, 'unanimous among judges -> agreed, no dissent');

// --- veto removes a proposal from contention ---
var d3 = C.resolve(P, [
  { voter: 'a', scores: { b: .9, c: .2 } },
  { voter: 'b', scores: { a: .7, c: .1 } },
  { voter: 'c', scores: { a: .6, b: .8 } } ], [{ by: 'c', against: 'b', reason: 'off-character' }], {});
ok(d3.winnerId === 'a' && d3.vetoed.join() === 'b', 'b (the vote leader) is vetoed -> winner falls to a');
ok((d3.vetoReasons.b || [])[0].reason === 'off-character', 'veto reason is carried through');

// --- everything vetoed -> contested, but still resolves (never crashes) ---
var d4 = C.resolve(P, [{ voter: 'a', scores: { b: 1 } }], [
  { by: 'x', against: 'a' }, { by: 'x', against: 'b' }, { by: 'x', against: 'c' } ], {});
ok(d4.status === 'contested' && d4.winnerId != null, 'all-vetoed -> contested, still returns a least-bad winner');

// --- tie on tally -> broken by confidence ---
var d5 = C.resolve([{ by: 'a', text: 'A', conf: .5 }, { by: 'b', text: 'B', conf: .9 }],
  [{ voter: 'a', scores: { b: 1 } }, { voter: 'b', scores: { a: 1 } }], [], {});
ok(d5.winnerId === 'b' && d5.margin === 0, 'a tally tie (margin 0) is broken by higher confidence -> b');

ok(C.resolve([], [], []).status === 'no-proposals', 'no proposals -> no-proposals');

// --- a live deliberation round: members propose / vote / veto via injected effects ---
function mk(id, conf, votes, vetoAgainst) {
  return C.member(id, id + '-stance', {
    propose: function () { return { text: id.toUpperCase(), conf: conf }; },
    vote: function (p) { return votes[p.by] || 0; },
    veto: function (p) { return { veto: vetoAgainst === p.by, reason: vetoAgainst === p.by ? 'blocked' : '' }; }
  });
}
var members = [
  mk('a', .5, { b: .9, c: .2 }),
  mk('b', .6, { a: .3, c: .5 }),
  mk('c', .4, { a: .4, b: .8 }) ];

var direct = C.createCouncil({ members: members });
direct.deliberate({ topic: 'reply' }).then(function (dec) {
  ok(dec.winnerId === 'b' && dec.text === 'B', 'deliberate() (direct) elects b');
  ok(dec.transcript.proposals.length === 3 && dec.transcript.ballots.length === 3, 'transcript captures every proposal and ballot');

  // same round, but routed over the real nervous bus -> members are registered as kind:"brain" neurons
  var nv = C.createNervous(function (){});
  var council = C.createCouncil({ members: members, nervous: nv });
  var brains = nv.list().filter(function (n){ return n.kind === 'brain'; });
  ok(brains.length === 3, 'each member-Brain registered as a neuron on the council bus');
  ok(nv.describe('a').does.some(function (x){ return x.name === 'propose'; }), 'a member advertises propose/vote/veto');

  return council.deliberate({ topic: 'reply' });
}).then(function (dec) {
  ok(dec.winnerId === 'b', 'deliberate() over the nervous bus reaches the same verdict');

  // a veto member flips the outcome
  var withVeto = [members[0], members[1], mk('c', .4, { a: .4, b: .8 }, 'b')];
  return C.createCouncil({ members: withVeto }).deliberate({});
}).then(function (dec) {
  ok(dec.vetoed.join() === 'b' && dec.winnerId !== 'b', 'a member veto in deliberate() removes b from contention');

  // --- Society: mandatory participation under timeout + watchdog reawakening ---
  var nv2 = C.createNervous(function (){});
  var stall = C.member('stall', 'stalled', { propose: function (){ return null; }, vote: function (){ return new Promise(function (){}); }, veto: function (){ return { veto: false }; } });
  var good  = C.member('good',  'ok',      { propose: function (){ return null; }, vote: function (){ return 0.5; }, veto: function (){ return { veto: false }; } });
  var good2 = C.member('good2', 'ok',      { propose: function (){ return null; }, vote: function (){ return 0.7; }, veto: function (){ return { veto: false }; } });
  var soc = C.createCouncil({ members: [stall, good, good2], nervous: nv2, timeoutMs: 20 });   // odd society (3), real 20ms timeout
  return soc.deliberate({}, [{ by: 'cand', text: 'hi', conf: .5 }]).then(function (d6) {
    ok(d6.participation.length === 3, 'mandatory participation — all three voted, including the stalled one');
    var sb = d6.transcript.ballots.filter(function (b){ return b.voter === 'stall'; })[0];
    ok(sb && sb.scores.cand === 0, 'a timed-out vote becomes the default score, never an absence');
    ok(nv2.health('stall') === 'asleep', 'the stalled member was put to sleep on timeout');
    var woke = soc.wakeStalled();
    ok(woke.indexOf('stall') >= 0 && nv2.health('stall') === 'active', 'the watchdog reawakens it to register & work again');
    ok(d6.winnerId === 'cand' && soc.size === 3, 'seeded candidate wins on live votes; society size reported');
  });
}).then(function () {
  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — the council nominates, votes, vetoes, resolves, and keeps every member working'));
  process.exit(fail ? 1 : 0);
}).catch(function (e){ console.log('FAIL: threw ' + (e && e.stack || e)); process.exit(1); });
