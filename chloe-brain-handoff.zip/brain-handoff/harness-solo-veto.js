/* Nation veto channel. node harness-solo-veto.js   (also: BRAIN=./brain.min.js node harness-solo-veto.js)
 * The faculties that hold the PURPOSE can now BLOCK an intent, not just outvote it, through the same
 * resolve() the council already uses. Conscience won't let her be playful at someone who's hurting;
 * instinct won't let her poke at someone who's angry. The Society resolves the block; she never goes
 * silent even if everything were blocked; and a happy room blocks nothing so play is free to lead. */
'use strict';
var N = require('./nation.js');
var B = require(process.env.BRAIN || './brain.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

function run(brain, text){
  var army = N.createArmy({ brain: brain, config: { noise: 0 } });   // noise 0 -> deterministic
  army.perceive({ who: 'You', role: 'user', text: text });
  return army.deliberateIntents({ prompt: text });
}
var HURT = 'i feel so alone and exhausted, i can\u2019t do this anymore';
var MAD  = 'this is stupid and i\u2019m so angry, shut up';
var GLAD = 'haha that\u2019s so funny, i love this, best day ever!';
var FLAT = 'i went to the store and bought some bread';

(async function () {
  // 1) Distress: conscience blocks the frivolous moves; a caring intent takes the floor.
  var d = await run(B, HURT);
  ok(d.speaker, 'someone always takes the floor (never silent) under distress');
  ok(d.vetoed.indexOf('play') >= 0 && d.vetoed.indexOf('voice') >= 0, 'distress -> play and express(voice) are vetoed');
  ok(d.intent && /protect|comfort|ground|recall|caution/.test(d.intent.kind), 'the winner is a caring/steady intent, not a frivolous one');
  ok(d.intent && !/play|express/.test(d.intent.kind), 'a frivolous intent cannot win while someone is hurting');
  ok(d.vetoReasons.play && /hurting/.test(d.vetoReasons.play[0].reason), 'the veto carries a human-readable reason (for the Thoughts drawer)');

  // 2) Anger: instinct blocks poking; still never silent.
  var a = await run(B, MAD);
  ok(a.vetoed.indexOf('play') >= 0, 'anger -> instinct vetoes a playful intent');
  ok(a.speaker, 'still seats a speaker when angry');

  // 3) A happy room blocks nothing — play is free to lead.
  var g = await run(B, GLAD);
  ok(g.vetoed.length === 0, 'a glad message vetoes nothing');

  // 4) Neutral chatter: no veto either (guards fire only on a genuine signal, not by default).
  var f = await run(B, FLAT);
  ok(f.vetoed.length === 0, 'flat/neutral chatter triggers no veto (no over-blocking)');

  // 5) Guards are narrow: only ever play/express get blocked — never a caring/steady intent.
  [d, a, g, f].forEach(function (x) {
    ok(x.vetoed.every(function (v) { return v === 'play' || v === 'voice'; }), 'only frivolous faculties are ever vetoed (' + (x.vetoed.join(',') || 'none') + ')');
  });

  // 6) Determinism at noise 0: same input -> identical block + winner.
  var d2 = await run(B, HURT);
  ok(d2.winnerId === d.winnerId && d2.vetoed.join() === d.vetoed.join(), 'deterministic at noise 0 (same veto + winner)');

  // 7) Fallback parity: with NO brain bundle, localResolve must honor vetoes the same way.
  var dn = await run(null, HURT);
  ok(dn.speaker && dn.vetoed.indexOf('play') >= 0 && !/play|express/.test(dn.intent.kind),
     'localResolve (no brain) honors the veto identically — frivolous blocked, caring seated');

  console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN — conscience/instinct can block, the Society resolves it, she never goes silent, and a glad room stays playful'));
  process.exit(fail ? 1 : 0);
})();
