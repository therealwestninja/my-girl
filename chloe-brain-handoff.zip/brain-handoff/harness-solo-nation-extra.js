/* Two nation suites in one file (combined for packaging). node harness-solo-nation-extra.js
 *   1) intents under a role frame: a driving/adversary/commanding frame turns the right nations forceful
 *      (voice->oppose/press/command, reason->drive, play->provoke) while the guards/warm faculties stay
 *      supportive, and the forceful kinds fall outside the play/express veto. Default/none frame = unchanged.
 *   2) affect->sentiment consolidation: the council's signed user-sentiment comes from affect.js's valence
 *      (one source of truth), passed in on the turn; the council's own cues remain the faithful fallback. */
'use strict';
var N = require('./nation.js');
var fail = 0; function ok(c, m){ if (c) console.log('  ok   ' + m); else { fail++; console.log('  FAIL ' + m); } }

// ===== suite 1: role-frame intents =====
function sectionFrame(){
  function army(frame, opts){
    var a = N.createArmy(Object.assign({ rng: function(){ return 0.5; } }, opts || {}));
    a.perceive({ who:'You', role:'user', text:'you call that an attack? pathetic.' });
    return a;
  }
  function floorKinds(dec){ var o = {}; (dec.floor || []).forEach(function(f){ o[f.id] = f.kind; }); return o; }

  // default frame (and no frame) -> the original supportive intents, unchanged
  return Promise.resolve().then(function(){
    return army(null).deliberateIntents({ prompt:'hi' }).then(function(d0){
      var k0 = floorKinds(d0);
      ok(k0.voice === 'express' && k0.reason === 'ground' && k0.play === 'play' && k0.conscience === 'protect', 'no frame: voice=express, reason=ground, play=play, conscience=protect (unchanged)');

      var DEF = { drive:'you', alignment:'ally', stature:'equal' };
      return army(null).deliberateIntents({ prompt:'hi', frame: DEF }).then(function(dDef){
        var kd = floorKinds(dDef);
        ok(kd.voice === 'express' && kd.reason === 'ground', 'the default {you,ally,equal} frame is identical to no frame (no behavior change when unset)');

        // adversary -> voice opposes, reason presses, play provokes; guards stay
        return army(null).deliberateIntents({ prompt:'hi', frame: { drive:'you', alignment:'adversary', stature:'equal' } }).then(function(dA){
          var ka = floorKinds(dA);
          ok(ka.voice === 'oppose' && ka.reason === 'press' && ka.play === 'provoke', 'adversary: voice=oppose, reason=press, play=provoke');
          ok(ka.heart === 'comfort' && ka.conscience === 'protect' && ka.instinct === 'caution', 'adversary: the warm faculties and guards keep their supportive intents (protection floor intact)');

          // commands -> voice commands; she-leads -> reason drives
          return army(null).deliberateIntents({ prompt:'hi', frame: { drive:'she', alignment:'ally', stature:'commands' } }).then(function(dC){
            var kc = floorKinds(dC);
            ok(kc.voice === 'command' && kc.reason === 'drive', 'she-leads + commands: voice=command, reason=drive');

            // the forceful intents are NOT play/express, so the veto (which only blocks play/express) never catches them
            var vetoedForce = (dC.vetoed || []).some(function(id){ return id === 'voice' || id === 'reason'; });
            ok(!vetoedForce, 'forceful intents fall outside the play/express guard \u2014 the frame relaxes the veto for free');

          });
        });
      });
    });
  });
}

// ===== suite 2: affect -> sentiment =====
function sectionAffect(){
  function freshArmy(){ return N.createArmy({ rng: function(){ return 0.5; } }); }
  function feed(a, valence){ for (var i = 0; i < 4; i++) a.perceive({ who:'You', role:'user', text:'tell me about your day', valence: valence }); return a; }

  // neutral TEXT (no distress/anger words), so the only thing that can move sentiment is the affect valence we feed.
  return Promise.resolve().then(function(){
    return feed(freshArmy(), -0.9).deliberateIntents({ prompt:'hi' }).then(function(dNeg){
      ok((dNeg.vetoed || []).length > 0, 'sustained NEGATIVE affect valence drives sentiment down -> the guard vetoes the frivolous intents');
      ok((dNeg.vetoed || []).indexOf('play') >= 0 || (dNeg.vetoed || []).indexOf('voice') >= 0, '...specifically play/express, exactly what conscience guards');

      return feed(freshArmy(), 0.9).deliberateIntents({ prompt:'hi' }).then(function(dPos){
        ok((dPos.vetoed || []).length === 0, 'POSITIVE affect valence keeps sentiment up: no veto, she stays free to play');

        // no valence passed at all: the council falls back to its own cues, and neutral text -> no movement (parity)
        var c = freshArmy(); for (var i = 0; i < 4; i++) c.perceive({ who:'You', role:'user', text:'tell me about your day' });
        return c.deliberateIntents({ prompt:'hi' }).then(function(dNone){
          ok((dNone.vetoed || []).length === 0, 'NO external valence: the original cues path is unchanged (neutral text -> no veto, parity preserved)');

          // and the cues path still works on its own when the text itself is hostile (the fallback is intact)
          var d = freshArmy(); for (var i = 0; i < 3; i++) d.perceive({ who:'You', role:'user', text:'you are stupid and i hate this' });
          return d.deliberateIntents({ prompt:'hi' }).then(function(dCue){
            ok((dCue.vetoed || []).length > 0, 'the cues fallback still fires on genuinely hostile text when no affect read is supplied');
          });
        });
      });
    });
  });
}

sectionFrame()
  .then(sectionAffect)
  .then(function(){
    console.log('\n' + (fail ? ('FAILURES: ' + fail) : 'ALL GREEN \u2014 role-frame intents turn the right nations forceful while the guards stay supportive, and user-sentiment flows from the affect read with the cues path as faithful fallback'));
    process.exit(fail ? 1 : 0);
  })
  .catch(function(e){ console.log('FAIL: threw ' + (e && e.stack || e)); process.exit(1); });
